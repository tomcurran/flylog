package org.tomcurran.logbook.ui.fragments;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Equipment;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

public class EquipmentDialogFragment extends BaseDialogFragment {

	public static final String TAG = "equipment_dialog_fragment";
	private static final String[] PROJECTION = {
			Equipment.EQUIPMENT_CANOPY_NAME,
			Equipment.EQUIPMENT_CANOPY_SIZE
	};

	public EquipmentDialogFragment(Long rowId, BaseDialogFragment.OnSuccessListener listener) {
		super(rowId, R.layout.fragment_dialog_equipment);
		setOnSuccessListener(listener);
	}

	@Override
	public void setupView(Builder builder, View view) {
		if (mRowId == null) {
			builder.setTitle(R.string.dialog_title_equipment_add);
			return;
		}
		
		Cursor equipment = getActivity().getContentResolver().query(
				Equipment.buildEquipmentUri(mRowId),
				PROJECTION,
				null,
				null,
				Equipment.DEFAULT_SORT
		);
		if (equipment.moveToFirst()) {
			builder.setTitle(R.string.dialog_title_equipment_edit);
			((EditText) view.findViewById(R.id.dialog_text_equipment_name)).setText(
					equipment.getString(equipment.getColumnIndexOrThrow(Equipment.EQUIPMENT_CANOPY_NAME)));
			((EditText) view.findViewById(R.id.dialog_text_equipment_size)).setText(
					equipment.getString(equipment.getColumnIndexOrThrow(Equipment.EQUIPMENT_CANOPY_SIZE)));
		}
	}

	@Override
	public void onPositiveButtonClick(DialogInterface dialog) {
		String equipmentName = ((EditText)((AlertDialog)dialog).findViewById(R.id.dialog_text_equipment_name)).getText().toString();
		String equipmentSize = ((EditText)((AlertDialog)dialog).findViewById(R.id.dialog_text_equipment_size)).getText().toString();
        if (!TextUtils.isEmpty(equipmentName) && !TextUtils.isEmpty(equipmentSize)) {
        	ContentResolver resolver = getActivity().getContentResolver();
        	ContentValues values = new ContentValues();
        	values.put(Equipment.EQUIPMENT_CANOPY_NAME, equipmentName);
        	values.put(Equipment.EQUIPMENT_CANOPY_SIZE, Integer.valueOf(equipmentSize));
        	if (mRowId != null) {
        		resolver.update(Equipment.buildEquipmentUri(mRowId), values, null, null);
        	} else {
        		Uri equipmentUri = resolver.insert(Equipment.CONTENT_URI, values);
        		mRowId = Long.valueOf(Equipment.getEquipmentId(equipmentUri));
        	}
        	dispatchOnSuccessListener();
        }
	}

	@Override
	public void onNeutralButtonClick(DialogInterface dialog) {
		if (mRowId != null) {
			getActivity().getContentResolver().delete(Equipment.buildEquipmentUri(mRowId), null, null);
			dispatchOnSuccessListener();
    	}
	}

}
