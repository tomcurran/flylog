package org.tomcurran.logbook.ui.fragments;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Aircrafts;
import org.tomcurran.logbook.ui.BaseActivity;
import org.tomcurran.logbook.ui.HomeActivity;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.ActionBar;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.ListFragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.view.Menu;
import android.support.v4.view.MenuInflater;
import android.support.v4.view.MenuItem;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.widget.TextView;

public class AircraftListFragment extends ListFragment implements LoaderManager.LoaderCallbacks<Cursor> {

	private static final int LOADER_AIRCRAFTS = 0;
	private static final String[] PROJECTION = {
		Aircrafts.AIRCRAFT_NAME,
		Aircrafts._ID
	};

	private CursorAdapter mAdapter;
    private BaseDialogFragment.OnSuccessListener mAircraftOnSuccessListener = new BaseDialogFragment.OnSuccessListener() {
		@Override
		public void onSuccess(Long id) {
			getLoaderManager().restartLoader(LOADER_AIRCRAFTS, null, AircraftListFragment.this);
		}
	};

	// life cycle

    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setHasOptionsMenu(true);
    }

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		FragmentActivity activity = getActivity();
		ActionBar ab = activity.getSupportActionBar();
		
		ab.setTitle(R.string.title_aircraft_list);
//        ab.setDisplayHomeAsUpEnabled(true);

		setEmptyText(getString(R.string.list_emtpy_aircraft));
		mAdapter = new AircraftListAdapter(activity);
		setListAdapter(mAdapter);
        getLoaderManager().initLoader(LOADER_AIRCRAFTS, null, this);
		registerForContextMenu(getListView());
	}


	// Options menu

    @Override
    public void onCreateOptionsMenu(Menu menu, android.view.MenuInflater inflater) {
    	inflater.inflate(R.menu.options_menu_list_aircraft, menu);
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home: {
			((BaseActivity)getActivity()).goUp(HomeActivity.class);
			return true;
		}
		case R.id.options_menu_list_aircraft_insert: {
			createAircraft();
			return true;
		}
		default:
			return super.onOptionsItemSelected(item);
		}
	}


	// Context menu

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		editAircraft(id);
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		MenuInflater inflater = (MenuInflater) getActivity().getMenuInflater();
		inflater.inflate(R.menu.context_menu_list_item_aircraft, menu);
		menu.setHeaderTitle(
				 ((TextView) ((AdapterContextMenuInfo) menuInfo)
						 .targetView.findViewById(android.R.id.text1)).getText());
	}

	@Override
	public boolean onContextItemSelected(android.view.MenuItem item) {
		switch (item.getItemId()) {
		case R.id.context_menu_list_item_aircraft_edit: {
			editAircraft(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		case R.id.context_menu_list_item_aircraft_delete: {
			deleteAircraft(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		default:
			return super.onContextItemSelected(item);
		}
	}


	// helpers

	private void createAircraft() {
		new AircraftDialogFragment(null, mAircraftOnSuccessListener)
			.show(getFragmentManager(), AircraftDialogFragment.TAG);
	}

	private void editAircraft(long aircraftId) {
		new AircraftDialogFragment(aircraftId, mAircraftOnSuccessListener)
			.show(getFragmentManager(), AircraftDialogFragment.TAG);
	}

	private void deleteAircraft(long aircraftId) {
		getActivity().getContentResolver().delete(Aircrafts.buildAircraftUri(aircraftId), null, null);
		getLoaderManager().restartLoader(LOADER_AIRCRAFTS, null, this);
	}


	// loaders

	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		return new CursorLoader(
				getActivity(),
				Aircrafts.CONTENT_URI,
				PROJECTION,
				null,
				null,
				Aircrafts.DEFAULT_SORT
		);
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
		mAdapter.swapCursor(data);
	}

	@Override
	public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.swapCursor(null);
	}


	// list adapter

	public static class AircraftListAdapter extends SimpleCursorAdapter {

		private static final int[] TO = new int[] {
			android.R.id.text1
		};

		public AircraftListAdapter(Context context) {
			super(context, android.R.layout.simple_list_item_1, null, PROJECTION, TO, 0);
		}
	}

}
