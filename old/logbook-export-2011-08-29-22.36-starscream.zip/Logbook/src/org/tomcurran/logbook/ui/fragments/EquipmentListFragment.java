package org.tomcurran.logbook.ui.fragments;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Equipment;
import org.tomcurran.logbook.ui.BaseActivity;
import org.tomcurran.logbook.ui.HomeActivity;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.ActionBar;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.ListFragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.view.Menu;
import android.support.v4.view.MenuInflater;
import android.support.v4.view.MenuItem;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.widget.TextView;

public class EquipmentListFragment extends ListFragment implements LoaderManager.LoaderCallbacks<Cursor> {

	private static final int LOADER_EQUIPMENT = 0;
	private static final String[] PROJECTION = {
		Equipment.EQUIPMENT_CANOPY_NAME,
		Equipment.EQUIPMENT_CANOPY_SIZE,
		Equipment._ID
	};

	private CursorAdapter mAdapter;
    private BaseDialogFragment.OnSuccessListener mEquipmentOnSuccessListener = new BaseDialogFragment.OnSuccessListener() {
		@Override
		public void onSuccess(Long id) {
			getLoaderManager().restartLoader(LOADER_EQUIPMENT, null, EquipmentListFragment.this);
		}
	};

	// life cycle

    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setHasOptionsMenu(true);
    }

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		FragmentActivity activity = getActivity();
		ActionBar ab = activity.getSupportActionBar();
		
		ab.setTitle(R.string.title_equipment_list);
//        ab.setDisplayHomeAsUpEnabled(true);

		setEmptyText(getString(R.string.list_emtpy_equipment));
		mAdapter = new EquipmentListAdapter(activity);
		setListAdapter(mAdapter);
        getLoaderManager().initLoader(LOADER_EQUIPMENT, null, this);
		registerForContextMenu(getListView());
	}


	// Options menu

    @Override
    public void onCreateOptionsMenu(Menu menu, android.view.MenuInflater inflater) {
    	inflater.inflate(R.menu.options_menu_list_equipment, menu);
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home: {
			((BaseActivity)getActivity()).goUp(HomeActivity.class);
			return true;
		}
		case R.id.options_menu_list_equipment_insert: {
			createEquipment();
			return true;
		}
		default:
			return super.onOptionsItemSelected(item);
		}
	}


	// Context menu

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		editEquipment(id);
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		MenuInflater inflater = (MenuInflater) getActivity().getMenuInflater();
		inflater.inflate(R.menu.context_menu_list_item_equipment, menu);
		menu.setHeaderTitle(
				 ((TextView) ((AdapterContextMenuInfo) menuInfo)
						 .targetView.findViewById(android.R.id.text1)).getText());
	}

	@Override
	public boolean onContextItemSelected(android.view.MenuItem item) {
		switch (item.getItemId()) {
		case R.id.context_menu_list_item_equipment_edit: {
			editEquipment(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		case R.id.context_menu_list_item_equipment_delete: {
			deleteEquipment(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		default:
			return super.onContextItemSelected(item);
		}
	}


	// helpers

	private void createEquipment() {
		new EquipmentDialogFragment(null, mEquipmentOnSuccessListener)
			.show(getFragmentManager(), EquipmentDialogFragment.TAG);
	}

	private void editEquipment(long equipmentId) {
		new EquipmentDialogFragment(equipmentId, mEquipmentOnSuccessListener)
			.show(getFragmentManager(), EquipmentDialogFragment.TAG);
	}

	private void deleteEquipment(long equipmentId) {
		getActivity().getContentResolver().delete(Equipment.buildEquipmentUri(equipmentId), null, null);
		getLoaderManager().restartLoader(LOADER_EQUIPMENT, null, this);
	}


	// loaders

	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		return new CursorLoader(
				getActivity(),
				Equipment.CONTENT_URI,
				PROJECTION,
				null,
				null,
				Equipment.DEFAULT_SORT
		);
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
		mAdapter.swapCursor(data);
	}

	@Override
	public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.swapCursor(null);
	}


	// list adapter

	public static class EquipmentListAdapter extends SimpleCursorAdapter {

		private static final int[] TO = new int[] {
			android.R.id.text1
		};

		public EquipmentListAdapter(Context context) {
			super(context, android.R.layout.simple_list_item_1, null, PROJECTION, TO, 0);
		}

		@Override
		public void bindView(View view, Context context, Cursor cursor) {
			super.bindView(view, context, cursor);

			ViewHolder holder = (ViewHolder) view.getTag();
			if (holder == null) {
				holder = new ViewHolder();
				holder.text = (TextView) view.findViewById(android.R.id.text1);
				holder.nameColumn = cursor.getColumnIndexOrThrow(Equipment.EQUIPMENT_CANOPY_NAME);
				holder.sizeColumn = cursor.getColumnIndexOrThrow(Equipment.EQUIPMENT_CANOPY_SIZE);
				view.setTag(holder);
			}

			holder.text.setText(cursor.getString(holder.nameColumn) + " " + cursor.getInt(holder.sizeColumn));
		}

		static class ViewHolder {
			TextView text;
			int nameColumn;
			int sizeColumn;
        }

	}

}
