package org.tomcurran.logbook.ui;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.ui.fragments.AircraftListFragment;
import org.tomcurran.logbook.ui.fragments.EquipmentListFragment;
import org.tomcurran.logbook.ui.fragments.JumpListFragment;
import org.tomcurran.logbook.ui.fragments.PlaceListFragment;
import org.tomcurran.logbook.ui.fragments.StatisticsFragment;

import android.os.Bundle;
import android.support.v4.app.ActionBar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.widget.ArrayAdapter;

public class HomeActivity extends BaseActivity implements ActionBar.OnNavigationListener {

	private static final int LIST_JUMP      = 0;
	private static final int LIST_STATS     = 1;
	private static final int LIST_PLACES    = 2;
	private static final int LIST_AIRCRAFTS = 3;
	private static final int LIST_EQUIPMENT = 4;

	private Fragment mJumpFragment;
	private Fragment mStatFragment;
	private Fragment mPlaceFragment;
	private Fragment mAircraftFragment;
	private Fragment mEquipmentFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ensureSupportActionBarAttached();
		
		ActionBar ab = getSupportActionBar();
		ab.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
		ArrayAdapter<CharSequence> list = ArrayAdapter.createFromResource(this, R.array.locations, R.layout.abs__simple_spinner_item);
        list.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		ab.setListNavigationCallbacks(list, this);

		mJumpFragment = new JumpListFragment();
		mStatFragment = new StatisticsFragment();
		mPlaceFragment = new PlaceListFragment();
		mAircraftFragment = new AircraftListFragment();
		mEquipmentFragment = new EquipmentListFragment();
	}

	@Override
	public boolean onNavigationItemSelected(int itemPosition, long itemId) {
		switch (itemPosition) {
		case LIST_JUMP:
			navigate(mJumpFragment);
			return true;
		case LIST_STATS:
			navigate(mStatFragment);
			return true;
		case LIST_PLACES:
			navigate(mPlaceFragment);
			return true;
		case LIST_AIRCRAFTS:
			navigate(mAircraftFragment);
			return true;
		case LIST_EQUIPMENT:
			navigate(mEquipmentFragment);
			return true;
		default:
			return false;
		}
	}

	private void navigate(Fragment fragment) {
		FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
		transaction.replace(android.R.id.content, fragment);
//		transaction.addToBackStack(null);
		transaction.commit();
	}


}