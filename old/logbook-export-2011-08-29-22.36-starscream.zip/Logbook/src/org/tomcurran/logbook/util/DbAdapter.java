package org.tomcurran.logbook.util;

import android.content.Context;
import android.database.Cursor;

import org.tomcurran.logbook.provider.LogbookContract.Jumps;

import java.util.Calendar;

public class DbAdapter {

	public static final String[] SELECTION_ARG_ZERO = { "0" };


    private static final String[] HIGHEST_JUMP_NUMBER_PROJECTION = { "max(" + Jumps.JUMP_NUMBER + ")" };
    private static final String HIGHEST_JUMP_NUMBER_SELECTION = Jumps.JUMP_NUMBER + ">?";

	public static int getHighestJumpNumber(Context context) {
    	final Cursor cursor = context.getContentResolver().query(
                Jumps.CONTENT_URI,
                HIGHEST_JUMP_NUMBER_PROJECTION,
                HIGHEST_JUMP_NUMBER_SELECTION,
                SELECTION_ARG_ZERO,
                Jumps.DEFAULT_SORT
        );
    	int highestJumpNumber = cursor.moveToFirst() ? cursor.getInt(0) : 0;
    	cursor.close();
    	return highestJumpNumber;
    }


	private static final String[] COUNT_PROJECTION = { "count(*)" };
	private static final String COUNT_SELECTION = Jumps.JUMP_DATE + ">=?";

	public static int getJumpCountLastMonths(Context context, int months) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, -months);
		final Cursor jumps = context.getContentResolver().query(
				Jumps.CONTENT_URI,
				COUNT_PROJECTION,
				COUNT_SELECTION,
				new String[] { String.valueOf(calendar.getTimeInMillis()) },
				Jumps.DEFAULT_SORT
		);
		int jumpCountLastMonths = jumps.moveToFirst() ? jumps.getInt(0) : 0;
		jumps.close();
		return jumpCountLastMonths;
	}

/*
	private static int getDelay(Context context, final String aggregate) {
		final Cursor jumps = context.getContentResolver().query(
				Jumps.CONTENT_URI,
				new String[] { aggregate + "(" + Jumps.JUMP_DELAY + ")" },
				DELAY_SELECTION,
				SELECTION_ARG_ZERO,
				Jumps.DEFAULT_SORT
		);
		int delay = jumps.moveToFirst() ? jumps.getInt(0) : 0;
		jumps.close();
		return delay;
	}

	public static int getTotalDelay(Context context) {
		return getDelay(context, "sum");
	}

	public static int getLongestDelay(Context context) {
    	return getDelay(context, "max");
    }


	private static int getAltitude(Context context, final String aggregate) {
		final Cursor cursor = context.getContentResolver().query(
                Jumps.CONTENT_URI,
        		new String[] { aggregate + "(" + Jumps.JUMP_ALTITUDE + ")" },
                ALTITUDE_SELECTION,
                SELECTION_ARG_ZERO,
                Jumps.DEFAULT_SORT
        );
		int altitude = cursor.moveToFirst() ? cursor.getInt(0) : 0;
		cursor.close();
		return altitude;
	}

	public static int getHeightestAltitude(Context context) {
		return getAltitude(context, "max");
	}

	public static int getLowestAltitude(Context context) {
		return getAltitude(context, "min");
	}

	public static int getAverageAltitude(Context context) {
		return getAltitude(context, "avg");
	}
*/


	public static final String ALTITUDE_SELECTION = Jumps.JUMP_ALTITUDE + ">?";
    public static final String ALTITUDE_MAX = "max(" + Jumps.JUMP_ALTITUDE + ")";
    public static final String ALTITUDE_AVG = "avg(" + Jumps.JUMP_ALTITUDE + ")";
    public static final String ALTITUDE_MIN = "min(" + Jumps.JUMP_ALTITUDE + ")";
    public static final String[] ALTITUDES_PROJECTION = {
			ALTITUDE_MAX,
			ALTITUDE_AVG,
			ALTITUDE_MIN
	};


	public static final String DELAY_SELECTION = Jumps.JUMP_DELAY + ">?";
	public static final String DELAY_MAX = "max(" + Jumps.JUMP_DELAY + ")";
	public static final String DELAY_SUM = "sum(" + Jumps.JUMP_DELAY + ")";
	public static final String[] DELAYS_PROJECTION = {
			DELAY_MAX,
			DELAY_SUM
	};

}