package org.tomcurran.logbook.ui.fragments;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Aircrafts;
import org.tomcurran.logbook.provider.LogbookContract.Equipment;
import org.tomcurran.logbook.provider.LogbookContract.Jumps;
import org.tomcurran.logbook.provider.LogbookContract.Places;
import org.tomcurran.logbook.util.DbAdapter;
import org.tomcurran.logbook.util.UIUtils;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class StatisticsFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {

	private static final int LOADER_MONTHS6_COUNT = 5;
	private static final int LOADER_MONTHS12_COUNT = 6;
	private static final int LOADER_MONTHS18_COUNT = 7;
	private static final int LOADER_MONTHS24_COUNT = 8;
	private static final int LOADER_ALTITUDES = 0;
	private static final int LOADER_DELAYS = 1;
	private static final int LOADER_PLACES = 2;
	private static final int LOADER_EQUIPMENT = 3;
	private static final int LOADER_AIRCRAFTS = 4;

	public static final String COUNT_ALL = "count(*)";
	public static final String[] MONTHS_PROJECTION = {
		COUNT_ALL
	};

	public static final String ALTITUDE_SELECTION = Jumps.JUMP_ALTITUDE + ">?";
    public static final String ALTITUDE_MAX = "max(" + Jumps.JUMP_ALTITUDE + ")";
    public static final String ALTITUDE_AVG = "avg(" + Jumps.JUMP_ALTITUDE + ")";
    public static final String ALTITUDE_MIN = "min(" + Jumps.JUMP_ALTITUDE + ")";
    public static final String[] ALTITUDES_PROJECTION = {
			ALTITUDE_MAX,
			ALTITUDE_AVG,
			ALTITUDE_MIN
	};

	public static final String DELAY_SELECTION = Jumps.JUMP_DELAY + ">?";
	public static final String DELAY_MAX = "max(" + Jumps.JUMP_DELAY + ")";
	public static final String DELAY_SUM = "sum(" + Jumps.JUMP_DELAY + ")";
	public static final String[] DELAYS_PROJECTION = {
			DELAY_MAX,
			DELAY_SUM
	};

	private static final String JUMP_NUMBER_COUNT = "count(" + Jumps.JUMP_NUMBER + ")";
	private static final String[] PLACES_PROJECTION = {
		JUMP_NUMBER_COUNT,
		Places.PLACE_NAME,
		Places._ID
	};
	private static final String[] EQUIPMENT_PROJECTION = {
		JUMP_NUMBER_COUNT,
		Equipment.EQUIPMENT_CANOPY_NAME,
		Equipment.EQUIPMENT_CANOPY_SIZE,
		Equipment._ID
	};
	private static final String[] AIRCRAFTS_PROJECTION = {
		JUMP_NUMBER_COUNT,
		Aircrafts.AIRCRAFT_NAME,
		Aircrafts._ID
	};

	private Cursor mMonths6Cursor;
	private Cursor mMonths12Cursor;
	private Cursor mMonths18Cursor;
	private Cursor mMonths24Cursor;
	private Cursor mAltitudesCursor;
	private Cursor mDelaysCursor;
	private Cursor mPlacesCursor;
	private Cursor mEquipmentCursor;
	private Cursor mAircraftsCursor;

	// life cycle

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflater.inflate(R.layout.fragment_statistics, container, false);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
        LoaderManager loaderManager = getLoaderManager();
        loaderManager.initLoader(LOADER_MONTHS6_COUNT,  null, this);
        loaderManager.initLoader(LOADER_MONTHS12_COUNT, null, this);
        loaderManager.initLoader(LOADER_MONTHS18_COUNT, null, this);
        loaderManager.initLoader(LOADER_MONTHS24_COUNT, null, this);
        loaderManager.initLoader(LOADER_ALTITUDES,      null, this);
        loaderManager.initLoader(LOADER_DELAYS,         null, this);
        loaderManager.initLoader(LOADER_PLACES,         null, this);
        loaderManager.initLoader(LOADER_EQUIPMENT,      null, this);
        loaderManager.initLoader(LOADER_AIRCRAFTS,      null, this);
	}


    // loaders

	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		switch (id) {
        case LOADER_MONTHS6_COUNT:        	
            return new CursorLoader(
            		getActivity(),
                    Jumps.buildLastMonthsUri(6),
                    MONTHS_PROJECTION,
                    null,
                    null,
                    Jumps.DEFAULT_SORT
            );
        case LOADER_MONTHS12_COUNT:        	
            return new CursorLoader(
            		getActivity(),
                    Jumps.buildLastMonthsUri(12),
                    MONTHS_PROJECTION,
                    null,
                    null,
                    Jumps.DEFAULT_SORT
            );
        case LOADER_MONTHS18_COUNT:        	
            return new CursorLoader(
            		getActivity(),
                    Jumps.buildLastMonthsUri(18),
                    MONTHS_PROJECTION,
                    null,
                    null,
                    Jumps.DEFAULT_SORT
            );
        case LOADER_MONTHS24_COUNT:        	
            return new CursorLoader(
            		getActivity(),
                    Jumps.buildLastMonthsUri(24),
                    MONTHS_PROJECTION,
                    null,
                    null,
                    Jumps.DEFAULT_SORT
            );
        case LOADER_ALTITUDES:
            return new CursorLoader(
            		getActivity(),
                    Jumps.CONTENT_URI,
                    ALTITUDES_PROJECTION,
                    ALTITUDE_SELECTION,
                    DbAdapter.SELECTION_ARG_ZERO,
                    Jumps.DEFAULT_SORT
            );
        case LOADER_DELAYS:
        	return new CursorLoader(
					getActivity(),
					Jumps.CONTENT_URI,
					DELAYS_PROJECTION,
					DELAY_SELECTION,
					DbAdapter.SELECTION_ARG_ZERO,
					Jumps.DEFAULT_SORT
			);
        case LOADER_PLACES:
        	return new CursorLoader(
					getActivity(),
					Places.CONTENT_STATS_URI,
					PLACES_PROJECTION,
					null,
					null,
					Places.DEFAULT_SORT
			);
        case LOADER_EQUIPMENT:
        	return new CursorLoader(
					getActivity(),
					Equipment.CONTENT_STATS_URI,
					EQUIPMENT_PROJECTION,
					null,
					null,
					Equipment.DEFAULT_SORT
			);
        case LOADER_AIRCRAFTS:
        	return new CursorLoader(
					getActivity(),
					Aircrafts.CONTENT_STATS_URI,
					AIRCRAFTS_PROJECTION,
					null,
					null,
					Aircrafts.DEFAULT_SORT
			);
        default:
            return null;
        }
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
		switch (loader.getId()) {
        case LOADER_MONTHS6_COUNT:
            mMonths6Cursor = data;
            loadMonths6();
            break;
        case LOADER_MONTHS12_COUNT:
            mMonths12Cursor = data;
            loadMonths12();
            break;
        case LOADER_MONTHS18_COUNT:
            mMonths18Cursor = data;
            loadMonths18();
            break;
        case LOADER_MONTHS24_COUNT:
            mMonths24Cursor = data;
            loadMonths24();
            break;
        case LOADER_ALTITUDES:
            mAltitudesCursor = data;
            loadAltitudes();
            break;
        case LOADER_DELAYS:
            mDelaysCursor = data;
            loadDelays();
            break;
        case LOADER_PLACES:
            mPlacesCursor = data;
            loadPlaces();
            break;
        case LOADER_EQUIPMENT:
            mEquipmentCursor = data;
            loadEquipment();
            break;
        case LOADER_AIRCRAFTS:
            mAircraftsCursor = data;
            loadAircrafts();
            break;
		}
	}

	@Override
	public void onLoaderReset(Loader<Cursor> loader) {
		switch (loader.getId()) {
        case LOADER_MONTHS6_COUNT:
            mMonths6Cursor = null;
            break;
        case LOADER_MONTHS12_COUNT:
            mMonths12Cursor = null;
            break;
        case LOADER_MONTHS18_COUNT:
            mMonths18Cursor = null;
            break;
        case LOADER_MONTHS24_COUNT:
            mMonths24Cursor = null;
            break;
        case LOADER_ALTITUDES:
            mAltitudesCursor = null;
            break;
        case LOADER_DELAYS:
            mDelaysCursor = null;
            break;
        case LOADER_PLACES:
            mPlacesCursor = null;
            break;
        case LOADER_EQUIPMENT:
            mEquipmentCursor = null;
            break;
        case LOADER_AIRCRAFTS:
            mAircraftsCursor = null;
            break;
        }
	}

	private void loadMonths6() {
		Cursor data = mMonths6Cursor;
		Activity activity = getActivity();
		int count = 0;
		if (data != null && data.moveToFirst()) {
			count = data.getInt(data.getColumnIndexOrThrow(COUNT_ALL));
		}
		((TextView) activity.findViewById(R.id.text_stat_jump_numbers_6))
				.setText(getString(R.string.text_stat_jump_numbers, 6, count));
	}

	private void loadMonths12() {
		Cursor data = mMonths12Cursor;
		Activity activity = getActivity();
		int count = 0;
		if (data != null && data.moveToFirst()) {
			count = data.getInt(data.getColumnIndexOrThrow(COUNT_ALL));
		}
		((TextView) activity.findViewById(R.id.text_stat_jump_numbers_12))
				.setText(getString(R.string.text_stat_jump_numbers, 12, count));
	}

	private void loadMonths18() {
		Cursor data = mMonths18Cursor;
		Activity activity = getActivity();
		int count = 0;
		if (data != null && data.moveToFirst()) {
			count = data.getInt(data.getColumnIndexOrThrow(COUNT_ALL));
		}
		((TextView) activity.findViewById(R.id.text_stat_jump_numbers_18))
				.setText(getString(R.string.text_stat_jump_numbers, 18, count));
	}

	private void loadMonths24() {
		Cursor data = mMonths24Cursor;
		Activity activity = getActivity();
		int count = 0;
		if (data != null && data.moveToFirst()) {
			count = data.getInt(data.getColumnIndexOrThrow(COUNT_ALL));
		}
		((TextView) activity.findViewById(R.id.text_stat_jump_numbers_24))
				.setText(getString(R.string.text_stat_jump_numbers, 24, count));
	}

	private void loadAltitudes() {
		Cursor data = mAltitudesCursor;
		Activity activity = getActivity();
		int highestAltitude = 0;
		int averageAltitude = 0;
		int lowestAltitude = 0;
		if (data != null && data.moveToFirst()) {
			highestAltitude = data.getInt(data.getColumnIndexOrThrow(ALTITUDE_MAX));
			averageAltitude = data.getInt(data.getColumnIndexOrThrow(ALTITUDE_AVG));
			lowestAltitude = data.getInt(data.getColumnIndexOrThrow(ALTITUDE_MIN));
		}
		((TextView) activity.findViewById(R.id.text_stat_altitude))
				.setText(getString(R.string.text_stat_altitude,
					UIUtils.formatAltitude(activity, highestAltitude),
					UIUtils.formatAltitude(activity, averageAltitude),
					UIUtils.formatAltitude(activity, lowestAltitude)));
	}

	private void loadDelays() {
		Cursor data = mDelaysCursor;
		Activity activity = getActivity();
		int longestDelay = 0;
		int totalDelay = 0;
		if (data != null && data.moveToFirst()) {
			longestDelay = data.getInt(data.getColumnIndexOrThrow(DELAY_MAX));
			totalDelay = data.getInt(data.getColumnIndexOrThrow(DELAY_SUM));
		}
		((TextView) activity.findViewById(R.id.text_stat_delay))
				.setText(getString(R.string.text_stat_delay,
					UIUtils.formatDelay(activity, longestDelay),
					UIUtils.formatDelay(activity, totalDelay)));
	}

	private void loadPlaces() {
		Cursor data = mPlacesCursor;
		TextView placesText = (TextView) getActivity().findViewById(R.id.text_stat_places);
		if (data != null && data.moveToFirst()) {
			int nameColumn = data.getColumnIndexOrThrow(Places.PLACE_NAME);
			int countColumn = data.getColumnIndexOrThrow(JUMP_NUMBER_COUNT);
			placesText.setText("");
			do {
				placesText.append(getString(R.string.text_stat_places,
						data.getString(nameColumn), data.getInt(countColumn)));
			} while (data.moveToNext());
		} else {
			placesText.setText(getString(R.string.text_stat_places_empty));
		}
	}

	private void loadEquipment() {
		Cursor data = mEquipmentCursor;
		TextView equipmentText = (TextView) getActivity().findViewById(R.id.text_stat_equipment);
		if (data != null && data.moveToFirst()) {
			int nameColumn = data.getColumnIndexOrThrow(Equipment.EQUIPMENT_CANOPY_NAME);
			int sizeColumn = data.getColumnIndexOrThrow(Equipment.EQUIPMENT_CANOPY_SIZE);
			int countColumn = data.getColumnIndexOrThrow(JUMP_NUMBER_COUNT);
			equipmentText.setText("");
			do {
				equipmentText.append(getString(R.string.text_stat_equipment,
						data.getString(nameColumn), data.getInt(sizeColumn), data.getInt(countColumn)));
			} while (data.moveToNext());
		} else {
			equipmentText.setText(getString(R.string.text_stat_equipment_empty));
		}
	}

	private void loadAircrafts() {
		Cursor data = mAircraftsCursor;
		TextView aircraftsText = (TextView) getActivity().findViewById(R.id.text_stat_aircrafts);
		if (data != null && data.moveToFirst()) {
			int nameColumn = data.getColumnIndexOrThrow(Aircrafts.AIRCRAFT_NAME);
			int countColumn = data.getColumnIndexOrThrow(JUMP_NUMBER_COUNT);
			aircraftsText.setText("");
			do {
				aircraftsText.append(getString(R.string.text_stat_aircrafts,
						data.getString(nameColumn), data.getInt(countColumn)));
			} while (data.moveToNext());
		} else {
			aircraftsText.setText(getString(R.string.text_stat_aircrafts_empty));
		}
	}

}
