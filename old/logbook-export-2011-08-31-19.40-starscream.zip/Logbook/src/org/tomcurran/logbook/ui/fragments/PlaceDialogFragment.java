package org.tomcurran.logbook.ui.fragments;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Places;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

public class PlaceDialogFragment extends BaseDialogFragment {

	public static final String TAG = "place_dialog_fragment";
	private static final String[] PROJECTION = {
		Places.PLACE_NAME
	};

	public PlaceDialogFragment(Long rowId, BaseDialogFragment.OnSuccessListener listener) {
		super(rowId, R.layout.fragment_dialog_single);
		setOnSuccessListener(listener);
	}

	@Override
	public void setupView(Builder builder, View view) {
		if (mRowId == null) {
			builder.setTitle(R.string.dialog_title_place_add);
			return;
		}
		
		Cursor place = getActivity().getContentResolver().query(
				Places.buildPlaceUri(mRowId),
				PROJECTION,
				null,
				null,
				Places.DEFAULT_SORT
		);
		if (place.moveToFirst()) {
			builder.setTitle(R.string.dialog_title_place_edit);
			((EditText) view.findViewById(R.id.dialog_text)).setText(
					place.getString(place.getColumnIndexOrThrow(Places.PLACE_NAME)));
		}
	}

	@Override
	public void onPositiveButtonClick(DialogInterface dialog) {
		String placeName = ((EditText)((AlertDialog)dialog).findViewById(R.id.dialog_text)).getText().toString();
        if (!TextUtils.isEmpty(placeName)) {
        	ContentResolver resolver = getActivity().getContentResolver();
        	ContentValues values = new ContentValues();
        	values.put(Places.PLACE_NAME, placeName);
        	if (mRowId != null) {
        		resolver.update(Places.buildPlaceUri(mRowId), values, null, null);
        	} else {
        		Uri placeUri = resolver.insert(Places.CONTENT_URI, values);
        		mRowId = Long.valueOf(Places.getPlaceId(placeUri));
        	}
        	dispatchOnSuccessListener();
        }
	}

	@Override
	public void onNeutralButtonClick(DialogInterface dialog) {
		if (mRowId != null) {
			getActivity().getContentResolver().delete(Places.buildPlaceUri(mRowId), null, null);
			dispatchOnSuccessListener();
    	}
	}

}
