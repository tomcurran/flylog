package org.tomcurran.logbook.ui;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.ui.fragments.AircraftListFragment;
import org.tomcurran.logbook.ui.fragments.EquipmentListFragment;
import org.tomcurran.logbook.ui.fragments.JumpListFragment;
import org.tomcurran.logbook.ui.fragments.PlaceListFragment;
import org.tomcurran.logbook.ui.fragments.StatisticsFragment;

import android.os.Bundle;
import android.support.v4.app.ActionBar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.widget.ArrayAdapter;

public class HomeActivity extends BaseActivity implements ActionBar.OnNavigationListener {

	private static final int LIST_JUMP      = 0;
	private static final int LIST_STATS     = 1;
	private static final int LIST_PLACES    = 2;
	private static final int LIST_AIRCRAFTS = 3;
	private static final int LIST_EQUIPMENT = 4;

	private static final String TAG_JUMP      = "jump";
	private static final String TAG_STATS     = "stats";
	private static final String TAG_PLACES    = "place";
	private static final String TAG_AIRCRAFTS = "aircraft";
	private static final String TAG_EQUIPMENT = "equipment";

	private Fragment mJumpFragment;
	private Fragment mStatFragment;
	private Fragment mPlaceFragment;
	private Fragment mAircraftFragment;
	private Fragment mEquipmentFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ensureSupportActionBarAttached();

		ActionBar ab = getSupportActionBar();
		FragmentManager fm = getSupportFragmentManager();

		ArrayAdapter<CharSequence> list = ArrayAdapter.createFromResource(this, R.array.locations, R.layout.abs__simple_spinner_item);
        list.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		ab.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
		ab.setListNavigationCallbacks(list, this);

		mJumpFragment = setupFragment(fm, JumpListFragment.class, TAG_JUMP);
		mStatFragment = setupFragment(fm, StatisticsFragment.class, TAG_STATS);
		mPlaceFragment = setupFragment(fm, PlaceListFragment.class, TAG_PLACES);
		mAircraftFragment = setupFragment(fm, AircraftListFragment.class, TAG_AIRCRAFTS);
		mEquipmentFragment = setupFragment(fm, EquipmentListFragment.class, TAG_EQUIPMENT);

	}

	private Fragment setupFragment(FragmentManager fragmentManager, Class<? extends Fragment> fragmentClass, String tag) {
		Fragment frag = fragmentClass.cast(fragmentManager.findFragmentByTag(tag));
		if (frag == null) {
			try {
				frag = fragmentClass.newInstance();
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		return frag;
	}

	@Override
	public boolean onNavigationItemSelected(int itemPosition, long itemId) {
		switch (itemPosition) {
		case LIST_JUMP:
			navigate(mJumpFragment, TAG_JUMP);
			return true;
		case LIST_STATS:
			navigate(mStatFragment, TAG_STATS);
			return true;
		case LIST_PLACES:
			navigate(mPlaceFragment, TAG_PLACES);
			return true;
		case LIST_AIRCRAFTS:
			navigate(mAircraftFragment, TAG_AIRCRAFTS);
			return true;
		case LIST_EQUIPMENT:
			navigate(mEquipmentFragment, TAG_EQUIPMENT);
			return true;
		default:
			return false;
		}
	}

	private void navigate(Fragment fragment, String tag) {
		if (!fragment.isAdded()) {
			getSupportFragmentManager()
				.beginTransaction()
				.replace(android.R.id.content, fragment, tag)
				.commit();
		}
	}

}