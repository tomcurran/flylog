package org.tomcurran.logbook.util;

import org.tomcurran.logbook.provider.LogbookContract.Jumps;

import android.content.Context;
import android.database.Cursor;

public class DbAdapter {

	public static final String[] SELECTION_ARG_ZERO = { "0" };


    private static final String[] HIGHEST_JUMP_NUMBER_PROJECTION = { "max(" + Jumps.JUMP_NUMBER + ")" };
    private static final String HIGHEST_JUMP_NUMBER_SELECTION = Jumps.JUMP_NUMBER + ">?";

	public static int getHighestJumpNumber(Context context) {
    	final Cursor cursor = context.getContentResolver().query(
                Jumps.CONTENT_URI,
                HIGHEST_JUMP_NUMBER_PROJECTION,
                HIGHEST_JUMP_NUMBER_SELECTION,
                SELECTION_ARG_ZERO,
                Jumps.DEFAULT_SORT
        );
    	int highestJumpNumber = cursor.moveToFirst() ? cursor.getInt(0) : 0;
    	cursor.close();
    	return highestJumpNumber;
    }

}