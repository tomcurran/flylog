package org.tomcurran.logbook.ui;

import org.tomcurran.logbook.R;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

public class JumpActivity extends FragmentActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jump);
    }
}
