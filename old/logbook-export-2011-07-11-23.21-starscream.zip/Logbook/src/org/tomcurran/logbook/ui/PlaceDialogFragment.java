package org.tomcurran.logbook.ui;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Places;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

public class PlaceDialogFragment extends DialogFragment {
	
	Fragment mHostFragment;
	int mLoaderId;

	public PlaceDialogFragment(Fragment hostFragment, int loaderId) {
		super();
		mHostFragment = hostFragment;
		mLoaderId = loaderId;
	}

	public static PlaceDialogFragment newInstance(Long placeId, Fragment hostFragment, final int loaderId) {
		PlaceDialogFragment frag = new PlaceDialogFragment(hostFragment, loaderId);
        if (placeId != null) {
        	Bundle args = new Bundle();
        	args.putLong(Places._ID, placeId);
            frag.setArguments(args);
        }
        return frag;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Bundle args = getArguments();
    	final Long placeId = args != null ? args.getLong(Places._ID) : null;
        
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.fragment_dialog_place, null);
        
        String title = placeId != null ? "Edit Place" : "Add Place";

        return new AlertDialog.Builder(getActivity())
//                .setIcon(R.drawable.dialog_icon_place)
                .setTitle(title)
                .setView(view)
                .setPositiveButton(R.string.dialog_button_place_ok,
                    new DialogInterface.OnClickListener() {
                        @SuppressWarnings("unchecked")
						public void onClick(DialogInterface dialog, int whichButton) {
                        	String placeName = ((EditText)((AlertDialog)dialog).findViewById(R.id.dialog_text_place_name)).getText().toString();
                            if (!TextUtils.isEmpty(placeName)) {
                            	ContentValues values = new ContentValues();
                            	values.put(Places.PLACE_NAME, placeName);
                            	if (placeId != null) {
                                	getActivity().getContentResolver().update(Places.buildPlaceUri(placeId), values, null, null);
                            	} else {
                                	getActivity().getContentResolver().insert(Places.CONTENT_URI, values);
                            	}
                            	mHostFragment.getLoaderManager().restartLoader(mLoaderId, null, (LoaderCallbacks<Cursor>) mHostFragment);
                            }
                        }
                    }
                )
                .setNegativeButton(R.string.dialog_button_place_cancel,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
//                            Toast.makeText(getActivity(), "negative click...", Toast.LENGTH_SHORT).show();
                        }
                    }
                )
                .create();
    }
}
