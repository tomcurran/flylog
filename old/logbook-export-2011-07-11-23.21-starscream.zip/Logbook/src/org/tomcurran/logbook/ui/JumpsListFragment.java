package org.tomcurran.logbook.ui;

import java.text.NumberFormat;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Aircrafts;
import org.tomcurran.logbook.provider.LogbookContract.Jumps;
import org.tomcurran.logbook.provider.LogbookContract.Places;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.view.MenuCompat;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter;
import android.text.format.DateFormat;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class JumpsListFragment extends ListFragment implements LoaderManager.LoaderCallbacks<Cursor> {

	private static final int ACTIVITY_CREATE = 0;
	private static final int ACTIVITY_EDIT = 1;
	private static final int LOADER_JUMPS = 0;
	
	private static final String[] PROJECTION = new String[] {
		Jumps.JUMP_NUMBER,
		Jumps.JUMP_DATE,
		Places.PLACE_NAME,
		Aircrafts.AIRCRAFT_NAME,
		Jumps.JUMP_ALTITUDE,
		Jumps.JUMP_DESCRIPTION,
		Jumps._ID
	};

	private CursorAdapter mAdapter;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflater.inflate(R.layout.fragment_list_jumps, container, false);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		registerForContextMenu(getListView());
		mAdapter = new JumpsListAdapter(getActivity());
		setListAdapter(mAdapter);
        getLoaderManager().initLoader(LOADER_JUMPS, null, this);
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		getLoaderManager().restartLoader(LOADER_JUMPS, null, this);
	}
	
	
	// Options menu
	
	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		inflater.inflate(R.menu.options_menu_list_jumps, menu);
		MenuCompat.setShowAsAction(menu.findItem(R.id.options_menu_list_jumps_insert), 1);
		super.onCreateOptionsMenu(menu, inflater);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.options_menu_list_jumps_insert:
			createJump();
			return true;
		case R.id.options_menu_list_jumps_preferences:
			Toast.makeText(getActivity(), "preferences...", Toast.LENGTH_SHORT).show();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	
	
	// Context menu

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		editJump(id);
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		MenuInflater inflater = getActivity().getMenuInflater();
		inflater.inflate(R.menu.context_menu_list_item_jumps, menu);
		menu.setHeaderTitle(getString(R.string.context_menu_list_item_jumps_title,
				 ((TextView) ((AdapterContextMenuInfo) menuInfo).targetView.findViewById(R.id.list_item_jumps_number)).getText()));
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.context_menu_list_item_jumps_edit: {
			editJump(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		case R.id.context_menu_list_item_jumps_delete: {
			deleteJump(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		default:
			return super.onContextItemSelected(item);
		}
	}


	// helpers
	
	private void createJump() {
		Intent i = new Intent(getActivity(), JumpActivity.class);
		startActivityForResult(i, ACTIVITY_CREATE);
	}
	
	private void editJump(long jumpId) {
		Intent i = new Intent(getActivity(), JumpActivity.class);
		i.putExtra(Jumps._ID, jumpId);
		startActivityForResult(i, ACTIVITY_EDIT);
	}
	
	private void deleteJump(long jumpId) {
		getActivity().getContentResolver().delete(Jumps.buildJumpUri(jumpId), null, null);
		getLoaderManager().restartLoader(LOADER_JUMPS, null, this);
	}

	
	// loader implements
	
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		return new CursorLoader(
				getActivity(),
				Jumps.CONTENT_URI,
				PROJECTION,
				null,
				null,
				Jumps.DEFAULT_SORT
		);
	}

	public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
		mAdapter.swapCursor(data);
	}

	public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.swapCursor(null);
	}

	
	// list adapter
	
	public static class JumpsListAdapter extends SimpleCursorAdapter {

		private static final int[] TO = new int[] {
			R.id.list_item_jumps_number,
			R.id.list_item_jumps_date,
			R.id.list_item_jumps_place,
			R.id.list_item_jumps_aircraft,
			R.id.list_item_jumps_altitude,
			R.id.list_item_jumps_description
		};

		public JumpsListAdapter(Context context) {
			super(context, R.layout.list_item_jumps, null, PROJECTION, TO, 0);
		}

		@Override
		public void bindView(View view, Context context, Cursor cursor) {
			super.bindView(view, context, cursor);
			
			TextView altitudeText = (TextView) view.findViewById(R.id.list_item_jumps_altitude);
			TextView dateText = (TextView) view.findViewById(R.id.list_item_jumps_date);
			
			int altitude = cursor.getInt(cursor.getColumnIndex(Jumps.JUMP_ALTITUDE));		
			altitudeText.setText(NumberFormat.getIntegerInstance().format(altitude) + " ft");

			long dateMillis = cursor.getLong(cursor.getColumnIndex(Jumps.JUMP_DATE));
			dateText.setText(DateFormat.format("E, MMMM dd, yyyy", dateMillis));
		}
	}

}
