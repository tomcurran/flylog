package org.tomcurran.logbook.ui;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Aircrafts;
import org.tomcurran.logbook.provider.LogbookContract.Equipment;
import org.tomcurran.logbook.provider.LogbookContract.Jumps;
import org.tomcurran.logbook.provider.LogbookContract.Places;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.format.Time;

public class HomeActivity extends FragmentActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
//        insertTestData();
    }

    // test data
	
	public void insertTestData() {
		ContentResolver resolver = getContentResolver();
		ContentValues values = new ContentValues();
		Uri placeUri;
		Uri aircraftUri;
		Uri equipmentUri;
		Time time = new Time();
		
		resolver.delete(Jumps.CONTENT_URI, null, null);
		resolver.delete(Places.CONTENT_URI, null, null);
		resolver.delete(Aircrafts.CONTENT_URI, null, null);
		resolver.delete(Equipment.CONTENT_URI, null, null);
		
		values.put(Places.PLACE_NAME, "Wild Geese");
		resolver.insert(Places.CONTENT_URI, values);
		values.put(Places.PLACE_NAME, "Perris");
		resolver.insert(Places.CONTENT_URI, values);
		values.clear();
		values.put(Places.PLACE_NAME, "Strathallan");
		placeUri = resolver.insert(Places.CONTENT_URI, values);

		values.clear();
		values.put(Aircrafts.AIRCRAFT_NAME, "Skyvan");
		resolver.insert(Aircrafts.CONTENT_URI, values);
		values.clear();
		values.put(Aircrafts.AIRCRAFT_NAME, "C208");
		resolver.insert(Aircrafts.CONTENT_URI, values);
		values.clear();
		values.put(Aircrafts.AIRCRAFT_NAME, "C206");
		aircraftUri = resolver.insert(Aircrafts.CONTENT_URI, values);

		values.clear();
		values.put(Equipment.EQUIPMENT_CANOPY_NAME, "Balance");
		values.put(Equipment.EQUIPMENT_CANOPY_SIZE, 210);
		resolver.insert(Equipment.CONTENT_URI, values);
		values.clear();
		values.put(Equipment.EQUIPMENT_CANOPY_NAME, "Fury");
		values.put(Equipment.EQUIPMENT_CANOPY_SIZE, 220);
		resolver.insert(Equipment.CONTENT_URI, values);
		values.clear();
		values.put(Equipment.EQUIPMENT_CANOPY_NAME, "Spectre");
		values.put(Equipment.EQUIPMENT_CANOPY_SIZE, 190);
		equipmentUri = resolver.insert(Equipment.CONTENT_URI, values);
		
		values.clear();
		values.put(Jumps.PLACE_ID, Places.getPlaceId(placeUri));
		values.put(Jumps.AIRCRAFT_ID, Aircrafts.getAircraftId(aircraftUri));
		values.put(Jumps.EQUIPMENT_ID, Equipment.getEquipmentId(equipmentUri));
		values.put(Jumps.JUMP_NUMBER, 116);
		time.set(26, 6 - 1, 2011);
		values.put(Jumps.JUMP_DATE, time.toMillis(false));
		values.put(Jumps.JUMP_ALTITUDE, 2200);
		values.put(Jumps.JUMP_DELAY, 5);
		values.put(Jumps.JUMP_DESCRIPTION, "hop'n'pop");
		resolver.insert(Jumps.CONTENT_URI, values);
		
		values.clear();
		values.put(Jumps.PLACE_ID, Places.getPlaceId(placeUri));
		values.put(Jumps.AIRCRAFT_ID, Aircrafts.getAircraftId(aircraftUri));
		values.put(Jumps.EQUIPMENT_ID, Equipment.getEquipmentId(equipmentUri));
		values.put(Jumps.JUMP_NUMBER, 115);
		time.set(25, 6 - 1, 2011);
		values.put(Jumps.JUMP_DATE, time.toMillis(false));
		values.put(Jumps.JUMP_ALTITUDE, 10000);
		values.put(Jumps.JUMP_DELAY, 47);
		values.put(Jumps.JUMP_DESCRIPTION, "5 way speed star unlinked exit with john, sandy, jonny, kieran.\nManaged to get 3 in star; me, john, sandy");
		resolver.insert(Jumps.CONTENT_URI, values);
	}

}