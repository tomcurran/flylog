package org.tomcurran.logbook.ui.fragments;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Aircrafts;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

public class AircraftDialogFragment extends BaseDialogFragment {

	public static final String TAG = "aircraft_dialog_fragment";
	private static final String[] PROJECTION = {
		Aircrafts.AIRCRAFT_NAME
	};

	public AircraftDialogFragment(Long rowId, BaseDialogFragment.OnSuccessListener listener) {
		super(rowId, R.layout.fragment_dialog_aircraft);
		setOnSuccessListener(listener);
	}

	@Override
	public void setupView(Builder builder, View view) {
		if (mRowId == null) {
			builder.setTitle(R.string.dialog_title_aircraft_add);
			return;
		}
		
		Cursor aircraft = getActivity().getContentResolver().query(
				Aircrafts.buildAircraftUri(mRowId),
				PROJECTION,
				null,
				null,
				Aircrafts.DEFAULT_SORT
		);
		if (aircraft.moveToFirst()) {
			builder.setTitle(R.string.dialog_title_aircraft_edit);
			((EditText) view.findViewById(R.id.dialog_text_aircraft_name)).setText(
					aircraft.getString(aircraft.getColumnIndexOrThrow(Aircrafts.AIRCRAFT_NAME)));
		}
	}

	@Override
	public void onPositiveButtonClick(DialogInterface dialog) {
		String aircraftName = ((EditText)((AlertDialog)dialog).findViewById(R.id.dialog_text_aircraft_name)).getText().toString();
        if (!TextUtils.isEmpty(aircraftName)) {
        	ContentResolver resolver = getActivity().getContentResolver();
        	ContentValues values = new ContentValues();
        	values.put(Aircrafts.AIRCRAFT_NAME, aircraftName);
        	if (mRowId != null) {
        		resolver.update(Aircrafts.buildAircraftUri(mRowId), values, null, null);
        	} else {
        		Uri aircraftUri = resolver.insert(Aircrafts.CONTENT_URI, values);
        		mRowId = Long.valueOf(Aircrafts.getAircraftId(aircraftUri));
        	}
        	dispatchOnSuccessListener();
        }
	}

	@Override
	public void onNeutralButtonClick(DialogInterface dialog) {
		if (mRowId != null) {
			getActivity().getContentResolver().delete(Aircrafts.buildAircraftUri(mRowId), null, null);
			dispatchOnSuccessListener();
    	}
	}

}
