package org.tomcurran.logbook.util;

import android.content.Context;
import android.database.Cursor;

import org.tomcurran.logbook.provider.LogbookContract.Jumps;
import org.tomcurran.logbook.provider.LogbookDatabase;

import java.util.Calendar;

public class DatabaseAdapter {

	public static final String[] SELECTION_ARG_ZERO = { "0" };


    private static final String[] HIGHEST_JUMP_NUMBER_PROJECTION = { "max(" + Jumps.JUMP_NUMBER + ")" };
    private static final String HIGHEST_JUMP_NUMBER_SELECTION = Jumps.JUMP_NUMBER + ">?";

	public static int getHighestJumpNumber(Context context) {
    	final Cursor cursor = context.getContentResolver().query(
                Jumps.CONTENT_URI,
                HIGHEST_JUMP_NUMBER_PROJECTION,
                HIGHEST_JUMP_NUMBER_SELECTION,
                SELECTION_ARG_ZERO,
                Jumps.DEFAULT_SORT
        );
    	return cursor.moveToFirst() ? cursor.getInt(0) : 0;
    }


	private static final String[] COUNT_PROJECTION = { "count(*)" };
	private static final String COUNT_SELECTION = Jumps.JUMP_DATE + ">=?";

	public static int getJumpCountLastMonths(Context context, int months) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, -months);
		final Cursor jumps = context.getContentResolver().query(
				Jumps.CONTENT_URI,
				COUNT_PROJECTION,
				COUNT_SELECTION,
				new String[] { String.valueOf(calendar.getTimeInMillis()) },
				Jumps.DEFAULT_SORT
		);
		return jumps.moveToFirst() ? jumps.getInt(0) : 0;
	}


	private static final String DELAY_SELECTION = Jumps.JUMP_DELAY + ">?";

	private static int getDelay(Context context, final String aggregate) {
		final Cursor jumps = context.getContentResolver().query(
				Jumps.CONTENT_URI,
				new String[] { aggregate + "(" + Jumps.JUMP_DELAY + ")" },
				DELAY_SELECTION,
				SELECTION_ARG_ZERO,
				Jumps.DEFAULT_SORT
		);
		return jumps.moveToFirst() ? jumps.getInt(0) : 0;
	}

	public static int getTotalDelay(Context context) {
		return getDelay(context, "sum");
	}

	public static int getLongestDelay(Context context) {
    	return getDelay(context, "max");
    }


    private static final String ALTITUDE_SELECTION = Jumps.JUMP_ALTITUDE + ">?";

	private static int getAltitude(Context context, final String aggregate) {
		final Cursor cursor = context.getContentResolver().query(
                Jumps.CONTENT_URI,
        		new String[] { aggregate + "(" + Jumps.JUMP_ALTITUDE + ")" },
                ALTITUDE_SELECTION,
                SELECTION_ARG_ZERO,
                Jumps.DEFAULT_SORT
        );
		return cursor.moveToFirst() ? cursor.getInt(0) : 0;
	}

	public static int getHeightestAltitude(Context context) {
		return getAltitude(context, "max");
	}

	public static int getLowestAltitude(Context context) {
		return getAltitude(context, "min");
	}

	public static int getAverageAltitude(Context context) {
		return getAltitude(context, "avg");
	}


	private static final String PLACES_COUNT_TABLE = "places LEFT OUTER JOIN jumps ON places._id=jumps.place_id";
	public static final String[] PLACES_COUNT_PROJECTION = {
		"count(jump_number)",
		"places.place_name",
		"places._id"
	};
	private static final String PLACES_COUNT_GROUPBY = PLACES_COUNT_PROJECTION[2];
	private static final String PLACES_COUNT_ORDERBY = PLACES_COUNT_PROJECTION[0] + " DESC";

	public static Cursor getPlacesCountCursor(Context context) {
		return new LogbookDatabase(context).getReadableDatabase().query(
				PLACES_COUNT_TABLE,
				PLACES_COUNT_PROJECTION,
				null,
				null,
				PLACES_COUNT_GROUPBY,
				null,
				PLACES_COUNT_ORDERBY,
				null);
	}


	private static final String EQUIPMENT_COUNT_TABLE = "equipment LEFT OUTER JOIN jumps ON equipment._id=jumps.equipment_id";
	public static final String[] EQUIPMENT_COUNT_PROJECTION = {
		"count(jump_number)",
		"equipment.equipment_canopy_name",
		"equipment.equipment_canopy_size",
		"equipment._id"
	};
	private static final String EQUIPMENT_COUNT_GROUPBY = EQUIPMENT_COUNT_PROJECTION[2];
	private static final String EQUIPMENT_COUNT_ORDERBY = EQUIPMENT_COUNT_PROJECTION[0] + " DESC";

	public static Cursor getEquipmentCountCursor(Context context) {
		return new LogbookDatabase(context).getReadableDatabase().query(
				EQUIPMENT_COUNT_TABLE,
				EQUIPMENT_COUNT_PROJECTION,
				null,
				null,
				EQUIPMENT_COUNT_GROUPBY,
				null,
				EQUIPMENT_COUNT_ORDERBY,
				null);
	}


	private static final String AIRCRAFTS_COUNT_TABLE = "aircrafts LEFT OUTER JOIN jumps ON aircrafts._id=jumps.aircraft_id";
	public static final String[] AIRCRAFTS_COUNT_PROJECTION = {
		"count(jump_number)",
		"aircrafts.aircraft_name",
		"aircrafts._id"
	};
	private static final String AIRCRAFTS_COUNT_GROUPBY = AIRCRAFTS_COUNT_PROJECTION[2];
	private static final String AIRCRAFTS_COUNT_ORDERBY = AIRCRAFTS_COUNT_PROJECTION[0] + " DESC";

	public static Cursor getAircraftsCountCursor(Context context) {
		return new LogbookDatabase(context).getReadableDatabase().query(
				AIRCRAFTS_COUNT_TABLE,
				AIRCRAFTS_COUNT_PROJECTION,
				null,
				null,
				AIRCRAFTS_COUNT_GROUPBY,
				null,
				AIRCRAFTS_COUNT_ORDERBY,
				null);
	}
}