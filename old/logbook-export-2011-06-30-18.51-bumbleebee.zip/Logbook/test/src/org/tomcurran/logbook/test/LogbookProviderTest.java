package org.tomcurran.logbook.test;

import org.tomcurran.logbook.provider.LogbookContract;
import org.tomcurran.logbook.provider.LogbookDatabase;
import org.tomcurran.logbook.provider.LogbookProvider;
import org.tomcurran.logbook.provider.LogbookContract.Aircrafts;
import org.tomcurran.logbook.provider.LogbookContract.Equipment;
import org.tomcurran.logbook.provider.LogbookContract.Jumps;
import org.tomcurran.logbook.provider.LogbookContract.Places;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.test.ProviderTestCase2;
import android.test.mock.MockContentResolver;
import android.text.format.Time;

public class LogbookProviderTest extends ProviderTestCase2<LogbookProvider> {

	private static final Uri INVALID_PLACES_URI = Uri.withAppendedPath(Places.CONTENT_URI, "invalid");
	private static final Uri INVALID_AIRCRAFTS_URI = Uri.withAppendedPath(Aircrafts.CONTENT_URI, "invalid");
	private static final Uri INVALID_EQUIPMENT_URI = Uri.withAppendedPath(Equipment.CONTENT_URI, "invalid");
	private static final Uri INVALID_JUMPS_URI = Uri.withAppendedPath(Jumps.CONTENT_URI, "invalid");
	
	private MockContentResolver mMockResolver;
	private SQLiteDatabase mDb;
	
	private static Time sTime = new Time();
	
	private final PlaceInfo[] TEST_PLACES = {
			new PlaceInfo("place0"),
			new PlaceInfo("place1"),
			new PlaceInfo("place2"),
			new PlaceInfo("place3"),
			new PlaceInfo("place4")
	};
	
	private final AircraftInfo[] TEST_AIRCRAFTS = {
			new AircraftInfo("aircraft0"),
			new AircraftInfo("aircraft1"),
			new AircraftInfo("aircraft2"),
			new AircraftInfo("aircraft3"),
			new AircraftInfo("aircraft4")
	};
	
	private final EquipmentInfo[] TEST_EQUIPMENT = {
			new EquipmentInfo("equipment0", 280),
			new EquipmentInfo("equipment1", 220),
			new EquipmentInfo("equipment2", 210),
			new EquipmentInfo("equipment3", 190),
			new EquipmentInfo("equipment4", 170)
	};
	
	private final JumpInfo[] TEST_JUMPS = {
			new JumpInfo(1, 1, 1, 0, sTime.toMillis(false), 2200, 5, "description0"),
			new JumpInfo(2, 2, 2, 1, sTime.toMillis(false), 2200, 6, "description1"),
			new JumpInfo(3, 3, 3, 2, sTime.toMillis(false), 2200, 7, "description2"),
			new JumpInfo(4, 4, 4, 3, sTime.toMillis(false), 2200, 6, "description3"),
			new JumpInfo(5, 5, 5, 4, sTime.toMillis(false), 2200, 5, "description4")
	};
 
	public LogbookProviderTest() {
		super(LogbookProvider.class, LogbookContract.CONTENT_AUTHORITY);
	}
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		
		mMockResolver = getMockContentResolver();
		mDb = new LogbookDatabase(getMockContext()).getWritableDatabase();
		sTime.set(29, 6 - 1, 2011);
	}
	
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	private void insertData() {
		
		for (int index = 0; index < TEST_PLACES.length; index++) {
            mDb.insertOrThrow(
            	"places", // TODO don't do this?
            	Places.PLACE_NAME,
            	TEST_PLACES[index].getContentValues()
            );
        }
		
		for (int index = 0; index < TEST_AIRCRAFTS.length; index++) {
			mDb.insertOrThrow(
            	"aircrafts", // TODO don't do this?
            	Aircrafts.AIRCRAFT_NAME,
            	TEST_AIRCRAFTS[index].getContentValues()
            );
        }
		
		for (int index = 0; index < TEST_EQUIPMENT.length; index++) {
			mDb.insertOrThrow(
            	"equipment", // TODO don't do this?
            	Equipment.EQUIPMENT_CANOPY_NAME,
            	TEST_EQUIPMENT[index].getContentValues()
            );
        }
		
		for (int index = 0; index < TEST_JUMPS.length; index++) {
			mDb.insertOrThrow(
            	"jumps", // TODO don't do this?
            	Jumps.JUMP_DESCRIPTION,
            	TEST_JUMPS[index].getContentValues()
            );
        }
		
	}
	
	public void testUriAndGetType() {
		String mimeType;
		Uri placeIdUri;
		Uri aircraftIdUri;
		Uri equipmentIdUri;
		Uri jumpIdUri;
		
		// places
		mimeType = mMockResolver.getType(Places.CONTENT_URI);
		assertEquals(Places.CONTENT_TYPE, mimeType);
	
		placeIdUri = Places.buildPlaceUri("1");
		mimeType = mMockResolver.getType(placeIdUri);
		assertEquals(Places.CONTENT_ITEM_TYPE, mimeType);

		mimeType = mMockResolver.getType(INVALID_PLACES_URI);

		// aircrafts
		mimeType = mMockResolver.getType(Aircrafts.CONTENT_URI);
		assertEquals(Aircrafts.CONTENT_TYPE, mimeType);
	
		aircraftIdUri = Aircrafts.buildAircraftUri("1");
		mimeType = mMockResolver.getType(aircraftIdUri);
		assertEquals(Aircrafts.CONTENT_ITEM_TYPE, mimeType);

		mimeType = mMockResolver.getType(INVALID_AIRCRAFTS_URI);

		// equipment
		mimeType = mMockResolver.getType(Equipment.CONTENT_URI);
		assertEquals(Equipment.CONTENT_TYPE, mimeType);
	
		equipmentIdUri = Equipment.buildEquipmentUri("1");
		mimeType = mMockResolver.getType(equipmentIdUri);
		assertEquals(Equipment.CONTENT_ITEM_TYPE, mimeType);

		mimeType = mMockResolver.getType(INVALID_EQUIPMENT_URI);

		// jumps
		mimeType = mMockResolver.getType(Jumps.CONTENT_URI);
		assertEquals(Jumps.CONTENT_TYPE, mimeType);
	
		jumpIdUri = Jumps.buildJumpUri("1");
		mimeType = mMockResolver.getType(jumpIdUri);
		assertEquals(Jumps.CONTENT_ITEM_TYPE, mimeType);

		mimeType = mMockResolver.getType(INVALID_JUMPS_URI);
		
	}

	public void testQueriesOnPlacesUri() {
		final Uri CONTENT_URI = Places.CONTENT_URI;
		final String[] TEST_PROJECTION = {
				Places.PLACE_NAME
	    };
		final String NAME_SELECTION = Places.PLACE_NAME + "=?";
        final String SELECTION_COLUMNS = NAME_SELECTION + " OR " + NAME_SELECTION + " OR " + NAME_SELECTION;
        final String[] SELECTION_ARGS = { "place0", "place1", "place2" };
        final String SORT_ORDER = Places.DEFAULT_SORT;

		_testQueriesOnURI(
				CONTENT_URI,
				TEST_PROJECTION,
				NAME_SELECTION,
				SELECTION_COLUMNS,
				SELECTION_ARGS,
				SORT_ORDER,
				TEST_PLACES
		);
	}
	
	public void testQueriesOnPlaceIdUri() {
	      final String SELECTION_COLUMNS = Places.PLACE_NAME + "=?";
	      final String[] SELECTION_ARGS = { "place1" };
	      final String SORT_ORDER = Places.DEFAULT_SORT;
	      final String[] PLACE_ID_PROJECTION = {
	           Places._ID,
	           Places.PLACE_NAME
	      };

	      Uri placeIdUri = Places.buildPlaceUri("1");
	      Cursor cursor = mMockResolver.query(
	          placeIdUri,
	          null,
	          null,
	          null,
	          null
	      );
	      assertEquals(0,cursor.getCount());

	      insertData();
	      cursor = mMockResolver.query(
	          Places.CONTENT_URI,
	          PLACE_ID_PROJECTION, 
	          SELECTION_COLUMNS,
	          SELECTION_ARGS,
	          SORT_ORDER
	      );

	      assertEquals(1, cursor.getCount());
	      assertTrue(cursor.moveToFirst());

	      String inputPlaceId = cursor.getString(0);
	      placeIdUri = Places.buildPlaceUri(inputPlaceId);
	      cursor = mMockResolver.query(placeIdUri,
	    		  PLACE_ID_PROJECTION,
	    		  SELECTION_COLUMNS,
	    		  SELECTION_ARGS,
	    		  SORT_ORDER
	      );
	      assertEquals(1, cursor.getCount());
	      assertTrue(cursor.moveToFirst());
	      assertEquals(inputPlaceId, cursor.getString(0));
	}

	public void testPlacesInserts() {
		PlaceInfo place = new PlaceInfo(
				"place100"
		);

		Uri rowUri = mMockResolver.insert(
				Places.CONTENT_URI,
				place.getContentValues()
		);

		long placeId = Long.parseLong(Places.getPlaceId(rowUri));

		Cursor cursor = mMockResolver.query(
				Places.CONTENT_URI,
				null,
				null,
				null,
				null
		);
		assertEquals(1, cursor.getCount());
		assertTrue(cursor.moveToFirst());
		assertEquals(place.place_name, cursor.getString(cursor.getColumnIndex(Places.PLACE_NAME)));

		ContentValues values = place.getContentValues();
		values.put(Places._ID, placeId);
		try {
			rowUri = mMockResolver.insert(Places.CONTENT_URI, values);
			fail("Expected insert failure for existing record but insert succeeded.");
		} catch (Exception e) {
			// succeeded, so do nothing.
		}
	}

	public void testPlacesDeletes() {
		final Uri CONTENT_URI = Places.CONTENT_URI;
		final String SELECTION_COLUMNS = Places.PLACE_NAME + "=?";
        final String[] SELECTION_ARGS = { "place0" };
		_testDeletes(CONTENT_URI, SELECTION_COLUMNS, SELECTION_ARGS);
	}
	
	public void testPlacesUpdates() {
		final Uri CONTENT_URI = Places.CONTENT_URI;
        final String SELECTION_COLUMNS = Places.PLACE_NAME + "=?";
        final String[] selectionArgs = { "place1" };
        ContentValues values = new ContentValues();
        values.put(Places.PLACE_NAME, "place99");
        _testUpdates(CONTENT_URI, SELECTION_COLUMNS, selectionArgs, values);
	}

	public void testQueriesOnAircraftsUri() {
		final Uri CONTENT_URI = Aircrafts.CONTENT_URI;
		final String[] TEST_PROJECTION = {
				Aircrafts.AIRCRAFT_NAME
	    };
		final String NAME_SELECTION = Aircrafts.AIRCRAFT_NAME + "=?";
        final String SELECTION_COLUMNS = NAME_SELECTION + " OR " + NAME_SELECTION + " OR " + NAME_SELECTION;
        final String[] SELECTION_ARGS = { "aircraft0", "aircraft1", "aircraft2" };
        final String SORT_ORDER = Aircrafts.DEFAULT_SORT;

		_testQueriesOnURI(
				CONTENT_URI,
				TEST_PROJECTION,
				NAME_SELECTION,
				SELECTION_COLUMNS,
				SELECTION_ARGS,
				SORT_ORDER,
				TEST_AIRCRAFTS
		);
	}
	
	public void testQueriesOnAircraftIdUri() {
	      final String SELECTION_COLUMNS = Aircrafts.AIRCRAFT_NAME + "=?";
	      final String[] SELECTION_ARGS = { "aircraft1" };
	      final String SORT_ORDER = Aircrafts.DEFAULT_SORT;
	      final String[] AIRCRAFT_ID_PROJECTION = {
	    		  Aircrafts._ID,
	    		  Aircrafts.AIRCRAFT_NAME
	      };

	      Uri aircraftIdUri = Aircrafts.buildAircraftUri("1");
	      Cursor cursor = mMockResolver.query(
	          aircraftIdUri,
	          null,
	          null,
	          null,
	          null
	      );
	      assertEquals(0,cursor.getCount());

	      insertData();
	      cursor = mMockResolver.query(
	    		  Aircrafts.CONTENT_URI,
	    		  AIRCRAFT_ID_PROJECTION, 
	    		  SELECTION_COLUMNS,
	    		  SELECTION_ARGS,
	    		  SORT_ORDER
	      );

	      assertEquals(1, cursor.getCount());
	      assertTrue(cursor.moveToFirst());

	      String inputAircraftId = cursor.getString(0);
	      aircraftIdUri = Aircrafts.buildAircraftUri(inputAircraftId);
	      cursor = mMockResolver.query(aircraftIdUri,
	    		  AIRCRAFT_ID_PROJECTION,
	    		  SELECTION_COLUMNS,
	    		  SELECTION_ARGS,
	    		  SORT_ORDER
	      );
	      assertEquals(1, cursor.getCount());
	      assertTrue(cursor.moveToFirst());
	      assertEquals(inputAircraftId, cursor.getString(0));
	}
	
	public void testAircraftsInserts() {
		AircraftInfo aircraft = new AircraftInfo("aircraft99");
		Uri rowUri = mMockResolver.insert(
				Aircrafts.CONTENT_URI,
				aircraft.getContentValues());

		long aircraftId = Long.valueOf(Aircrafts.getAircraftId(rowUri));

		Cursor cursor = mMockResolver.query(
				Aircrafts.CONTENT_URI,
				null,
				null,
				null,
				null
		);
		assertEquals(1, cursor.getCount());
		assertTrue(cursor.moveToFirst());
		assertEquals(aircraft.aircraft_name, cursor.getString(cursor.getColumnIndex(Aircrafts.AIRCRAFT_NAME)));

		ContentValues values = aircraft.getContentValues();
		values.put(Aircrafts._ID, (int) aircraftId);
		try {
			rowUri = mMockResolver.insert(Aircrafts.CONTENT_URI, values);
			fail("Expected insert failure for existing record but insert succeeded.");
		} catch (Exception e) {
			// succeeded, so do nothing.
		}
	}

	public void testAircraftsDeletes() {
		final Uri CONTENT_URI = Aircrafts.CONTENT_URI;
		final String SELECTION_COLUMNS = Aircrafts.AIRCRAFT_NAME + "=?";
		final String[] SELECTION_ARGS = { "aircraft0" };
		_testDeletes(CONTENT_URI, SELECTION_COLUMNS, SELECTION_ARGS);
	}

	public void testAircraftsUpdates() {
		final Uri CONTENT_URI = Aircrafts.CONTENT_URI;
		final String SELECTION_COLUMNS = Aircrafts.AIRCRAFT_NAME + "=?";
		final String[] selectionArgs = { "aircraft1" };
		ContentValues values = new ContentValues();
		values.put(Aircrafts.AIRCRAFT_NAME, "aircraft99");
		_testUpdates(CONTENT_URI, SELECTION_COLUMNS, selectionArgs, values);
	}

	public void testQueriesOnEquipmentUri() {
		final Uri CONTENT_URI = Equipment.CONTENT_URI;
		final String[] TEST_PROJECTION = {
				Equipment.EQUIPMENT_CANOPY_NAME,
				Equipment.EQUIPMENT_CANOPY_SIZE
	    };
		final String NAME_SELECTION = Equipment.EQUIPMENT_CANOPY_NAME + "=?";
        final String SELECTION_COLUMNS = NAME_SELECTION + " OR " + NAME_SELECTION + " OR " + NAME_SELECTION;
        final String[] SELECTION_ARGS = { "equipment0", "equipment1", "equipment2" };
        final String SORT_ORDER = Equipment.DEFAULT_SORT;
        
		_testQueriesOnURI(
				CONTENT_URI,
				TEST_PROJECTION,
				NAME_SELECTION,
				SELECTION_COLUMNS,
				SELECTION_ARGS,
				SORT_ORDER,
				TEST_EQUIPMENT
		);
	}
	
	public void testQueriesOnEquipmentIdUri() {
	      final String SELECTION_COLUMNS = Equipment.EQUIPMENT_CANOPY_NAME + "=?";
	      final String[] SELECTION_ARGS = { "equipment1" };
	      final String SORT_ORDER = Equipment.DEFAULT_SORT;
	      final String[] EQUIPMENT_ID_PROJECTION = {
	    		  Equipment._ID,
	    		  Equipment.EQUIPMENT_CANOPY_NAME,
	    		  Equipment.EQUIPMENT_CANOPY_SIZE
	      };

	      Uri equipmentIdUri = Equipment.buildEquipmentUri("1");
	      
	      Cursor cursor = mMockResolver.query(
	          equipmentIdUri,
	          null,
	          null,
	          null,
	          null
	      );
	      assertEquals(0,cursor.getCount());

	      insertData();
	      cursor = mMockResolver.query(
	    		  Equipment.CONTENT_URI,
	    		  EQUIPMENT_ID_PROJECTION, 
	    		  SELECTION_COLUMNS,
	    		  SELECTION_ARGS,
	    		  SORT_ORDER
	      );

	      assertEquals(1, cursor.getCount());
	      assertTrue(cursor.moveToFirst());

	      String inputEquipmentId = cursor.getString(0);
	      equipmentIdUri = Equipment.buildEquipmentUri(inputEquipmentId);
	      cursor = mMockResolver.query(
	    		  equipmentIdUri,
	    		  EQUIPMENT_ID_PROJECTION,
	    		  SELECTION_COLUMNS,
	    		  SELECTION_ARGS,
	    		  SORT_ORDER
	      );
	      assertEquals(1, cursor.getCount());
	      assertTrue(cursor.moveToFirst());
	      assertEquals(inputEquipmentId, cursor.getString(0));
	}
	
	public void testEquipmentInserts() {
		EquipmentInfo equipment = new EquipmentInfo("equipment99", 280);
		Uri rowUri = mMockResolver.insert(
				Equipment.CONTENT_URI,
				equipment.getContentValues()
		);

		long equipmentId = Long.valueOf(Equipment.getEquipmentId(rowUri));

		Cursor cursor = mMockResolver.query(
				Equipment.CONTENT_URI,
				null,
				null,
				null,
				null
		);
		assertEquals(1, cursor.getCount());
		assertTrue(cursor.moveToFirst());
		assertEquals(equipment.equipment_canopy_name, cursor.getString(cursor.getColumnIndex(Equipment.EQUIPMENT_CANOPY_NAME)));
		assertEquals(equipment.equipment_canopy_size, cursor.getInt(cursor.getColumnIndex(Equipment.EQUIPMENT_CANOPY_SIZE)));

		ContentValues values = equipment.getContentValues();
		values.put(Equipment._ID, (int) equipmentId);
		try {
			rowUri = mMockResolver.insert(Equipment.CONTENT_URI, values);
			fail("Expected insert failure for existing record but insert succeeded.");
		} catch (Exception e) {
			// succeeded, so do nothing.
		}
	}

	public void testEquipmentDeletes() {
		final Uri CONTENT_URI = Equipment.CONTENT_URI;
		final String SELECTION_COLUMNS = Equipment.EQUIPMENT_CANOPY_NAME + "=?";
		final String[] SELECTION_ARGS = { "equipment0" };
		_testDeletes(CONTENT_URI, SELECTION_COLUMNS, SELECTION_ARGS);
	}

	public void testEquipmentUpdates() {
		final Uri CONTENT_URI = Equipment.CONTENT_URI;
		final String SELECTION_COLUMNS = Equipment.EQUIPMENT_CANOPY_NAME + "=?";
		final String[] selectionArgs = { "equipment1" };
		ContentValues values = new ContentValues();
		values.put(Equipment.EQUIPMENT_CANOPY_NAME, "equipment99");
		values.put(Equipment.EQUIPMENT_CANOPY_SIZE, 280);
		_testUpdates(CONTENT_URI, SELECTION_COLUMNS, selectionArgs, values);
	}

	public void testQueriesOnJumpsUri() {
		final Uri CONTENT_URI = Jumps.CONTENT_URI;
		final String[] TEST_PROJECTION = {
				Jumps.JUMP_NUMBER,
				Jumps.JUMP_DESCRIPTION,
				Places.PLACE_NAME,
				Aircrafts.AIRCRAFT_NAME,
				Equipment.EQUIPMENT_CANOPY_NAME,
				Equipment.EQUIPMENT_CANOPY_SIZE
	    };
		final String NAME_SELECTION = Jumps.JUMP_NUMBER + "=?";
        final String SELECTION_COLUMNS = NAME_SELECTION + " OR " + NAME_SELECTION + " OR " + NAME_SELECTION;
        final String[] SELECTION_ARGS = { "2", "1", "0" };
        final String SORT_ORDER = Jumps.DEFAULT_SORT;

		_testQueriesOnURI(
				CONTENT_URI,
				TEST_PROJECTION,
				NAME_SELECTION,
				SELECTION_COLUMNS,
				SELECTION_ARGS,
				SORT_ORDER,
				TEST_JUMPS
		);
	}

	public void testQueriesOnJumpIdUri() {
	      final String SELECTION_COLUMNS = Jumps.JUMP_NUMBER + "=?";
	      final String[] SELECTION_ARGS = { "1" };
	      final String SORT_ORDER = Jumps.DEFAULT_SORT;
	      final String[] JUMP_ID_PROJECTION = {
	    		  Jumps._ID,
				  Jumps.JUMP_NUMBER,
				  Jumps.JUMP_DESCRIPTION,
				  Places.PLACE_NAME,
				  Aircrafts.AIRCRAFT_NAME,
				  Equipment.EQUIPMENT_CANOPY_NAME,
				  Equipment.EQUIPMENT_CANOPY_SIZE
	      };

	      Uri jumpIdUri = Jumps.buildJumpUri("1");
	      
	      Cursor cursor = mMockResolver.query(
	          jumpIdUri,
	          null,
	          null,
	          null,
	          null
	      );
	      assertEquals(0,cursor.getCount());

	      insertData();
	      cursor = mMockResolver.query(
	    		  Jumps.CONTENT_URI,
	    		  JUMP_ID_PROJECTION, 
	    		  SELECTION_COLUMNS,
	    		  SELECTION_ARGS,
	    		  SORT_ORDER
	      );

	      assertEquals(1, cursor.getCount());
	      assertTrue(cursor.moveToFirst());

	      String inputEquipmentId = cursor.getString(0);
	      jumpIdUri = Jumps.buildJumpUri(inputEquipmentId);
	      cursor = mMockResolver.query(
	    		  jumpIdUri,
	    		  JUMP_ID_PROJECTION,
	    		  SELECTION_COLUMNS,
	    		  SELECTION_ARGS,
	    		  SORT_ORDER
	      );
	      assertEquals(1, cursor.getCount());
	      assertTrue(cursor.moveToFirst());
	      assertEquals(inputEquipmentId, cursor.getString(0));
	}

	public void testJumpsInserts() {
		JumpInfo jump = new JumpInfo(1, 2, 3, 99, sTime.toMillis(false), 2200, 5, "description99");
		Uri rowUri = mMockResolver.insert(
				Jumps.CONTENT_URI,
				jump.getContentValues()
		);

		long jumpId = Long.valueOf(Jumps.getJumpId(rowUri));

		Cursor cursor = mMockResolver.query(
				Jumps.CONTENT_URI,
				null,
				null,
				null,
				null
		);
		assertEquals(1, cursor.getCount());
		assertTrue(cursor.moveToFirst());

		assertEquals(jump.place_id, cursor.getInt(cursor.getColumnIndex(Jumps.PLACE_ID)));
		assertEquals(jump.aircraft_id, cursor.getInt(cursor.getColumnIndex(Jumps.AIRCRAFT_ID)));
		assertEquals(jump.equipment_id, cursor.getInt(cursor.getColumnIndex(Jumps.EQUIPMENT_ID)));
		assertEquals(jump.jump_number, cursor.getInt(cursor.getColumnIndex(Jumps.JUMP_NUMBER)));
		assertEquals(jump.jump_description, cursor.getString(cursor.getColumnIndex(Jumps.JUMP_DESCRIPTION)));

		ContentValues values = jump.getContentValues();
		values.put(Jumps._ID, (int) jumpId);
		try {
			rowUri = mMockResolver.insert(Jumps.CONTENT_URI, values);
			fail("Expected insert failure for existing record but insert succeeded.");
		} catch (Exception e) {
			// succeeded, so do nothing.
		}
	}

	public void testJumpsDeletes() {
		final Uri CONTENT_URI = Jumps.CONTENT_URI;
		final String SELECTION_COLUMNS = Jumps.JUMP_NUMBER + "=?";
		final String[] SELECTION_ARGS = { "0" };
		_testDeletes(CONTENT_URI, SELECTION_COLUMNS, SELECTION_ARGS);
	}

	public void testJumpsUpdates() {
		final Uri CONTENT_URI = Jumps.CONTENT_URI;
		final String SELECTION_COLUMNS = Jumps.JUMP_NUMBER + "=?";
		final String[] selectionArgs = { "0" };
		ContentValues values = new ContentValues();
		values.put(Jumps.PLACE_ID, 5);
		values.put(Jumps.AIRCRAFT_ID, 5);
		values.put(Jumps.EQUIPMENT_ID, 5);
		values.put(Jumps.JUMP_NUMBER, 6);
		values.put(Jumps.JUMP_DESCRIPTION, "desctiption6");
		_testUpdates(CONTENT_URI, SELECTION_COLUMNS, selectionArgs, values);
	}

	private void _testQueriesOnURI(
			final Uri CONTENT_URI,
			final String[] TEST_PROJECTION,
			final String NAME_SELECTION,
			final String SELECTION_COLUMNS,
			final String[] SELECTION_ARGS,
			final String SORT_ORDER,
			final Object[] TEST_OBJECTS
	) {
		Cursor cursor;
		Cursor projectionCursor;
		
		cursor = mMockResolver.query(
				CONTENT_URI,
				null,
				null,
				null,
				null
		);
		assertEquals(0, cursor.getCount());
		
		insertData();
		
		cursor = mMockResolver.query(
				CONTENT_URI,
				null,
				null,
				null,
				null
		);
		assertEquals(TEST_OBJECTS.length, cursor.getCount());
		
		projectionCursor = mMockResolver.query(
				CONTENT_URI,
				TEST_PROJECTION,
				null,
				null,
				null
		);
		assertEquals(TEST_PROJECTION.length, projectionCursor.getColumnCount());
		assertEquals(TEST_PROJECTION[0], projectionCursor.getColumnName(0));
		
		projectionCursor = mMockResolver.query(
				CONTENT_URI,
				TEST_PROJECTION,
				SELECTION_COLUMNS,
				SELECTION_ARGS,
				SORT_ORDER
		);
		assertEquals(SELECTION_ARGS.length, projectionCursor.getCount());
		int index = 0;
        while (projectionCursor.moveToNext()) {
            assertEquals(SELECTION_ARGS[index], projectionCursor.getString(0));
            index++;
        }
        assertEquals(SELECTION_ARGS.length, index);
	}

	private void _testDeletes(
			final Uri CONTENT_URI,
			final String SELECTION_COLUMNS,
			final String[] SELECTION_ARGS
	) {
		int rowsDeleted = mMockResolver.delete(
				CONTENT_URI,
				SELECTION_COLUMNS,
				SELECTION_ARGS
		);
		assertEquals(0, rowsDeleted);

		insertData();
		rowsDeleted = mMockResolver.delete(
				CONTENT_URI,
				SELECTION_COLUMNS,
				SELECTION_ARGS
		);
		assertEquals(1, rowsDeleted);

		Cursor cursor = mMockResolver.query(
				CONTENT_URI,
				null,
				SELECTION_COLUMNS,
				SELECTION_ARGS,
				null
		);
		assertEquals(0, cursor.getCount());
	}
	
	private void _testUpdates(
			final Uri CONTENT_URI,
			final String SELECTION_COLUMNS,
			final String[] selectionArgs,
			ContentValues values
	) {		
		int rowsUpdated = mMockResolver.update(
				CONTENT_URI,
				values,
				SELECTION_COLUMNS,
				selectionArgs
		);
		assertEquals(0, rowsUpdated);

		insertData();
		rowsUpdated = mMockResolver.update(
				CONTENT_URI,
				values,
				SELECTION_COLUMNS,
				selectionArgs
		);
		assertEquals(1, rowsUpdated);
	}

	private static class PlaceInfo {
		String place_name;
		
		public PlaceInfo(String name) {
			this.place_name = name;
		}
		
		public ContentValues getContentValues() {
			ContentValues v = new ContentValues();
			v.put(Places.PLACE_NAME, place_name);
			return v;
		}
	}

	private static class AircraftInfo {
		String aircraft_name;
		
		public AircraftInfo(String name) {
			this.aircraft_name = name;
		}
		
		public ContentValues getContentValues() {
			ContentValues v = new ContentValues();
			v.put(Aircrafts.AIRCRAFT_NAME, aircraft_name);
			return v;
		}
	}

	private static class EquipmentInfo {
		String equipment_canopy_name;
		int equipment_canopy_size;
		
		public EquipmentInfo(String name, int size) {
			this.equipment_canopy_name = name;
			this.equipment_canopy_size = size;
		}
		
		public ContentValues getContentValues() {
			ContentValues v = new ContentValues();
			v.put(Equipment.EQUIPMENT_CANOPY_NAME, equipment_canopy_name);
			v.put(Equipment.EQUIPMENT_CANOPY_SIZE, equipment_canopy_size);
			return v;
		}
	}

	private static class JumpInfo {
		int place_id;
		int aircraft_id;
		int equipment_id;
		int jump_number;
		long jump_date;
		int jump_altitude;
		int jump_delay;
		String jump_description;
		
		public JumpInfo(int place, int aircraft, int equipment, int number, long date, int altitude, int delay, String description) {
			this.place_id = place;
			this.aircraft_id = aircraft;
			this.equipment_id = equipment;
			this.jump_number = number;
			this.jump_date = date;
			this.jump_altitude = altitude;
			this.jump_delay = delay;
			this.jump_description = description;
		}
		
		public ContentValues getContentValues() {
			ContentValues v = new ContentValues();
			v.put(Jumps.PLACE_ID, place_id);
			v.put(Jumps.AIRCRAFT_ID, aircraft_id);
			v.put(Jumps.EQUIPMENT_ID, equipment_id);
			v.put(Jumps.JUMP_NUMBER, jump_number);
			v.put(Jumps.JUMP_DATE, jump_date);
			v.put(Jumps.JUMP_ALTITUDE, jump_altitude);
			v.put(Jumps.JUMP_DELAY, jump_delay);
			v.put(Jumps.JUMP_DESCRIPTION, jump_description);
			return v;
		}
	}
}
