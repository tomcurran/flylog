package org.tomcurran.logbook.util;

import org.tomcurran.logbook.provider.LogbookContract.Aircrafts;
import org.tomcurran.logbook.provider.LogbookContract.Equipment;
import org.tomcurran.logbook.provider.LogbookContract.Jumps;
import org.tomcurran.logbook.provider.LogbookContract.Places;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.text.format.Time;

public class TestData {

	private ContentResolver mResolver;

	private final PlaceInfo[] PLACES = {
			new PlaceInfo("Strathallan"),
			new PlaceInfo("Black Knights"),
			new PlaceInfo("Wild Geese"),
			new PlaceInfo("Perris")
	};

	private final AircraftInfo[] AIRCRAFTS = {
			new AircraftInfo("C206"),
			new AircraftInfo("Porter"),
			new AircraftInfo("C208"),
			new AircraftInfo("Twin Otter"),
			new AircraftInfo("Skyvan"),
			new AircraftInfo("Baloon")
	};

	private final EquipmentInfo[] EQUIPMENT = {
			new EquipmentInfo("Manta",      280),
			new EquipmentInfo("Maveron",    240),
			new EquipmentInfo("PD",         210),
			new EquipmentInfo("Balance",    210),
			new EquipmentInfo("Fury",       220),
			new EquipmentInfo("Spectre",    190),
			new EquipmentInfo("Triathalon", 175)
	};

	private final JumpInfo[] JUMPS = {
			new JumpInfo(  0,     0,  0, 1970,  1,  1, "USED TO MATCH INDEXS TO JUMP NUMBER delete"),
			new JumpInfo(  1,  3500,  0, 2009, 11, 28, "Good exit, position & count\n(just get head further back)"),
			new JumpInfo(  2,  3500,  0, 2010,  2, 21, "Good exit, position & count\nBOC DP's next"),
			new JumpInfo(  3,  3500,  0, 2010,  3, 13, "Good setup, turned 90 right on exit, did get DP"),
			new JumpInfo(  4,  3500,  0, 2010,  3, 14, "Good setup, exit good & on heading. Fumbled D/P handle but got it on 5 seconds"),
			new JumpInfo(  5,  3500,  0, 2010,  3, 21, "Exit OK but didn't arch\nFumbled D/P but when got it good grasp, pull & recovery"),
			new JumpInfo(  6,  3500,  0, 2010,  3, 28, "Turned slight to right on eixt. Upper body good but dropped knees\nGood grasp, pull & recovery"),
			new JumpInfo(  7,  3500,  0, 2010,  4,  9, "G.A.T.W"),
			new JumpInfo(  8,  3500,  0, 2010,  4,  9, "Very good D.P. + ?\nNo ?"),
			new JumpInfo(  9,  3500,  0, 2010,  4,  9, "Great D/P.\nJust slight flat.\nC/C O.K.\nJust arch more!"),
			new JumpInfo( 10,  3500,  0, 2010,  4, 10, "Excellent D/P.\nJust scccchloooon down!\nGood C/C.\nCleared for F/F."),
			new JumpInfo( 11,  3500,  0, 2010,  4, 11, "Perfect D.R.C.P"),
			new JumpInfo( 12,  3500,  0, 2010,  4, 12, "Perfect D/P\nThat's all I've got to say about that!"),
			new JumpInfo( 13,  3500,  0, 2010,  5,  3, "Good exit into stable spread + arch, V.G reach, pull + recovery\nOn heading through out\nGATW\n3rd good DRCP + cleared for 3 second delay"),
			new JumpInfo( 14,  4200,  3, 2010,  5,  4, "Lost exit\nOn back on pull\nLook forward and up on exit\nTry 3 sec again"),
			new JumpInfo( 15,  4200,  3, 2010,  5,  8, "Perfect exit & deployment\nWell done"),
			new JumpInfo( 16,  4200,  3, 2010,  5,  8, "V.G.A.T.W\n5 sec next\nWell done"),
			new JumpInfo( 17,  4200,  5, 2010,  5,  8, "Perfect 5s delay\n/v.V.V.V.V.G.A.T.W\n10s next!"),
			new JumpInfo( 18,  4500, 10, 2010,  5,  8, "Perfect 10! V.V.V.V.G.A.T.W\n1 more!"),
			new JumpInfo( 19,  4500, 10, 2010,  5,  9, "And again...\nPerfect 10!!\n15s next!"),
			new JumpInfo( 20,  6000, 15, 2010,  5,  9, "Excellent 15 sec delay\n15 sec + alti next"),
			new JumpInfo( 21,  6000, 15, 2010,  5,  9, "Good exit & fallaway.\nSaw student check alti on way down. Good count\nPull on alti next!\nWell done!"),
			new JumpInfo( 22,  5500, 15, 2010,  5, 16, "Perfect straight delay.\nExcellet altitude awareness.\nTurns next!"),
			new JumpInfo( 23, 10000, 35, 2010,  5, 16, "Excellent exit, fallaway, right & left 360 turns\nGood alti awareness\nUnstable exit next"),
			new JumpInfo( 24,  9000, 30, 2010,  5, 22, "Very unstable exit!\nExcellent arch to recover after 5 seconds\nExcellent alti awareness, pull, recovery + canopy control.\nBackloops nexy"),
			new JumpInfo( 25,  8500, 25, 2010,  5, 23, "V. good exit & fallaway\n2 excellent bacloops\nGood alti awareness & good deployment at correct height + good c/c\nDive exit next"),
			new JumpInfo( 26, 10000, 35, 2010,  5, 30, "Good position in door & good dive except didn't duck legs up enough. Went into very steep & flipped over but otherise very controlled & stable throughout.\nGood canopy control - just watch flare\nDive exit + track on next jump"),
			new JumpInfo( 27, 10000, 35, 2010,  5, 31, "Perfect dive exit!\nExcellent heading control, and altitude awareness.\n2 very steep tracks.\n Godd pull recovery\nExcellent c/c.\nGo into track slower, to gain forward movement.\nTrack again next"),
			new JumpInfo( 28, 10000, 35, 2010,  5, 31, "Good exit\n2 excellent tracks\nExcellent A/A, pull + recovery\nTrack turns next!"),
			new JumpInfo( 29, 12500, 50, 2010,  8,  4, "Excellent exit! 2 excellent track turns to left + right!\nExcellent A/A, pull + c/c\nCat 8 next!"),
			new JumpInfo( 30,  8000, 25, 2010,  8,  4, "Exit from 8000ft due to cloud.\nAll manoeuvres completed, good throughout, and good alti awareness.\nWell done"),
			new JumpInfo( 31,  8000, 25, 2010,  8,  5, ""),
			new JumpInfo( 32,  6000, 15, 2010,  8,  7, ""),
			new JumpInfo( 33, 10000, 35, 2010,  8,  7, ""),
			new JumpInfo( 34, 13000, 60, 2010,  8, 17, ""),
			new JumpInfo( 35, 13000, 60, 2010,  8, 18, ""),
			new JumpInfo( 36, 13000, 60, 2010,  8, 19, ""),
			new JumpInfo( 37,  7800, 29, 2010, 10,  2, ""),
			new JumpInfo( 38,  2500,  3, 2010, 10, 10, ""),
			new JumpInfo( 39,  4580, 15, 2010, 10, 16, ""),
			new JumpInfo( 40,  4820, 16, 2010, 10, 16, ""),
			new JumpInfo( 41,  4860, 17, 2010, 10, 23, ""),
			new JumpInfo( 42,  5080, 18, 2010, 11, 27, ""),
			new JumpInfo( 43,  4860, 15, 2011,  1, 22, ""),
			new JumpInfo( 44,  6230, 22, 2011,  1, 23, ""),
			new JumpInfo( 45,  4860, 15, 2011,  1, 23, ""),
			new JumpInfo( 46,  4500, 11, 2011,  1, 29, ""),
			new JumpInfo( 47,  3210,  7, 2011,  1, 29, ""),
			new JumpInfo( 48,  4900, 18, 2011,  2,  5, ""),
			new JumpInfo( 49,  4370, 16, 2011,  2, 12, ""),
			new JumpInfo( 50,  8910, 34, 2011,  2, 26, ""),
			new JumpInfo( 51,  7000, 24, 2011,  2, 26, ""),
			new JumpInfo( 52, 10000, 35, 2011,  2, 27, ""),
			new JumpInfo( 53,  3140,  8, 2011,  3, 26, ""),
			new JumpInfo( 54,  4270, 13, 2011,  3, 26, ""),
			new JumpInfo( 55,  4990, 18, 2011,  3, 26, ""),
			new JumpInfo( 56,  2500,  3, 2011,  3, 26, ""),
			new JumpInfo( 57,  9480, 38, 2011,  3, 27, ""),
			new JumpInfo( 58, 10240, 44, 2011,  3, 27, ""),
			new JumpInfo( 59,  9730, 45, 2011,  3, 27, ""),
			new JumpInfo( 60, 12520, 57, 2011,  4,  1, ""),
			new JumpInfo( 61, 12700, 59, 2011,  4,  1, ""),
			new JumpInfo( 62, 12460, 55, 2011,  4,  1, ""),
			new JumpInfo( 63, 12680, 59, 2011,  4,  2, ""),
			new JumpInfo( 64, 12690, 59, 2011,  4,  2, ""),
			new JumpInfo( 65, 12700, 58, 2011,  4,  2, ""),
			new JumpInfo( 66, 12740, 58, 2011,  4,  2, ""),
			new JumpInfo( 67, 12520, 55, 2011,  4,  2, ""),
			new JumpInfo( 68,  5260, 19, 2011,  4,  3, ""),
			new JumpInfo( 69,  6890, 25, 2011,  4,  4, ""),
			new JumpInfo( 70, 12770, 61, 2011,  4,  4, ""),
			new JumpInfo( 71, 12850, 59, 2011,  4,  4, ""),
			new JumpInfo( 72, 12690, 60, 2011,  4,  4, ""),
			new JumpInfo( 73, 12650, 60, 2011,  4,  5, ""),
			new JumpInfo( 74, 12780, 59, 2011,  4,  5, ""),
			new JumpInfo( 75, 12460, 59, 2011,  4,  5, ""),
			new JumpInfo( 76, 12640, 59, 2011,  4,  5, ""),
			new JumpInfo( 77, 12850, 60, 2011,  4,  5, ""),
			new JumpInfo( 78, 13200, 62, 2011,  4,  9, ""),
			new JumpInfo( 79, 12620, 52, 2011,  4,  9, ""),
			new JumpInfo( 80, 12880, 60, 2011,  4,  9, ""),
			new JumpInfo( 81, 12560, 63, 2011,  4, 10, ""),
			new JumpInfo( 82, 12370, 59, 2011,  4, 10, ""),
			new JumpInfo( 83, 12470, 57, 2011,  4, 10, ""),
			new JumpInfo( 84, 12660, 61, 2011,  4, 10, ""),
			new JumpInfo( 85, 12700, 59, 2011,  4, 11, ""),
			new JumpInfo( 86, 12640, 58, 2011,  4, 11, ""),
			new JumpInfo( 87, 12780, 59, 2011,  4, 11, ""),
			new JumpInfo( 88, 12690, 61, 2011,  4, 11, ""),
			new JumpInfo( 89, 13920, 64, 2011,  4, 11, ""),
			new JumpInfo( 90, 12740, 58, 2011,  4, 12, ""),
			new JumpInfo( 91, 12680, 55, 2011,  4, 12, ""),
			new JumpInfo( 92, 18720, 90, 2011,  4, 14, ""),
			new JumpInfo( 93, 12820, 59, 2011,  4, 12, ""),
			new JumpInfo( 94, 12450, 58, 2011,  4, 12, ""),
			new JumpInfo( 95, 12590, 59, 2011,  4, 13, ""),
			new JumpInfo( 96, 12320, 56, 2011,  4, 13, ""),
			new JumpInfo( 97, 12760, 59, 2011,  4, 13, ""),
			new JumpInfo( 98,  4710, 16, 2011,  4, 24, ""),
			new JumpInfo( 99,  4160,  8, 2011,  4, 25, "chilled out"),
			new JumpInfo(100,  8060, 30, 2011,  5,  1, "few barrol rolls & backloops & turns\npuled high to try out new canopy\nlots of fun\nlanded in pit"),
			new JumpInfo(101,  9570, 40, 2011,  5,  1, "same as #100\nlanded hanger side of pit\nmake sure not to"),
			new JumpInfo(102,  5030, 18, 2011,  5,  1, "practice jump master & spotting\nspun about\nlanded in pit"),
			new JumpInfo(103,  9040, 38, 2011,  5,  1, "tracked"),
			new JumpInfo(104,  4070, 12, 2011,  5,  1, "rolled out plane"),
			new JumpInfo(105,  7360, 28, 2011,  5, 30, "good party night before so just relaxed\nmajor chill out, backloop for good measure\ntried different ways of turning"),
			new JumpInfo(106,  9820, 43, 2011,  5, 30, "two way with kelly\nneed to make better use of deep brakes if far out on deployment"),
			new JumpInfo(107,  2130,  7, 2011,  6,  4, "hop'n'pop"),
			new JumpInfo(108,  2400,  7, 2011,  6,  4, "hop'n'pop"),
			new JumpInfo(109,  4030, 11, 2011,  6,  4, "hop'n'pop"),
			new JumpInfo(110,  2370,  7, 2011,  6,  4, "hop'n'pop"),
			new JumpInfo(111,  2850,  8, 2011,  6,  5, "hop'n'pop"),
			new JumpInfo(112,  4090, 14, 2011,  6,  5, "hop'n'pop"),
			new JumpInfo(113,  4670, 16, 2011,  6, 25, "backloop that didn't go so well\nthen turned to check out others in freefall"),
			new JumpInfo(114,  3880, 12, 2011,  6, 25, "backloop exit turned into a barrel roll"),
			new JumpInfo(115,  9810, 47, 2011,  6, 25, "5 way speed star unlinked exit with john, sandy, jonny, kieran"),
			new JumpInfo(116,  2200,  5, 2011,  6, 26, "hop'n'pop"),
			new JumpInfo(117,  4870, 18, 2011,  7,  2, "3 way. Lost grips on exit"),
			new JumpInfo(118,  9590, 43, 2011,  7,  3, "2 way with sandy.\nDave filming"),
			new JumpInfo(119,  9960, 46, 2011,  7,  3, "3 way with sandy & gus. Got first two points good. Then gus forgot the third point and it sort of went tits up"),
			new JumpInfo(120,  9380, 44, 2011,  7,  3, "5 way with sandy, kelly, gus, steve"),
			new JumpInfo(121,  8980, 40, 2011,  7, 23, "spotting practical. Tracked"),
			new JumpInfo(122,  9400, 40, 2011,  7, 23, "3 way fs with sandy, gus. First two points good, then sandy got away from us"),
			new JumpInfo(123,  9550, 40, 2011,  7, 23, "4 way tracking dive with sandy, gus, steve. Gus went wrong way, rest of us stayed in the same vacinity"),
			new JumpInfo(124,  9880, 45, 2011,  7, 30, "4 way fs with alan, jo, ian\nBuilt star, broke apart, then build star again"),
			new JumpInfo(125,  4710, 16, 2011,  7, 30, "spotted, backloop"),
			new JumpInfo(126,  5000,  3, 2011,  8,  1, "first crew, two good docks, two spirals"),
			new JumpInfo(127,  6000,  3, 2011,  8,  2, "2 way crew, receiving"),
			new JumpInfo(128,  7000,  3, 2011,  8,  3, "3 way crew, docking third"),
			new JumpInfo(129,  7000,  3, 2011,  8,  3, "4 way crew, docking fourth"),
			new JumpInfo(130,  10000, 3, 2011,  8,  3, "9 way crew attempt\nDocked second, built 4 stack, paul got off top, piloted for the rest of the jump, mangage to get 6 in stack"),
			new JumpInfo(131,  10000, 3, 2011,  8,  3, "8 way crew attempt\nDocked third\nManaged to get 7 in the stack"),
			new JumpInfo(132,  7000,  3, 2011,  8,  4, "6 way crew attempt"),
			new JumpInfo(133,  7000,  3, 2011,  8,  4, "6 way crew attempt, clouds"),
			new JumpInfo(134, 11200, 54, 2011,  8,  5, "Carols 3 point 3 way, phil coaching\n2 points, really close to last point"),
			new JumpInfo(135,  8000,  3, 2011,  8,  5, "8 way crew\nDocked fourth"),
			new JumpInfo(136, 11360, 53, 2011,  8,  5, "Carols second 3 point 3 way, phil coaching\n5 points"),
			new JumpInfo(137, 10000,  3, 2011,  8,  5, "8 way crew\nDocked fourth instead of fifth because people weren't filling their slots"),
			new JumpInfo(138, 12500, 60, 2011,  8,  5, "Carols 4 point 3 way, greg coach\n4 points"),
			new JumpInfo(139, 13680, 60, 2011,  8,  5, "9 way tracking\nMega fun\nWas slightly behind"),
			new JumpInfo(140, 10140, 47, 2011,  8,  6, "Carols 4 way attempt"),
			new JumpInfo(141, 10360, 49, 2011,  8,  6, "Carols second 4 way attempt. Exit funnelled")
	};
	
	public void insert() {
		ContentResolver res = mResolver;

		Uri SPC    = res.insert(Places.CONTENT_URI, PLACES[0].getContentValues());
		Uri BKPC   = res.insert(Places.CONTENT_URI, PLACES[1].getContentValues());
		Uri Geese  = res.insert(Places.CONTENT_URI, PLACES[2].getContentValues());
		Uri Perris = res.insert(Places.CONTENT_URI, PLACES[3].getContentValues());

		Uri C206   = res.insert(Aircrafts.CONTENT_URI, AIRCRAFTS[0].getContentValues());
		Uri Porter = res.insert(Aircrafts.CONTENT_URI, AIRCRAFTS[1].getContentValues());
		Uri C208   = res.insert(Aircrafts.CONTENT_URI, AIRCRAFTS[2].getContentValues());
		Uri TwinOt = res.insert(Aircrafts.CONTENT_URI, AIRCRAFTS[3].getContentValues());
		Uri Skyvan = res.insert(Aircrafts.CONTENT_URI, AIRCRAFTS[4].getContentValues());
		Uri Baloon = res.insert(Aircrafts.CONTENT_URI, AIRCRAFTS[5].getContentValues());

		Uri Manta   = res.insert(Equipment.CONTENT_URI, EQUIPMENT[0].getContentValues());
		Uri Maveron = res.insert(Equipment.CONTENT_URI, EQUIPMENT[1].getContentValues());
		Uri PD      = res.insert(Equipment.CONTENT_URI, EQUIPMENT[2].getContentValues());
		Uri Balance = res.insert(Equipment.CONTENT_URI, EQUIPMENT[3].getContentValues());
		Uri Fury    = res.insert(Equipment.CONTENT_URI, EQUIPMENT[4].getContentValues());
		Uri Spectre = res.insert(Equipment.CONTENT_URI, EQUIPMENT[5].getContentValues());
		Uri Triatha = res.insert(Equipment.CONTENT_URI, EQUIPMENT[6].getContentValues());

		JUMPS[1  ].setValues(SPC,    C206,   Manta);
		JUMPS[2  ].setValues(SPC,    C206,   Manta);
		JUMPS[3  ].setValues(SPC,    C206,   Manta);
		JUMPS[4  ].setValues(SPC,    C206,   Manta);
		JUMPS[5  ].setValues(SPC,    C206,   Manta);
		JUMPS[6  ].setValues(SPC,    C206,   Manta);
		JUMPS[7  ].setValues(SPC,    C206,   Manta);
		JUMPS[8  ].setValues(SPC,    C206,   Manta);
		JUMPS[9  ].setValues(SPC,    C206,   Manta);
		JUMPS[10 ].setValues(SPC,    C206,   Manta);
		JUMPS[11 ].setValues(SPC,    C206,   Manta);
		JUMPS[12 ].setValues(SPC,    C206,   Manta);
		JUMPS[13 ].setValues(BKPC,   Porter, Manta);
		JUMPS[14 ].setValues(BKPC,   Porter, Manta);
		JUMPS[15 ].setValues(SPC,    C206,   Manta);
		JUMPS[16 ].setValues(SPC,    C206,   Manta);
		JUMPS[17 ].setValues(SPC,    C206,   Manta);
		JUMPS[18 ].setValues(SPC,    C206,   Manta);
		JUMPS[19 ].setValues(SPC,    C206,   Manta);
		JUMPS[20 ].setValues(SPC,    C206,   Manta);
		JUMPS[21 ].setValues(SPC,    C206,   Manta);
		JUMPS[22 ].setValues(SPC,    C206,   Manta);
		JUMPS[23 ].setValues(SPC,    C206,   Manta);
		JUMPS[24 ].setValues(SPC,    C206,   Manta);
		JUMPS[25 ].setValues(SPC,    C206,   Manta);
		JUMPS[26 ].setValues(SPC,    C206,   Manta);
		JUMPS[27 ].setValues(SPC,    C206,   Manta);
		JUMPS[28 ].setValues(SPC,    C206,   Manta);
		JUMPS[29 ].setValues(SPC,    Porter, Manta);
		JUMPS[30 ].setValues(SPC,    C206,   Manta);
		JUMPS[31 ].setValues(SPC,    C206,   Manta);
		JUMPS[32 ].setValues(SPC,    C206,   Manta);
		JUMPS[33 ].setValues(SPC,    C206,   Manta);
		JUMPS[34 ].setValues(Geese,  C208,   Maveron);
		JUMPS[35 ].setValues(Geese,  C208,   Maveron);
		JUMPS[36 ].setValues(Geese,  C208,   PD);
		JUMPS[37 ].setValues(SPC,    C206,   Manta);
		JUMPS[38 ].setValues(SPC,    C206,   Manta);
		JUMPS[39 ].setValues(SPC,    C206,   Manta);
		JUMPS[40 ].setValues(SPC,    C206,   Manta);
		JUMPS[41 ].setValues(SPC,    C206,   Manta);
		JUMPS[42 ].setValues(SPC,    C206,   Manta);
		JUMPS[43 ].setValues(SPC,    C206,   Manta);
		JUMPS[44 ].setValues(SPC,    C206,   Manta);
		JUMPS[45 ].setValues(SPC,    C206,   Manta);
		JUMPS[46 ].setValues(SPC,    C206,   Manta);
		JUMPS[47 ].setValues(SPC,    C206,   Manta);
		JUMPS[48 ].setValues(SPC,    C206,   Manta);
		JUMPS[49 ].setValues(SPC,    C206,   Manta);
		JUMPS[50 ].setValues(SPC,    C206,   Manta);
		JUMPS[51 ].setValues(SPC,    C206,   Manta);
		JUMPS[52 ].setValues(SPC,    C206,   Manta);
		JUMPS[53 ].setValues(SPC,    C206,   Balance);
		JUMPS[54 ].setValues(SPC,    C206,   Balance);
		JUMPS[55 ].setValues(SPC,    C206,   Fury);
		JUMPS[56 ].setValues(SPC,    C206,   Balance);
		JUMPS[57 ].setValues(SPC,    C206,   Balance);
		JUMPS[58 ].setValues(SPC,    C206,   Balance);
		JUMPS[59 ].setValues(SPC,    C206,   Balance);
		JUMPS[60 ].setValues(Perris, TwinOt, Balance);
		JUMPS[61 ].setValues(Perris, TwinOt, Balance);
		JUMPS[62 ].setValues(Perris, TwinOt, Balance);
		JUMPS[63 ].setValues(Perris, TwinOt, Balance);
		JUMPS[64 ].setValues(Perris, Skyvan, Balance);
		JUMPS[65 ].setValues(Perris, Skyvan, Balance);
		JUMPS[66 ].setValues(Perris, TwinOt, Balance);
		JUMPS[67 ].setValues(Perris, TwinOt, Balance);
		JUMPS[68 ].setValues(Perris, TwinOt, Balance);
		JUMPS[69 ].setValues(Perris, Baloon, Balance);
		JUMPS[70 ].setValues(Perris, TwinOt, Balance);
		JUMPS[71 ].setValues(Perris, Skyvan, Balance);
		JUMPS[72 ].setValues(Perris, TwinOt, Balance);
		JUMPS[73 ].setValues(Perris, TwinOt, Balance);
		JUMPS[74 ].setValues(Perris, TwinOt, Balance);
		JUMPS[75 ].setValues(Perris, TwinOt, Balance);
		JUMPS[76 ].setValues(Perris, TwinOt, Balance);
		JUMPS[77 ].setValues(Perris, TwinOt, Balance);
		JUMPS[78 ].setValues(Perris, TwinOt, Balance);
		JUMPS[79 ].setValues(Perris, Skyvan, Balance);
		JUMPS[80 ].setValues(Perris, Skyvan, Balance);
		JUMPS[81 ].setValues(Perris, Skyvan, Balance);
		JUMPS[82 ].setValues(Perris, TwinOt, Balance);
		JUMPS[83 ].setValues(Perris, Skyvan, Balance);
		JUMPS[84 ].setValues(Perris, TwinOt, Balance);
		JUMPS[85 ].setValues(Perris, TwinOt, Balance);
		JUMPS[86 ].setValues(Perris, Skyvan, Balance);
		JUMPS[87 ].setValues(Perris, Skyvan, Balance);
		JUMPS[88 ].setValues(Perris, TwinOt, Balance);
		JUMPS[89 ].setValues(Perris, TwinOt, Balance);
		JUMPS[90 ].setValues(Perris, TwinOt, Balance);
		JUMPS[91 ].setValues(Perris, Skyvan, Balance);
		JUMPS[92 ].setValues(Perris, Skyvan, Balance);
		JUMPS[93 ].setValues(Perris, TwinOt, Balance);
		JUMPS[94 ].setValues(Perris, TwinOt, Balance);
		JUMPS[95 ].setValues(Perris, TwinOt, Balance);
		JUMPS[96 ].setValues(Perris, TwinOt, Balance);
		JUMPS[97 ].setValues(Perris, TwinOt, Balance);
		JUMPS[98 ].setValues(SPC,    C206,   Balance);
		JUMPS[99 ].setValues(SPC,    C206,   Fury);
		JUMPS[100].setValues(SPC,    C206,   Spectre);
		JUMPS[101].setValues(SPC,    C206,   Spectre);
		JUMPS[102].setValues(SPC,    C206,   Spectre);
		JUMPS[103].setValues(SPC,    C206,   Spectre);
		JUMPS[104].setValues(SPC,    C206,   Spectre);
		JUMPS[105].setValues(SPC,    C206,   Spectre);
		JUMPS[106].setValues(SPC,    C206,   Spectre);
		JUMPS[107].setValues(SPC,    C206,   Spectre);
		JUMPS[108].setValues(SPC,    C206,   Spectre);
		JUMPS[109].setValues(SPC,    C206,   Spectre);
		JUMPS[110].setValues(SPC,    C206,   Spectre);
		JUMPS[111].setValues(SPC,    C206,   Spectre);
		JUMPS[112].setValues(SPC,    C206,   Spectre);
		JUMPS[113].setValues(SPC,    C206,   Spectre);
		JUMPS[114].setValues(SPC,    C206,   Spectre);
		JUMPS[115].setValues(SPC,    C206,   Spectre);
		JUMPS[116].setValues(SPC,    C206,   Spectre);
		JUMPS[117].setValues(SPC,    C206,   Spectre);
		JUMPS[118].setValues(SPC,    C206,   Spectre);
		JUMPS[119].setValues(SPC,    C206,   Spectre);
		JUMPS[120].setValues(SPC,    C206,   Spectre);
		JUMPS[121].setValues(SPC,    C206,   Spectre);
		JUMPS[122].setValues(SPC,    C206,   Spectre);
		JUMPS[123].setValues(SPC,    C206,   Spectre);
		JUMPS[124].setValues(SPC,    C206,   Spectre);
		JUMPS[125].setValues(SPC,    C206,   Spectre);
		JUMPS[126].setValues(SPC,    Porter, Triatha);
		JUMPS[127].setValues(SPC,    Porter, Triatha);
		JUMPS[128].setValues(SPC,    Porter, Triatha);
		JUMPS[129].setValues(SPC,    Porter, Triatha);
		JUMPS[130].setValues(SPC,    Porter, Triatha);
		JUMPS[131].setValues(SPC,    Porter, Triatha);
		JUMPS[132].setValues(SPC,    Porter, Triatha);
		JUMPS[133].setValues(SPC,    Porter, Triatha);
		JUMPS[134].setValues(SPC,    Porter, Spectre);
		JUMPS[135].setValues(SPC,    Porter, Triatha);
		JUMPS[136].setValues(SPC,    Porter, Spectre);
		JUMPS[137].setValues(SPC,    Porter, Triatha);
		JUMPS[138].setValues(SPC,    Porter, Spectre);
		JUMPS[139].setValues(SPC,    Porter, Spectre);
		JUMPS[139].setValues(SPC,    Porter, Spectre);
		JUMPS[140].setValues(SPC,    C206,   Spectre);
		JUMPS[141].setValues(SPC,    C206,   Spectre);

		ContentValues[] jumpsValues = new ContentValues[JUMPS.length];
		for (int index = 0; index < JUMPS.length; index++) {
			jumpsValues[index] = JUMPS[index].getContentValues();
        }
		res.bulkInsert(Jumps.CONTENT_URI, jumpsValues);
	}

	public TestData(Activity activity) {
		mResolver = activity.getContentResolver();
		delete();
		insert();
	}

	public void delete() {
		ContentResolver resolver = mResolver;
		resolver.delete(Jumps.CONTENT_URI, null, null);
		resolver.delete(Places.CONTENT_URI, null, null);
		resolver.delete(Aircrafts.CONTENT_URI, null, null);
		resolver.delete(Equipment.CONTENT_URI, null, null);
	}

	private static class PlaceInfo {
		String place_name;
		
		public PlaceInfo(String name) {
			this.place_name = name;
		}
		
		public ContentValues getContentValues() {
			ContentValues v = new ContentValues();
			v.put(Places.PLACE_NAME, place_name);
			return v;
		}
	}

	private static class AircraftInfo {
		String aircraft_name;
		
		public AircraftInfo(String name) {
			this.aircraft_name = name;
		}
		
		public ContentValues getContentValues() {
			ContentValues v = new ContentValues();
			v.put(Aircrafts.AIRCRAFT_NAME, aircraft_name);
			return v;
		}
	}

	private static class EquipmentInfo {
		String equipment_canopy_name;
		int equipment_canopy_size;
		
		public EquipmentInfo(String name, int size) {
			this.equipment_canopy_name = name;
			this.equipment_canopy_size = size;
		}
		
		public ContentValues getContentValues() {
			ContentValues v = new ContentValues();
			v.put(Equipment.EQUIPMENT_CANOPY_NAME, equipment_canopy_name);
			v.put(Equipment.EQUIPMENT_CANOPY_SIZE, equipment_canopy_size);
			return v;
		}
	}

	private static class JumpInfo {
		int place_id;
		int aircraft_id;
		int equipment_id;
		int jump_number;
		long jump_date;
		int jump_altitude;
		int jump_delay;
		String jump_description;
		
		public JumpInfo(int number, int altitude, int delay, int jYear, int jMonth, int jDay, String description) {
			this.place_id = 0;
			this.aircraft_id = 0;
			this.equipment_id = 0;
			this.jump_number = number;
			Time time = new Time();
			time.set(jDay, jMonth - 1, jYear);
			this.jump_date = time.toMillis(false);
			this.jump_altitude = altitude;
			this.jump_delay = delay;
			this.jump_description = description;
		}
		
		public ContentValues getContentValues() {
			ContentValues v = new ContentValues();
			v.put(Jumps.PLACE_ID, place_id);
			v.put(Jumps.AIRCRAFT_ID, aircraft_id);
			v.put(Jumps.EQUIPMENT_ID, equipment_id);
			v.put(Jumps.JUMP_NUMBER, jump_number);
			v.put(Jumps.JUMP_DATE, jump_date);
			v.put(Jumps.JUMP_ALTITUDE, jump_altitude);
			v.put(Jumps.JUMP_DELAY, jump_delay);
			v.put(Jumps.JUMP_DESCRIPTION, jump_description);
			return v;
		}
		
		public void setValues(Uri placeUri, Uri aircraftUri, Uri equipmentUri) {
			this.place_id = Integer.valueOf(Places.getPlaceId(placeUri));
			this.aircraft_id = Integer.valueOf(Aircrafts.getAircraftId(aircraftUri));
			this.equipment_id = Integer.valueOf(Equipment.getEquipmentId(equipmentUri));
		}
	}
}
