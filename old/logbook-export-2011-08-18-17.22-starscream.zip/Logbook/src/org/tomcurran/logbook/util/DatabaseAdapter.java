package org.tomcurran.logbook.util;

import android.content.Context;
import android.database.Cursor;

import org.tomcurran.logbook.provider.LogbookContract.Jumps;

import java.util.Calendar;

public class DatabaseAdapter {


    private static final String[] HIGHEST_JUMP_NUMBER_PROJECTION = { Jumps.JUMP_NUMBER };

	public static int getHighestJumpNumber(Context context) {
    	final Cursor jump = context.getContentResolver().query(
                Jumps.CONTENT_URI,
                HIGHEST_JUMP_NUMBER_PROJECTION,
                null,
                null,
                Jumps.JUMP_NUMBER + " DESC LIMIT 1"
        );
    	return jump.moveToFirst() ? jump.getInt(jump.getColumnIndexOrThrow(Jumps.JUMP_NUMBER)) : 0;
    }


	private static final String[] COUNT_PROJECTION = { "count(*)" };
	private static final String COUNT_WHERE = Jumps.JUMP_DATE + ">=?";

	public static int getJumpCountLastMonths(Context context, int months) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, -months);
		final Cursor jumps = context.getContentResolver().query(
				Jumps.CONTENT_URI,
				COUNT_PROJECTION,
				COUNT_WHERE,
				new String[] { String.valueOf(calendar.getTimeInMillis()) },
				Jumps.DEFAULT_SORT
		);
		return jumps.moveToFirst() ? jumps.getInt(0) : 0;
	}


	private static final String[] DELAY_PROJECTION = { "sum(" + Jumps.JUMP_DELAY + ")" };

	public static int getTotalDelay(Context context) {
		final Cursor jumps = context.getContentResolver().query(
				Jumps.CONTENT_URI,
				DELAY_PROJECTION,
				null,
				null,
				Jumps.DEFAULT_SORT
		);
		return jumps.moveToFirst() ? jumps.getInt(0) : 0;
	}


    private static final String ALTITUDE_SELECTION = Jumps.JUMP_ALTITUDE + ">?";
    private static final String[] ALTITUDE_SELECTION_ARGS = { "0" };

	private static int getAltitude(Context context, final String aggregate) {
		final String[] projection = { aggregate + "(" + Jumps.JUMP_ALTITUDE + ")" };
		final Cursor cursor = context.getContentResolver().query(
                Jumps.CONTENT_URI,
                projection,
                ALTITUDE_SELECTION,
                ALTITUDE_SELECTION_ARGS,
                Jumps.DEFAULT_SORT
        );
		return cursor.moveToFirst() ? cursor.getInt(0) : 0;
	}

	public static int getHeightestAltitude(Context context) {
		return getAltitude(context, "max");
	}

	public static int getLowestAltitude(Context context) {
		return getAltitude(context, "min");
	}

	public static int getAverageAltitude(Context context) {
		return getAltitude(context, "avg");
	}
}