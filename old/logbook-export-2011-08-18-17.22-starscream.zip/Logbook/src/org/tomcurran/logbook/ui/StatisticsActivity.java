package org.tomcurran.logbook.ui;

import android.support.v4.app.Fragment;

import org.tomcurran.logbook.ui.fragments.StatisticsFragment;

public class StatisticsActivity extends BaseSinglePaneActivity {

	@Override
	protected Fragment onCreatePane() {
		return new StatisticsFragment();
	}

}
