package org.tomcurran.logbook.ui.fragments;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.ActionBar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.view.Menu;
import android.support.v4.widget.SimpleCursorAdapter;
import android.text.format.Time;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.DatePicker;
import android.widget.DatePicker.OnDateChangedListener;
import android.widget.Spinner;
import android.widget.TextView;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Aircrafts;
import org.tomcurran.logbook.provider.LogbookContract.Equipment;
import org.tomcurran.logbook.provider.LogbookContract.Jumps;
import org.tomcurran.logbook.provider.LogbookContract.Places;
import org.tomcurran.logbook.ui.BaseActivity;
import org.tomcurran.logbook.ui.HomeActivity;
import org.tomcurran.logbook.ui.widget.AddSpinner;
import org.tomcurran.logbook.util.DatabaseAdapter;
import org.tomcurran.logbook.util.UIUtils;

public class JumpEditFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {

    private static final int LOADER_PLACES = 0;
    private static final int LOADER_AIRCRAFTS = 1;
    private static final int LOADER_EQUIPMENT = 2;
    private static final String[] JUMP_PROJECTION = {
	        Jumps.JUMP_NUMBER,
	        Jumps.JUMP_DATE,
	        Jumps.PLACE_ID,
	        Jumps.AIRCRAFT_ID,
	        Jumps.EQUIPMENT_ID,
	        Jumps.JUMP_ALTITUDE,
	        Jumps.JUMP_DELAY,
	        Jumps.JUMP_DESCRIPTION,
	        Jumps._ID
    };
    private static final String[] PLACES_PROJECTION = {
	        Places.PLACE_NAME,
	        Places._ID
    };
    private static final String[] AIRCRAFTS_PROJECTION = {
	        Aircrafts.AIRCRAFT_NAME,
	        Aircrafts._ID
	};
	private static final String[] EQUIPMENT_PROJECTION = {
	        Equipment.EQUIPMENT_CANOPY_NAME,
	        Equipment.EQUIPMENT_CANOPY_SIZE,
	        Equipment._ID
	};

    private Long mRowId;
    private Long mPlaceId;
    private Long mAircraftId;
    private Long mEquipmentId;
    private TextView mJumpNumText;
    private DatePicker mDatePicker;
    private AddSpinner mPlaceSpinner;
    private AddSpinner mAircraftSpinner;
    private AddSpinner mEquipmentSpinner;
    private TextView mAltitudeText;
    private TextView mDelayText;
    private TextView mDescriptionText;
    private Time time;
    private OnDateChangedListener mDateChangedListener = new OnDateChangedListener() {
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                time.set(dayOfMonth, monthOfYear, year);
            }
    };
    private BaseDialogFragment.OnSuccessListener mPlaceOnSuccessListener = new BaseDialogFragment.OnSuccessListener() {
		@Override
		public void onSuccess(Long id) {
			mPlaceId = id;
			getLoaderManager().restartLoader(LOADER_PLACES, null, JumpEditFragment.this);
		}
	};
    private BaseDialogFragment.OnSuccessListener mAircraftOnSuccessListener = new BaseDialogFragment.OnSuccessListener() {
		@Override
		public void onSuccess(Long id) {
			mAircraftId = id;
			getLoaderManager().restartLoader(LOADER_AIRCRAFTS, null, JumpEditFragment.this);
		}
	};
    private BaseDialogFragment.OnSuccessListener mEquipmentOnSuccessListener = new BaseDialogFragment.OnSuccessListener() {
		@Override
		public void onSuccess(Long id) {
			mEquipmentId = id;
			getLoaderManager().restartLoader(LOADER_EQUIPMENT, null, JumpEditFragment.this);
		}
	};
    private AddSpinner.OnAddClickListener mOnAddListener = new AddSpinner.OnAddClickListener() {
		@Override
		public void onAddClick(Spinner spinner) {
			switch (spinner.getId()) {
			case R.id.spinner_edit_jump_place:
				new PlaceDialogFragment(null, mPlaceOnSuccessListener)
						.show(getFragmentManager(), PlaceDialogFragment.TAG);
				break;
			case R.id.spinner_edit_jump_aircraft:
				new AircraftDialogFragment(null, mAircraftOnSuccessListener)
						.show(getFragmentManager(), AircraftDialogFragment.TAG);
				break;
			case R.id.spinner_edit_jump_equipment:
				new EquipmentDialogFragment(null, mEquipmentOnSuccessListener)
						.show(getFragmentManager(), EquipmentDialogFragment.TAG);
				break;
			}
		}
	};


    // life cycle

    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    	return inflater.inflate(R.layout.fragment_edit_jump, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
    	super.onActivityCreated(savedInstanceState);

        FragmentActivity activity = getActivity();
        ActionBar ab = activity.getSupportActionBar();

        ab.setTitle(R.string.title_create_jump);
        ab.setDisplayHomeAsUpEnabled(true);

        mJumpNumText = (TextView) activity.findViewById(R.id.text_edit_jump_number);
        mDatePicker = (DatePicker) activity.findViewById(R.id.date_edit_jump_date);
        mPlaceSpinner = (AddSpinner) activity.findViewById(R.id.spinner_edit_jump_place);
        mAircraftSpinner = (AddSpinner) activity.findViewById(R.id.spinner_edit_jump_aircraft);
        mEquipmentSpinner = (AddSpinner) activity.findViewById(R.id.spinner_edit_jump_equipment);
        mAltitudeText = (TextView) activity.findViewById(R.id.text_edit_jump_altitude);
        mDelayText = (TextView) activity.findViewById(R.id.text_edit_jump_delay);
        mDescriptionText = (TextView) activity.findViewById(R.id.text_edit_jump_description);

        setupAddSpinner(
        		mPlaceSpinner,
        		R.string.prompt_edit_jump_places,
        		new BaseAdapter(activity, PLACES_PROJECTION),
        		LOADER_PLACES
        );
        
        setupAddSpinner(
        		mAircraftSpinner,
        		R.string.prompt_edit_jump_aircrafts,
        		new BaseAdapter(activity, AIRCRAFTS_PROJECTION),
        		LOADER_AIRCRAFTS
        );
        
        setupAddSpinner(
        		mEquipmentSpinner,
        		R.string.prompt_edit_jump_equipment,
        		new EquipmentAdapter(activity),
        		LOADER_EQUIPMENT
        );

        time = new Time();

        if (savedInstanceState == null) {
        	Bundle args = getArguments();
    		long jumpId = args.getLong(Jumps._ID, 0);
    		mRowId = jumpId != 0 ? jumpId : null;
        } else {
        	mRowId = (Long) savedInstanceState.getSerializable(Jumps._ID);
        }

        populateFields();
    }

    @Override
    public void onResume() {
    	super.onResume();
        populateFields();
    }

    @Override
    public void onPause() {
    	super.onPause();
        saveState();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
    	super.onSaveInstanceState(outState);
        saveState();
        outState.putSerializable(Jumps._ID, mRowId);
    }


    // options menu

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
    	inflater.inflate(R.menu.options_menu_edit_jump, menu);
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
    	switch (item.getItemId()) {
		case android.R.id.home:
			((BaseActivity)getActivity()).goUp(HomeActivity.class);
			return true;
		case R.id.options_menu_edit_jump_delete:
	        FragmentActivity activity = getActivity();
	        saveState();
	        activity.getContentResolver().delete(Jumps.buildJumpUri(mRowId), null, null);
            activity.finish();
			return false;
		default:
	    	return super.onOptionsItemSelected(item);
		}
    }


    // helpers

    public void populateFields() {
        FragmentActivity activity = getActivity();
    	if (mRowId != null) {
            Cursor jump = activity.getContentResolver().query(
                    Jumps.buildJumpUri(mRowId),
                    JUMP_PROJECTION,
                    null,
                    null,
                    Jumps.DEFAULT_SORT
            );
            if (jump.moveToFirst()) {
                int jump_num_column = jump.getColumnIndexOrThrow(Jumps.JUMP_NUMBER);
                activity.getSupportActionBar().setTitle(getString(R.string.title_edit_jump, jump.getInt(jump_num_column)));
                mJumpNumText.setText( jump.getString(jump_num_column));
                time.set(jump.getLong(jump.getColumnIndexOrThrow(Jumps.JUMP_DATE)));
                mDatePicker.init(time.year, time.month, time.monthDay, mDateChangedListener);
                mPlaceId = jump.getLong(jump.getColumnIndexOrThrow(Jumps.PLACE_ID));
                mAircraftId = jump.getLong(jump.getColumnIndexOrThrow(Jumps.AIRCRAFT_ID));
                mEquipmentId = jump.getLong(jump.getColumnIndexOrThrow(Jumps.EQUIPMENT_ID));                
                mAltitudeText.setText(jump.getString(jump.getColumnIndexOrThrow(Jumps.JUMP_ALTITUDE)));
                mDelayText.setText(jump.getString(jump.getColumnIndexOrThrow(Jumps.JUMP_DELAY)));
                mDescriptionText.setText(jump.getString(jump.getColumnIndexOrThrow(Jumps.JUMP_DESCRIPTION)));
            }
        } else {
        	// TODO default spinners
        	activity.invalidateOptionsMenu();
        	
        	SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        	time.setToNow();
            
        	mJumpNumText.setText(String.valueOf(DatabaseAdapter.getHighestJumpNumber(activity) + 1));
            mDatePicker.init(time.year, time.month, time.monthDay, mDateChangedListener);
            mDelayText.setText(prefs.getString("default_jump_delay", ""));
            mAltitudeText.setText(prefs.getString("default_jump_altitude", ""));
        }
	}

    private void saveState() {
        ContentResolver resolver = getActivity().getContentResolver();
        ContentValues values = new ContentValues();

        values.put(Jumps.JUMP_NUMBER, UIUtils.parseTextViewInt(mJumpNumText));
        values.put(Jumps.JUMP_DATE, time.toMillis(false));
        values.put(Jumps.PLACE_ID, mPlaceId);
        values.put(Jumps.AIRCRAFT_ID, mAircraftId);
        values.put(Jumps.EQUIPMENT_ID, mEquipmentId);
        values.put(Jumps.JUMP_ALTITUDE, UIUtils.parseTextViewInt(mAltitudeText));
        values.put(Jumps.JUMP_DELAY, UIUtils.parseTextViewInt(mDelayText));
        values.put(Jumps.JUMP_DESCRIPTION, mDescriptionText.getText().toString());
        
        if (mRowId == null) {
            Uri jump = resolver.insert(Jumps.CONTENT_URI, values);
            long id = Long.valueOf(Jumps.getJumpId(jump));
            if (id > 0) {
                mRowId = id;
            }
        } else {
            resolver.update(
                    Jumps.buildJumpUri(mRowId),
                    values,
                    null,
                    null
            );
        }
    }

    public void setupAddSpinner(AddSpinner spinner, int promtRes, SimpleCursorAdapter adapter, final int loader) {
    	spinner.setPromptId(promtRes);
    	spinner.setAdapter(adapter);
    	spinner.setOnItemSelectedListener(new BaseOnItemSelectedListener());
    	spinner.setOnAddListener(mOnAddListener);
        getLoaderManager().initLoader(loader, null, this);
    }


    // adapters
    
    public static class BaseAdapter extends SimpleCursorAdapter {

        private final static int[] TO = new int[] {
            android.R.id.text1
        };

        public BaseAdapter(Context context, final String[] projection) {
            super(context, android.R.layout.simple_spinner_item, null, projection, BaseAdapter.TO, 0);
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        }

    }

    public static class EquipmentAdapter extends BaseAdapter {
        
        public EquipmentAdapter(Context context) {
            super(context, EQUIPMENT_PROJECTION);
        }
        
        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            super.bindView(view, context, cursor);

            TextView text1 = (TextView) view.findViewById(android.R.id.text1);

            String canopy_name = cursor.getString(cursor.getColumnIndex(Equipment.EQUIPMENT_CANOPY_NAME));
            int canopy_size = cursor.getInt(cursor.getColumnIndex(Equipment.EQUIPMENT_CANOPY_SIZE));        
            
            text1.setText(canopy_name + " " + canopy_size);
        }
    }


    // listeners

    public class BaseOnItemSelectedListener implements OnItemSelectedListener {

        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
            switch (parent.getId()) {
            case R.id.spinner_edit_jump_place:
                mPlaceId = id;
                break;
            case R.id.spinner_edit_jump_aircraft:
                mAircraftId = id;
                break;
            case R.id.spinner_edit_jump_equipment:
                mEquipmentId = id;
                break;
            }
        }

        public void onNothingSelected(AdapterView<?> parent) {}
    }


    // loaders

    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        switch (id) {
        case LOADER_PLACES:
            return new CursorLoader(
                    getActivity(),
                    Places.CONTENT_URI,
                    PLACES_PROJECTION,
                    null,
                    null,
                    Places.DEFAULT_SORT
            );
        case LOADER_AIRCRAFTS:
            return new CursorLoader(
                    getActivity(),
                    Aircrafts.CONTENT_URI,
                    AIRCRAFTS_PROJECTION,
                    null,
                    null,
                    Aircrafts.DEFAULT_SORT
            );
        case LOADER_EQUIPMENT:
            return new CursorLoader(
                    getActivity(),
                    Equipment.CONTENT_URI,
                    EQUIPMENT_PROJECTION,
                    null,
                    null,
                    Equipment.DEFAULT_SORT
            );
        default:
            return null;
        }
    }

    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        switch (loader.getId()) {
        case LOADER_PLACES:
        	AddSpinner placeSpinner = (AddSpinner)mPlaceSpinner;
        	((SimpleCursorAdapter)placeSpinner.getAdapter()).swapCursor(data);
        	placeSpinner.setSelectionDbRow(mPlaceId, Places._ID);
            break;
        case LOADER_AIRCRAFTS:
        	AddSpinner aircraftSpinner = (AddSpinner)mAircraftSpinner;
        	((SimpleCursorAdapter)aircraftSpinner.getAdapter()).swapCursor(data);
        	aircraftSpinner.setSelectionDbRow(mAircraftId, Aircrafts._ID);
            break;
        case LOADER_EQUIPMENT:
        	AddSpinner equipmentSpinner = (AddSpinner)mEquipmentSpinner;
        	((SimpleCursorAdapter)equipmentSpinner.getAdapter()).swapCursor(data);
        	equipmentSpinner.setSelectionDbRow(mEquipmentId, Equipment._ID);
            break;
        }
    }

    public void onLoaderReset(Loader<Cursor> loader) {
        switch (loader.getId()) {
        case LOADER_PLACES:
        	((SimpleCursorAdapter)mPlaceSpinner.getAdapter()).swapCursor(null);
            break;
        case LOADER_AIRCRAFTS:
        	((SimpleCursorAdapter)mAircraftSpinner.getAdapter()).swapCursor(null);
            break;
        case LOADER_EQUIPMENT:
        	((SimpleCursorAdapter)mEquipmentSpinner.getAdapter()).swapCursor(null);
            break;
        }
    }

}
