package org.tomcurran.logbook.ui.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.ui.BaseActivity;
import org.tomcurran.logbook.ui.HomeActivity;
import org.tomcurran.logbook.util.DatabaseAdapter;
import org.tomcurran.logbook.util.UIUtils;

import java.text.NumberFormat;

public class StatisticsFragment extends Fragment {

	private static final String FT = " ft";
	private static NumberFormat nf = NumberFormat.getIntegerInstance();

	// life cycle

    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setHasOptionsMenu(true);
    }

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflater.inflate(R.layout.fragment_statistics, container, false);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		FragmentActivity activity = getActivity();

        activity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

		TextView jumpNumbersText = (TextView) activity.findViewById(R.id.text_stat_jump_numbers);
		TextView totalDelayText = (TextView) activity.findViewById(R.id.text_total_delay);
		TextView altitudeText = (TextView) activity.findViewById(R.id.text_stat_altitude);

		jumpNumbersText.setText(getString(R.string.text_stat_jump_numbers,
				DatabaseAdapter.getJumpCountLastMonths(activity, 6),
				DatabaseAdapter.getJumpCountLastMonths(activity, 12),
				DatabaseAdapter.getJumpCountLastMonths(activity, 18),
				DatabaseAdapter.getJumpCountLastMonths(activity, 24)));
		totalDelayText.setText(getString(R.string.text_total_delay,
				UIUtils.formatSeconds(activity, DatabaseAdapter.getTotalDelay(activity))));
		altitudeText.setText(getString(R.string.text_stat_altitude,
				nf.format(DatabaseAdapter.getHeightestAltitude(activity)) + FT,
				nf.format(DatabaseAdapter.getLowestAltitude(activity)) + FT,
				nf.format(DatabaseAdapter.getAverageAltitude(activity)) + FT));
	}


	// Options menu

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			((BaseActivity)getActivity()).goUp(HomeActivity.class);
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}
}
