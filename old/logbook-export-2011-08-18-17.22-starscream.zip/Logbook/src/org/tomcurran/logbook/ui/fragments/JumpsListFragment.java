package org.tomcurran.logbook.ui.fragments;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.ListFragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.view.Menu;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter;
import android.text.format.DateFormat;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.widget.TextView;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Aircrafts;
import org.tomcurran.logbook.provider.LogbookContract.Jumps;
import org.tomcurran.logbook.provider.LogbookContract.Places;
import org.tomcurran.logbook.ui.JumpEditActivity;
import org.tomcurran.logbook.ui.JumpPreferenceActivity;
import org.tomcurran.logbook.ui.StatisticsActivity;
import org.tomcurran.logbook.util.UIUtils;

import java.text.NumberFormat;

public class JumpsListFragment extends ListFragment implements LoaderManager.LoaderCallbacks<Cursor>  {

	private static final int ACTIVITY_CREATE = 0;
	private static final int ACTIVITY_EDIT = 1;

	private static final int LOADER_JUMPS = 0;

	private static final String[] PROJECTION = new String[] {
		Jumps.JUMP_NUMBER,
		Jumps.JUMP_DATE,
		Places.PLACE_NAME,
		Aircrafts.AIRCRAFT_NAME,
		Jumps.JUMP_ALTITUDE,
		Jumps.JUMP_DESCRIPTION,
		Jumps._ID
	};

	private CursorAdapter mAdapter;


	// life cycle

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflater.inflate(R.layout.fragment_list_jumps, container, false);
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		FragmentActivity activity = getActivity();
		activity.getSupportActionBar().setTitle(R.string.title_jumps_list);
		registerForContextMenu(getListView());
		mAdapter = new JumpsListAdapter(activity);
		setListAdapter(mAdapter);
        getLoaderManager().initLoader(LOADER_JUMPS, null, this);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		getLoaderManager().restartLoader(LOADER_JUMPS, null, this);
	}


	// Options menu

	@Override
	public void onCreateOptionsMenu(Menu menu, android.view.MenuInflater inflater) {
		inflater.inflate(R.menu.options_menu_list_jumps, menu);
	}

	@Override
	public boolean onOptionsItemSelected(android.view.MenuItem item) {
		switch (item.getItemId()) {
		case R.id.options_menu_list_jumps_insert: {
			createJump();
			return true;
		}
		case R.id.options_menu_list_jumps_preferences: {
			startActivity(new Intent(getActivity(), JumpPreferenceActivity.class));
			return true;
		}
		case R.id.options_menu_list_jumps_stats: {
			startActivity(new Intent(getActivity(), StatisticsActivity.class));
			return true;
		}
		default:
			return super.onOptionsItemSelected(item);
		}
	}


	// Context menu

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		editJump(id);
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		// TODO fix inflation error
//		MenuInflater inflater = getActivity().getMenuInflater();
//		inflater.inflate(R.menu.context_menu_list_item_jumps, menu);
//		menu.setHeaderTitle(getString(R.string.context_menu_list_item_jumps_title,
//				 ((TextView) ((AdapterContextMenuInfo) menuInfo).targetView.findViewById(R.id.list_item_jumps_number)).getText()));
	}

	@Override
	public boolean onContextItemSelected(android.view.MenuItem item) {
		switch (item.getItemId()) {
		case R.id.context_menu_list_item_jumps_edit: {
			editJump(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		case R.id.context_menu_list_item_jumps_delete: {
			deleteJump(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		default:
			return super.onContextItemSelected(item);
		}
	}


	// helpers

	private void createJump() {
		startActivityForResult(new Intent(getActivity(), JumpEditActivity.class), ACTIVITY_CREATE);
	}

	private void editJump(long jumpId) {
		Intent i = new Intent(getActivity(), JumpEditActivity.class);
		i.putExtra(Jumps._ID, jumpId);
		startActivityForResult(i, ACTIVITY_EDIT);
	}

	private void deleteJump(long jumpId) {
		getActivity().getContentResolver().delete(Jumps.buildJumpUri(jumpId), null, null);
		getLoaderManager().restartLoader(LOADER_JUMPS, null, this);
	}


	// loaders

	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		return new CursorLoader(
				getActivity(),
				Jumps.CONTENT_URI,
				PROJECTION,
				null,
				null,
				Jumps.DEFAULT_SORT
		);
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
		mAdapter.swapCursor(data);
	}

	@Override
	public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.swapCursor(null);
	}


	// list adapter

	public static class JumpsListAdapter extends SimpleCursorAdapter {

		private static final String DATE_FORMAT = "E, MMMM dd, yyyy";
		private static final String FT = " ft";
		private static final int[] TO = new int[] {
			R.id.list_item_jumps_number,
			R.id.list_item_jumps_date,
			R.id.list_item_jumps_place,
			R.id.list_item_jumps_aircraft,
			R.id.list_item_jumps_altitude,
			R.id.list_item_jumps_description
		};
		private static NumberFormat nf = NumberFormat.getIntegerInstance();

		public JumpsListAdapter(Context context) {
			super(context, R.layout.list_item_jumps, null, PROJECTION, TO, 0);
		}

		@Override
		public void bindView(View view, Context context, Cursor cursor) {
			super.bindView(view, context, cursor);

			ViewHolder holder = (ViewHolder) view.getTag();
			if (holder == null) {
				holder = new ViewHolder();
				holder.altitude = (TextView) view.findViewById(R.id.list_item_jumps_altitude);
				holder.date = (TextView) view.findViewById(R.id.list_item_jumps_date);
				holder.altitudeColumn = cursor.getColumnIndexOrThrow(Jumps.JUMP_ALTITUDE);
				holder.dateColumn = cursor.getColumnIndexOrThrow(Jumps.JUMP_DATE);
				view.setTag(holder);
			}

			holder.altitude.setText(nf.format(UIUtils.roundAltitude(cursor.getInt(holder.altitudeColumn))) + FT);
			holder.date.setText(DateFormat.format(DATE_FORMAT, cursor.getLong(holder.dateColumn)));
		}

		static class ViewHolder {
			TextView altitude;
			TextView date;
			int altitudeColumn; 
			int dateColumn;
        }
	}

}
