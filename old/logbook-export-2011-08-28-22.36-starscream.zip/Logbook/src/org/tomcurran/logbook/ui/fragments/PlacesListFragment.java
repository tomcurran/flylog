package org.tomcurran.logbook.ui.fragments;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.ActionBar;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.ListFragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.view.Menu;
import android.support.v4.view.MenuInflater;
import android.support.v4.view.MenuItem;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.widget.TextView;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Places;
import org.tomcurran.logbook.ui.BaseActivity;
import org.tomcurran.logbook.ui.HomeActivity;

public class PlacesListFragment extends ListFragment implements LoaderManager.LoaderCallbacks<Cursor> {

	private static final int LOADER_PLACES = 0;
	private static final String[] PROJECTION = {
		Places.PLACE_NAME,
		Places._ID
	};

	private CursorAdapter mAdapter;
    private BaseDialogFragment.OnSuccessListener mPlaceOnSuccessListener = new BaseDialogFragment.OnSuccessListener() {
		@Override
		public void onSuccess(Long id) {
			getLoaderManager().restartLoader(LOADER_PLACES, null, PlacesListFragment.this);
		}
	};

	// life cycle

    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setHasOptionsMenu(true);
    }

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		FragmentActivity activity = getActivity();
		ActionBar ab = activity.getSupportActionBar();
		
		ab.setTitle(R.string.title_places_list);
        ab.setDisplayHomeAsUpEnabled(true);

		setEmptyText(getString(R.string.list_emtpy_places));
		mAdapter = new PlacesListAdapter(activity);
		setListAdapter(mAdapter);
        getLoaderManager().initLoader(LOADER_PLACES, null, this);
		registerForContextMenu(getListView());
	}


	// Options menu

    @Override
    public void onCreateOptionsMenu(Menu menu, android.view.MenuInflater inflater) {
    	inflater.inflate(R.menu.options_menu_list_places, menu);
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home: {
			((BaseActivity)getActivity()).goUp(HomeActivity.class);
			return true;
		}
		case R.id.options_menu_list_places_insert: {
			createPlace();
			return true;
		}
		default:
			return super.onOptionsItemSelected(item);
		}
	}


	// Context menu

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		editPlace(id);
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		MenuInflater inflater = (MenuInflater) getActivity().getMenuInflater();
		inflater.inflate(R.menu.context_menu_list_item_places, menu);
		menu.setHeaderTitle(
				 ((TextView) ((AdapterContextMenuInfo) menuInfo)
						 .targetView.findViewById(android.R.id.text1)).getText());
	}

	@Override
	public boolean onContextItemSelected(android.view.MenuItem item) {
		switch (item.getItemId()) {
		case R.id.context_menu_list_item_places_edit: {
			editPlace(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		case R.id.context_menu_list_item_places_delete: {
			deletePlace(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		default:
			return super.onContextItemSelected(item);
		}
	}


	// helpers

	private void createPlace() {
		new PlaceDialogFragment(null, mPlaceOnSuccessListener)
			.show(getFragmentManager(), PlaceDialogFragment.TAG);
	}

	private void editPlace(long placeId) {
		new PlaceDialogFragment(placeId, mPlaceOnSuccessListener)
			.show(getFragmentManager(), PlaceDialogFragment.TAG);
	}

	private void deletePlace(long placeId) {
		getActivity().getContentResolver().delete(Places.buildPlaceUri(placeId), null, null);
		getLoaderManager().restartLoader(LOADER_PLACES, null, this);
	}


	// loaders

	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		return new CursorLoader(
				getActivity(),
				Places.CONTENT_URI,
				PROJECTION,
				null,
				null,
				Places.DEFAULT_SORT
		);
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
		mAdapter.swapCursor(data);
	}

	@Override
	public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.swapCursor(null);
	}


	// list adapter

	public static class PlacesListAdapter extends SimpleCursorAdapter {

		private static final int[] TO = new int[] {
			android.R.id.text1
		};

		public PlacesListAdapter(Context context) {
			super(context, android.R.layout.simple_list_item_1, null, PROJECTION, TO, 0);
		}
	}

}
