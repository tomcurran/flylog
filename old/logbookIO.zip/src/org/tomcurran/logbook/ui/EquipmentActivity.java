package org.tomcurran.logbook.ui;

import org.tomcurran.logbook.ui.fragments.EquipmentListFragment;

import android.support.v4.app.Fragment;

public class EquipmentActivity extends BaseSinglePaneActivity {

	@Override
	protected Fragment onCreatePane() {
		return new EquipmentListFragment();
	}
}
