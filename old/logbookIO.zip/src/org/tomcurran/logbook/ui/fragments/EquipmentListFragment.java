package org.tomcurran.logbook.ui.fragments;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Equipment;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.widget.TextView;

public class EquipmentListFragment extends ListFragment implements LoaderManager.LoaderCallbacks<Cursor> {

	private static final int LOADER_EQUIPMENT = 0;
	private static final String[] PROJECTION = new String[] {
		Equipment.EQUIPMENT_CANOPY_NAME,
		Equipment.EQUIPMENT_CANOPY_SIZE,
		Equipment._ID
	};
	private CursorAdapter mAdapter;
	private EquipmentDialogFragment.OnSuccessListener mEquipmentDialogOnSuccessListener = new EquipmentDialogFragment.OnSuccessListener() {
		public void onSuccess() {
			getLoaderManager().restartLoader(EquipmentListFragment.LOADER_EQUIPMENT, null, EquipmentListFragment.this);
		}
	};


	// life cycle

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflater.inflate(R.layout.fragment_list_equipment, container, false);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		registerForContextMenu(getListView());
		mAdapter = new EquipmentsListAdapter(getActivity());
		setListAdapter(mAdapter);
        getLoaderManager().initLoader(LOADER_EQUIPMENT, null, this);
	}


	// Options menu

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		inflater.inflate(R.menu.options_menu_list_equipment, menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.options_menu_list_equipment_insert:
			createEquipment();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}


	// Context menu

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		editEquipment(id);
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		getActivity().getMenuInflater().inflate(R.menu.context_menu_list_item_equipment, menu);
		menu.setHeaderTitle(((TextView) ((AdapterContextMenuInfo) menuInfo).targetView.findViewById(R.id.list_item_equipment_name)).getText());
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.context_menu_list_item_equipment_edit: {
			editEquipment(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		case R.id.context_menu_list_item_equipment_delete: {
			deleteEquipment(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		default:
			return super.onContextItemSelected(item);
		}
	}


	// helpers

	private void createEquipment() {
		new EquipmentDialogFragment(null, mEquipmentDialogOnSuccessListener).show(getFragmentManager(), EquipmentDialogFragment.TAG);
	}

	private void editEquipment(long equipmentId) {
		new EquipmentDialogFragment(equipmentId, mEquipmentDialogOnSuccessListener).show(getFragmentManager(), EquipmentDialogFragment.TAG);
	}

	private void deleteEquipment(long equipmentId) {
		getActivity().getContentResolver().delete(Equipment.buildEquipmentUri(equipmentId), null, null);
		getLoaderManager().restartLoader(LOADER_EQUIPMENT, null, this);
	}


	// loader implements
	
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		return new CursorLoader(
				getActivity(),
				Equipment.CONTENT_URI,
				PROJECTION,
				null,
				null,
				Equipment.DEFAULT_SORT
		);
	}

	public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
		mAdapter.swapCursor(data);
	}

	public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.swapCursor(null);
	}


	// list adapter

	public static class EquipmentsListAdapter extends SimpleCursorAdapter {

		private final static int[] TO = new int[] {
            R.id.list_item_equipment_name
        };

        public EquipmentsListAdapter(Context context) {
            super(context, R.layout.list_item_equipment, null, PROJECTION, EquipmentsListAdapter.TO, 0);
        }

		@Override
		public void bindView(View view, Context context, Cursor cursor) {
			super.bindView(view, context, cursor);

            TextView text1 = (TextView) view.findViewById(R.id.list_item_equipment_name);

            String canopy_name = cursor.getString(cursor.getColumnIndex(Equipment.EQUIPMENT_CANOPY_NAME));
            int canopy_size = cursor.getInt(cursor.getColumnIndex(Equipment.EQUIPMENT_CANOPY_SIZE));        
            
            text1.setText(canopy_name + " " + canopy_size);
		}
	}
}
