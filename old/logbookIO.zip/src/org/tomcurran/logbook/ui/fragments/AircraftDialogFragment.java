package org.tomcurran.logbook.ui.fragments;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Aircrafts;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

public class AircraftDialogFragment extends DialogFragment {
	
	public interface OnSuccessListener {
		void onSuccess();
	}

	public static final String TAG = "aircraft_dialog_fragment";

	protected Long mRowId;
	protected AircraftDialogFragment.OnSuccessListener mOnSuccessListener;

	protected OnClickListener mOnClickListener = new DialogInterface.OnClickListener() {
		public void onClick(DialogInterface dialog, int whichButton) {
        	switch (whichButton) {
        	case DialogInterface.BUTTON_POSITIVE:
        		String aircraftName = ((EditText)((AlertDialog)dialog).findViewById(R.id.dialog_text_aircraft_name)).getText().toString();
                if (!TextUtils.isEmpty(aircraftName)) {
                	ContentResolver resolver = getActivity().getContentResolver();
                	ContentValues values = new ContentValues();
                	values.put(Aircrafts.AIRCRAFT_NAME, aircraftName);
                	if (mRowId != null) {
                		resolver.update(Aircrafts.buildAircraftUri(mRowId), values, null, null);
                	} else {
                		resolver.insert(Aircrafts.CONTENT_URI, values);
                	}
                	mOnSuccessListener.onSuccess();
                }
        		break;
        	case DialogInterface.BUTTON_NEUTRAL:
        		if (mRowId != null) {
        			getActivity().getContentResolver().delete(Aircrafts.buildAircraftUri(mRowId), null, null);
        			mOnSuccessListener.onSuccess();
            	}
        		break;
        	case DialogInterface.BUTTON_NEGATIVE:
        		break;
        	}
        }
	};
	
	public AircraftDialogFragment(Long aircraftId, AircraftDialogFragment.OnSuccessListener onSuccessListener) {
		mRowId = aircraftId;
		mOnSuccessListener = onSuccessListener;
	}
	
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
    	FragmentActivity activity = getActivity();
		View v = LayoutInflater.from(activity).inflate(R.layout.fragment_dialog_aircraft, null);

		AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(activity)
//			.setIcon(R.drawable.dialog_icon_place)
			.setView(v)
			.setPositiveButton(R.string.dialog_button_aircraft_positive, mOnClickListener)
			.setNegativeButton(R.string.dialog_button_aircraft_negative, mOnClickListener);

    	if (mRowId != null) {
    		dialogBuilder.setTitle(R.string.dialog_title_aircraft_edit);
    		Cursor aircraft = getActivity().getContentResolver().query(
					Aircrafts.buildAircraftUri(mRowId),
					new String[] { Aircrafts.AIRCRAFT_NAME },
					null,
					null,
					Aircrafts.DEFAULT_SORT
			);
			if (aircraft.moveToFirst()) {
				((EditText) v.findViewById(R.id.dialog_text_aircraft_name)).setText(
						aircraft.getString(aircraft.getColumnIndexOrThrow(Aircrafts.AIRCRAFT_NAME)));
			}
			dialogBuilder.setNeutralButton(R.string.dialog_button_aircraft_neutral, mOnClickListener);
    	} else {
    		dialogBuilder.setTitle(R.string.dialog_title_aircraft_add);
    	}
		
    	return dialogBuilder.create();
	}
}
