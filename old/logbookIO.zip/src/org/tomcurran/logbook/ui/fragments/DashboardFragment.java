package org.tomcurran.logbook.ui.fragments;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.ui.AircraftsActivity;
import org.tomcurran.logbook.ui.EquipmentActivity;
import org.tomcurran.logbook.ui.JumpsListActivity;
import org.tomcurran.logbook.ui.PlacesActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class DashboardFragment extends Fragment {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_dashboard, container);
        
        root.findViewById(R.id.home_btn_jumps).setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
                startActivity(new Intent(getActivity(), JumpsListActivity.class));
			}
		});
        
        root.findViewById(R.id.home_btn_places).setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
                startActivity(new Intent(getActivity(), PlacesActivity.class));
			}
		});
        
        root.findViewById(R.id.home_btn_aircrafts).setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
                startActivity(new Intent(getActivity(), AircraftsActivity.class));
			}
		});
        
        root.findViewById(R.id.home_btn_equipment).setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
                startActivity(new Intent(getActivity(), EquipmentActivity.class));
			}
		});

		return root;
	}
}
