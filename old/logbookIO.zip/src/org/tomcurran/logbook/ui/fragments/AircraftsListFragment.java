package org.tomcurran.logbook.ui.fragments;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Aircrafts;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.widget.TextView;

public class AircraftsListFragment extends ListFragment implements LoaderManager.LoaderCallbacks<Cursor> {

	private static final int LOADER_AIRCRAFTS = 0;
	private static final String[] PROJECTION = new String[] {
		Aircrafts.AIRCRAFT_NAME,
		Aircrafts._ID
	};
	private CursorAdapter mAdapter;
	private AircraftDialogFragment.OnSuccessListener mAircraftDialogOnSuccessListener = new AircraftDialogFragment.OnSuccessListener() {
		public void onSuccess() {
			getLoaderManager().restartLoader(AircraftsListFragment.LOADER_AIRCRAFTS, null, AircraftsListFragment.this);
		}
	};


	// life cycle
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setHasOptionsMenu(true);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflater.inflate(R.layout.fragment_list_aircrafts, container, false);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		registerForContextMenu(getListView());
		mAdapter = new AircraftsListAdapter(getActivity());
		setListAdapter(mAdapter);
        getLoaderManager().initLoader(LOADER_AIRCRAFTS, null, this);
	}


	// Options menu

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		inflater.inflate(R.menu.options_menu_list_aircrafts, menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.options_menu_list_aircrafts_insert:
			createAircraft();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}


	// Context menu

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		editAircraft(id);
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		getActivity().getMenuInflater().inflate(R.menu.context_menu_list_item_aircrafts, menu);
		menu.setHeaderTitle(((TextView) ((AdapterContextMenuInfo) menuInfo).targetView.findViewById(R.id.list_item_aircrafts_name)).getText());
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.context_menu_list_item_aircrafts_edit: {
			editAircraft(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		case R.id.context_menu_list_item_aircrafts_delete: {
			deleteAircraft(((AdapterContextMenuInfo)item.getMenuInfo()).id);
			return true;
		}
		default:
			return super.onContextItemSelected(item);
		}
	}


	// helpers

	private void createAircraft() {
		new AircraftDialogFragment(null, mAircraftDialogOnSuccessListener).show(getFragmentManager(), AircraftDialogFragment.TAG);
	}

	private void editAircraft(long aircraftId) {
		new AircraftDialogFragment(aircraftId, mAircraftDialogOnSuccessListener).show(getFragmentManager(), AircraftDialogFragment.TAG);
	}

	private void deleteAircraft(long aircraftId) {
		getActivity().getContentResolver().delete(Aircrafts.buildAircraftUri(aircraftId), null, null);
		getLoaderManager().restartLoader(LOADER_AIRCRAFTS, null, this);
	}


	// loaders

	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		return new CursorLoader(
				getActivity(),
				Aircrafts.CONTENT_URI,
				PROJECTION,
				null,
				null,
				Aircrafts.DEFAULT_SORT
		);
	}

	public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
		mAdapter.swapCursor(data);
	}

	public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.swapCursor(null);
	}


	// list adapter
	
	public static class AircraftsListAdapter extends SimpleCursorAdapter {
		
		private static final int[] TO = new int[] {
			R.id.list_item_aircrafts_name
		};
		
		public AircraftsListAdapter(Context context) {
			super(context, R.layout.list_item_aircrafts, null, PROJECTION, TO, 0);
		}
	}
}
