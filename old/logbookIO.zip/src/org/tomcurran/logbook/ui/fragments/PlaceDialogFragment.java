package org.tomcurran.logbook.ui.fragments;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Places;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

public class PlaceDialogFragment extends DialogFragment {
	
	public interface OnSuccessListener {
		void onSuccess();
	}

	public static final String TAG = "palce_dialog_fragment";

	protected Long mRowId;
	protected PlaceDialogFragment.OnSuccessListener mOnSuccessListener;

	protected OnClickListener mOnClickListener = new DialogInterface.OnClickListener() {
		public void onClick(DialogInterface dialog, int whichButton) {
        	switch (whichButton) {
        	case DialogInterface.BUTTON_POSITIVE:
        		String placeName = ((EditText)((AlertDialog)dialog).findViewById(R.id.dialog_text_place_name)).getText().toString();
                if (!TextUtils.isEmpty(placeName)) {
                	ContentResolver resolver = getActivity().getContentResolver();
                	ContentValues values = new ContentValues();
                	values.put(Places.PLACE_NAME, placeName);
                	if (mRowId != null) {
                		resolver.update(Places.buildPlaceUri(mRowId), values, null, null);
                	} else {
                		resolver.insert(Places.CONTENT_URI, values);
                	}
                	mOnSuccessListener.onSuccess();
                }
        		break;
        	case DialogInterface.BUTTON_NEUTRAL:
        		if (mRowId != null) {
        			getActivity().getContentResolver().delete(Places.buildPlaceUri(mRowId), null, null);
        			mOnSuccessListener.onSuccess();
            	}
        		break;
        	case DialogInterface.BUTTON_NEGATIVE:
        		break;
        	}
        }
	};
	
	public PlaceDialogFragment(Long placeId, PlaceDialogFragment.OnSuccessListener onSuccessListener) {
		mRowId = placeId;
		mOnSuccessListener = onSuccessListener;
	}
	
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
    	FragmentActivity activity = getActivity();
		View v = LayoutInflater.from(activity).inflate(R.layout.fragment_dialog_place, null);

		AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(activity)
//			.setIcon(R.drawable.dialog_icon_place)
			.setView(v)
			.setPositiveButton(R.string.dialog_button_place_positive, mOnClickListener)
			.setNegativeButton(R.string.dialog_button_place_negative, mOnClickListener);

    	if (mRowId != null) {
    		dialogBuilder.setTitle(R.string.dialog_title_place_edit);
    		Cursor place = getActivity().getContentResolver().query(
					Places.buildPlaceUri(mRowId),
					new String[] { Places.PLACE_NAME },
					null,
					null,
					Places.DEFAULT_SORT
			);
			if (place.moveToFirst()) {
				((EditText) v.findViewById(R.id.dialog_text_place_name)).setText(
						place.getString(place.getColumnIndexOrThrow(Places.PLACE_NAME)));
			}
			dialogBuilder.setNeutralButton(R.string.dialog_button_place_neutral, mOnClickListener);
    	} else {
    		dialogBuilder.setTitle(R.string.dialog_title_place_add);
    	}
		
    	return dialogBuilder.create();
	}
}
