package org.tomcurran.logbook.ui.fragments;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookContract.Equipment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

public class EquipmentDialogFragment extends DialogFragment {
	
	public interface OnSuccessListener {
		void onSuccess();
	}

	public static final String TAG = "palce_dialog_fragment";

	protected Long mRowId;
	protected EquipmentDialogFragment.OnSuccessListener mOnSuccessListener;

	protected OnClickListener mOnClickListener = new DialogInterface.OnClickListener() {
		public void onClick(DialogInterface dialog, int whichButton) {
        	switch (whichButton) {
        	case DialogInterface.BUTTON_POSITIVE:
        		AlertDialog alertDialog = (AlertDialog) dialog;
        		String equipmentName = ((EditText)alertDialog.findViewById(R.id.dialog_text_equipment_name)).getText().toString();
        		String equipmentSize = ((EditText)alertDialog.findViewById(R.id.dialog_text_equipment_size)).getText().toString();
                if (!TextUtils.isEmpty(equipmentName) && !TextUtils.isEmpty(equipmentSize)) {
                	ContentResolver resolver = getActivity().getContentResolver();
                	ContentValues values = new ContentValues();
                	values.put(Equipment.EQUIPMENT_CANOPY_NAME, equipmentName);
                	values.put(Equipment.EQUIPMENT_CANOPY_SIZE, Integer.valueOf(equipmentSize));
                	if (mRowId != null) {
                		resolver.update(Equipment.buildEquipmentUri(mRowId), values, null, null);
                	} else {
                		resolver.insert(Equipment.CONTENT_URI, values);
                	}
                	mOnSuccessListener.onSuccess();
                }
        		break;
        	case DialogInterface.BUTTON_NEUTRAL:
        		if (mRowId != null) {
        			getActivity().getContentResolver().delete(Equipment.buildEquipmentUri(mRowId), null, null);
        			mOnSuccessListener.onSuccess();
            	}
        		break;
        	case DialogInterface.BUTTON_NEGATIVE:
        		break;
        	}
        }
	};
	
	public EquipmentDialogFragment(Long equipmentId, EquipmentDialogFragment.OnSuccessListener onSuccessListener) {
		mRowId = equipmentId;
		mOnSuccessListener = onSuccessListener;
	}
	
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
    	FragmentActivity activity = getActivity();
		View v = LayoutInflater.from(activity).inflate(R.layout.fragment_dialog_equipment, null);

		AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(activity)
//			.setIcon(R.drawable.dialog_icon_Equipment)
			.setView(v)
			.setPositiveButton(R.string.dialog_button_equipment_positive, mOnClickListener)
			.setNegativeButton(R.string.dialog_button_equipment_negative, mOnClickListener);

    	if (mRowId != null) {
    		dialogBuilder.setTitle(R.string.dialog_title_equipment_edit);
    		Cursor equipment = getActivity().getContentResolver().query(
					Equipment.buildEquipmentUri(mRowId),
					new String[] { Equipment.EQUIPMENT_CANOPY_NAME, Equipment.EQUIPMENT_CANOPY_SIZE },
					null,
					null,
					Equipment.DEFAULT_SORT
			);
			if (equipment.moveToFirst()) {
				((EditText) v.findViewById(R.id.dialog_text_equipment_name)).setText(
						equipment.getString(equipment.getColumnIndexOrThrow(Equipment.EQUIPMENT_CANOPY_NAME)));
				((EditText) v.findViewById(R.id.dialog_text_equipment_size)).setText(
						equipment.getString(equipment.getColumnIndexOrThrow(Equipment.EQUIPMENT_CANOPY_SIZE)));
			}
			dialogBuilder.setNeutralButton(R.string.dialog_button_equipment_neutral, mOnClickListener);
    	} else {
    		dialogBuilder.setTitle(R.string.dialog_title_equipment_add);
    	}
		
    	return dialogBuilder.create();
	}
}
