package org.tomcurran.logbook.ui;

import org.tomcurran.logbook.ui.fragments.PlacesListFragment;

import android.support.v4.app.Fragment;

public class PlacesActivity extends BaseSinglePaneActivity {

	@Override
	protected Fragment onCreatePane() {
		return new PlacesListFragment();
	}
}
