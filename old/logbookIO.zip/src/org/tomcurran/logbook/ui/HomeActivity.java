package org.tomcurran.logbook.ui;

import org.tomcurran.logbook.R;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class HomeActivity extends BaseActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        setupActionBar(null);
//        new TestData(this);
    }
	
	
	// Options menu
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	getMenuInflater().inflate(R.menu.options_menu_home, menu);
    	return true;
    }
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.options_menu_home_insert:
			createJump();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	
	private void createJump() {
		startActivity(new Intent(this, JumpEditActivity.class));
	}
}