package org.tomcurran.logbook.ui;

import org.tomcurran.logbook.ui.fragments.AircraftsListFragment;

import android.support.v4.app.Fragment;

public class AircraftsActivity extends BaseSinglePaneActivity {

	@Override
	protected Fragment onCreatePane() {
		return new AircraftsListFragment();
	}

}
