package org.tomcurran.logbook3;

import java.sql.Date;
import java.text.NumberFormat;

import android.content.Context;
import android.database.Cursor;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class JumpsListAdapter extends SimpleCursorAdapter {

	private static final String[] from = new String[] {
		JumpsDbAdapter.KEY_JUMP_NUM,
		JumpsDbAdapter.KEY_DATE,
		JumpsDbAdapter.KEY_PLACE,
		JumpsDbAdapter.KEY_AIRCRAFT,
		JumpsDbAdapter.KEY_ALTITUDE,
		JumpsDbAdapter.KEY_DESCRIPTION
	};
	private static final int[] to = new int[] {
		R.id.jump_num,
		R.id.date,
		R.id.place,
		R.id.aircraft,
		R.id.altitude,
		R.id.description
	};

	public JumpsListAdapter(Context context, Cursor c) {
		super(context, R.layout.jumps_row, c, from, to);
	}

	@Override
	public void bindView(View view, Context context, Cursor cursor) {
		super.bindView(view, context, cursor);
		
		TextView altitudeText = (TextView) view.findViewById(R.id.altitude);
		TextView dateText = (TextView) view.findViewById(R.id.date);
		
		int altitude = cursor.getInt(cursor.getColumnIndex(JumpsDbAdapter.KEY_ALTITUDE));		
		altitudeText.setText(NumberFormat.getIntegerInstance().format(altitude) + " ft");
		
		String date = cursor.getString(cursor.getColumnIndex(JumpsDbAdapter.KEY_DATE));
		Date jumpDate = Date.valueOf(date);
		dateText.setText(DateFormat.format("E, MMMM dd, yyyy", jumpDate));
	}
}
