package org.tomcurran.logbook3;

import android.os.Bundle;
import android.preference.PreferenceActivity;

public class JumpPreferences extends PreferenceActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle(R.string.preference_title);
		addPreferencesFromResource(R.xml.jump_preferences);
	}

}
