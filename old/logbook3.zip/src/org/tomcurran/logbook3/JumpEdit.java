package org.tomcurran.logbook3;

import java.sql.Date;
import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;

public class JumpEdit extends Activity {

	static final int DATE_DIALOG_ID = 0;

	private TextView mJumpNumText;
	private TextView mDateText;
	private TextView mPlaceText;
	private TextView mAircraftText;
	private TextView mEquipmentText;
	private TextView mAltitudeText;
	private TextView mDelayText;
	private TextView mDescriptionText;
    private Long mRowId;

    private int mYear;
    private int mMonth;
    private int mDay;
	private DatePickerDialog.OnDateSetListener mDateSetListener =
        new DatePickerDialog.OnDateSetListener() {
	        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
	            mYear = year;
	            mMonth = monthOfYear;
	            mDay = dayOfMonth;
	            updateDisplay();
	        }
    };
   
    private JumpsDbAdapter mDbHelper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		mDbHelper = new JumpsDbAdapter(this);
		mDbHelper.open();

		setContentView(R.layout.jump_edit);
		setTitle(R.string.create_jump_title);

		mJumpNumText = (TextView) findViewById(R.id.jumpNumberText);
		mDateText = (TextView) findViewById(R.id.dateText);
		mPlaceText = (TextView) findViewById(R.id.placeText);
		mAircraftText = (TextView) findViewById(R.id.aircraftText);
		mEquipmentText = (TextView) findViewById(R.id.equipmentText);
		mAltitudeText = (TextView) findViewById(R.id.altitudeText);
		mDelayText = (TextView) findViewById(R.id.delayText);
		mDescriptionText = (TextView) findViewById(R.id.descriptionText);
		
		mDateText.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				showDialog(DATE_DIALOG_ID);
			}
		});
		
		mDateText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus)
					showDialog(DATE_DIALOG_ID);
			}
		});

        mRowId = (savedInstanceState == null) ? null : (Long) savedInstanceState.getSerializable(JumpsDbAdapter.KEY_ROWID);
		if (mRowId == null) {
			Bundle extras = getIntent().getExtras();
			mRowId = extras != null ? extras.getLong(JumpsDbAdapter.KEY_ROWID) : null;
		}

		populateFields();
		updateDisplay();
	}
	
	private void populateFields() {
		if (mRowId != null) {
            Cursor jump = mDbHelper.fetchJump(mRowId);
            startManagingCursor(jump);

            int jump_num_col = jump.getColumnIndexOrThrow(JumpsDbAdapter.KEY_JUMP_NUM);
            mJumpNumText.setText(jump.getString(jump_num_col));
            
            setTitle(getString(R.string.edit_jump_title, jump.getInt(jump_num_col)));
            
            String[] date = jump.getString(jump.getColumnIndexOrThrow(JumpsDbAdapter.KEY_DATE)).split("-");
            mYear = Integer.parseInt(date[0]);
            mMonth = Integer.parseInt(date[1]) - 1;
            mDay = Integer.parseInt(date[2]);
            
    		mPlaceText.setText(jump.getString(jump.getColumnIndexOrThrow(JumpsDbAdapter.KEY_PLACE)));
    		mAircraftText.setText(jump.getString(jump.getColumnIndexOrThrow(JumpsDbAdapter.KEY_AIRCRAFT)));
    		mEquipmentText.setText(jump.getString(jump.getColumnIndexOrThrow(JumpsDbAdapter.KEY_EUQIPMENT)));
    		mAltitudeText.setText(jump.getString(jump.getColumnIndexOrThrow(JumpsDbAdapter.KEY_ALTITUDE)));
    		mDelayText.setText(jump.getString(jump.getColumnIndexOrThrow(JumpsDbAdapter.KEY_DELAY)));
    		mDescriptionText.setText(jump.getString(jump.getColumnIndexOrThrow(JumpsDbAdapter.KEY_DESCRIPTION)));
        }
		else {
        	SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);

            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
            
            mJumpNumText.setText(String.valueOf(mDbHelper.getHighestJumpNum() + 1));
            mPlaceText.setText(settings.getString("place", ""));
            mAircraftText.setText(settings.getString("aircraft", ""));
            mEquipmentText.setText(settings.getString("equipment", ""));
            mDelayText.setText(settings.getString("delay", ""));
            mAltitudeText.setText(settings.getString("altitude", ""));
        }
	}

	private void updateDisplay() {
		mDateText.setText(
            new StringBuilder()
            		.append(mDay).append("-")
                    .append(mMonth + 1).append("-") // Month is 0 based so add 1
                    .append(mYear));
	}

	@Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
        case DATE_DIALOG_ID:
            return new DatePickerDialog(this,
                        mDateSetListener,
                        mYear, mMonth, mDay);
        }
        return null;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        saveState();
        outState.putSerializable(JumpsDbAdapter.KEY_ROWID, mRowId);
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveState();
    }

    @Override
    protected void onResume() {
        super.onResume();
        populateFields();
    }

    private void saveState() {

    	String jumpNumText = mJumpNumText.getText().toString();
    	int jump_num = jumpNumText.equals("") ? 0 : Integer.parseInt(jumpNumText);

    	Date date = Date.valueOf(
    			new StringBuilder()
                    .append(mYear).append("-")
                    .append(mMonth + 1).append("-") // Month is 0 based so add 1
            		.append(mDay).toString());

    	String place = mPlaceText.getText().toString();
    	String aircraft = mAircraftText.getText().toString();
    	String equipment = mEquipmentText.getText().toString();
    	
    	String altitudeText = mAltitudeText.getText().toString();
    	int altitude = altitudeText.equals("") ? 0 : Integer.parseInt(altitudeText);

    	String delayText = mDelayText.getText().toString();
    	int delay = delayText.equals("") ? 0 : Integer.parseInt(delayText);

    	String description = mDescriptionText.getText().toString();

        if (mRowId == null) {
            long id = mDbHelper.createJump(jump_num, date, place, aircraft, equipment, altitude, delay, description);
            if (id > 0) {
                mRowId = id;
            }
        } else {
        	mDbHelper.updateJump(mRowId, jump_num, date, place, aircraft, equipment, altitude, delay, description);
        }
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.jump_edit_options, menu);
		return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch (item.getItemId()) {
		case R.id.edit_menu_delete:
			saveState();
            mDbHelper.deleteJump(mRowId);
            finish();
			return true;
		case R.id.edit_menu_save:
			setResult(RESULT_OK);
            finish();
            return true;
		default:
			return super.onOptionsItemSelected(item);
		}
    }
}
