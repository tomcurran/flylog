package org.tomcurran.logbook3;

import java.sql.Date;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class JumpsDbAdapter {

	public static final String KEY_ROWID = "_id";
	public static final String KEY_JUMP_NUM = "jumpnumber";
	public static final String KEY_DATE = "jumpdate";
	public static final String KEY_PLACE = "place";
	public static final String KEY_AIRCRAFT = "aircraft";
	public static final String KEY_EUQIPMENT = "equipment";
	public static final String KEY_ALTITUDE = "altitude";
	public static final String KEY_DELAY = "delay";
	public static final String KEY_DESCRIPTION = "description";

	private static final String TAG = "JumpsDbAdapter";

	private DatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;

	private static final String DATABASE_NAME = "data5";
	private static final String DATABASE_TABLE = "jumps";
	private static final int DATABASE_VERSION = 2;

	private static final String DATABASE_CREATE = String
			.format("create table %s (%s integer primary key autoincrement, %s integer, " +
					"%s string, %s string, %s string, %s string, %s integer, %s integer, %s string);",
					DATABASE_TABLE, KEY_ROWID, KEY_JUMP_NUM, KEY_DATE, KEY_PLACE,
					KEY_AIRCRAFT, KEY_EUQIPMENT, KEY_ALTITUDE, KEY_DELAY, KEY_DESCRIPTION);

	private final Context mCtx;

	private static class DatabaseHelper extends SQLiteOpenHelper {

		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {

			db.execSQL(DATABASE_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
					+ newVersion + ", which will destroy all old data");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
		}
	}

	public JumpsDbAdapter(Context ctx) {
		this.mCtx = ctx;
	}

	public JumpsDbAdapter open() throws SQLException {
		mDbHelper = new DatabaseHelper(mCtx);
		mDb = mDbHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		mDbHelper.close();
	}

	public long createJump(int jump_num, Date jump_date, String place,
			String aircraft, String equipment, int altitude, int delay, String description) {
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_JUMP_NUM, jump_num);
		initialValues.put(KEY_DATE, jump_date.toString());
		initialValues.put(KEY_PLACE, place);
		initialValues.put(KEY_AIRCRAFT, aircraft);
		initialValues.put(KEY_EUQIPMENT, equipment);
		initialValues.put(KEY_ALTITUDE, altitude);
		initialValues.put(KEY_DELAY, delay);
		initialValues.put(KEY_DESCRIPTION, description);

		return mDb.insert(DATABASE_TABLE, null, initialValues);
	}

	public boolean deleteJump(long rowId) {
		return mDb.delete(DATABASE_TABLE, String.format("%s=%s", KEY_ROWID, rowId), null) > 0;
	}

	public Cursor fetchAllJumps() {
		return mDb.query(DATABASE_TABLE, new String[] { KEY_ROWID,
				KEY_JUMP_NUM, KEY_DATE, KEY_PLACE, KEY_AIRCRAFT, KEY_EUQIPMENT,
				KEY_ALTITUDE, KEY_DELAY, KEY_DESCRIPTION }, null, null, null, null,
				String.format("%s desc,%s desc", KEY_JUMP_NUM, KEY_DATE));
	}

	public Cursor fetchJump(long rowId) throws SQLException {
		Cursor mCursor = mDb.query(true, DATABASE_TABLE, new String[] {
				KEY_ROWID, KEY_JUMP_NUM, KEY_DATE, KEY_PLACE, KEY_AIRCRAFT,
				KEY_EUQIPMENT, KEY_ALTITUDE, KEY_DELAY, KEY_DESCRIPTION },
				String.format("%s=%s", KEY_ROWID, rowId),
				null, null, null, null, null);
		if (mCursor != null) {
			mCursor.moveToFirst();
		}
		return mCursor;
	}

	public boolean updateJump(long rowId, int jump_num, Date jump_date, String place,
			String aircraft, String equipment, int altitude, int delay, String description) {
		ContentValues args = new ContentValues();
		args.put(KEY_JUMP_NUM, jump_num);
		args.put(KEY_DATE, jump_date.toString());
		args.put(KEY_PLACE, place);
		args.put(KEY_AIRCRAFT, aircraft);
		args.put(KEY_EUQIPMENT, equipment);
		args.put(KEY_ALTITUDE, altitude);
		args.put(KEY_DELAY, delay);
		args.put(KEY_DESCRIPTION, description);

		return mDb.update(DATABASE_TABLE, args, String.format("%s=%s", KEY_ROWID, rowId), null) > 0;
	}
	
	public int getHighestJumpNum() {
		Cursor cursor = mDb.query(true, DATABASE_TABLE, new String[] { KEY_JUMP_NUM },
				null, null, null, null, String.format("%s desc", KEY_JUMP_NUM), "1");
		if (cursor != null) {
			cursor.moveToFirst();
			int maxJumpNum = cursor.getInt(cursor.getColumnIndexOrThrow(KEY_JUMP_NUM));
			return maxJumpNum > 0 ? maxJumpNum : 0;
		} else
			return 0;
	}

	public void insertTestData() {
		createJump(99,  Date.valueOf("2011-04-11"), "SPC", "C206", "Fury 220",    4000, 8,  "chilled out");
		createJump(100, Date.valueOf("2011-05-01"), "SPC", "C206", "Spectre 190", 8000, 30, "few barrol rolls & backloops & turns\npuled high to try out new canopy\nlots of fun\nlanded in pit");
		createJump(101, Date.valueOf("2011-05-01"), "SPC", "C206", "Spectre 190", 9500, 40, "same as #100\nlanded hanger side of pit\nmake sure not to");
		createJump(102, Date.valueOf("2011-05-01"), "SPC", "C206", "Spectre 190", 5000, 18, "practice jump master & spotting\nspun about\nlanded in pit");
		createJump(103, Date.valueOf("2011-05-01"), "SPC", "C206", "Spectre 190", 9000, 38, "tracked");
		createJump(104, Date.valueOf("2011-05-01"), "SPC", "C206", "Spectre 190", 4000, 12, "rolled out plane");
		createJump(105, Date.valueOf("2011-05-30"), "SPC", "C206", "Spectre 190", 7500, 28, "good party night before so just relaxed\nmajor chill out, backloop for good measure\ntried different ways of turning");
		createJump(106, Date.valueOf("2011-05-30"), "SPC", "C206", "Spectre 190", 1000, 43, "two way with kelly\nneed to make better use of deep brakes if far out on deployment");
		createJump(107, Date.valueOf("2011-06-04"), "SPC", "C206", "Spectre 190", 2200, 7,  "hop'n'pop");
		createJump(108, Date.valueOf("2011-06-04"), "SPC", "C206", "Spectre 190", 2400, 7,  "hop'n'pop");
		createJump(109, Date.valueOf("2011-06-04"), "SPC", "C206", "Spectre 190", 4000, 11, "hop'n'pop");
		createJump(110, Date.valueOf("2011-06-04"), "SPC", "C206", "Spectre 190", 2400, 7,  "hop'n'pop");
		createJump(111, Date.valueOf("2011-06-05"), "SPC", "C206", "Spectre 190", 2800, 8,  "hop'n'pop");
		createJump(112, Date.valueOf("2011-06-05"), "SPC", "C206", "Spectre 190", 4000, 14, "hop'n'pop");
	}
}
