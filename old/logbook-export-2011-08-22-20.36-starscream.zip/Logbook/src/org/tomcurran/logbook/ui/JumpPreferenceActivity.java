package org.tomcurran.logbook.ui;

import org.tomcurran.logbook.R;

import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceChangeListener;
import android.preference.PreferenceActivity;
import android.text.TextUtils;
import android.widget.Toast;

public class JumpPreferenceActivity extends PreferenceActivity {

	private static final String NUMBERIC_REGEX = "\\d*";

	private Preference.OnPreferenceChangeListener numberCheckListener = new OnPreferenceChangeListener() {
	    @Override
	    public boolean onPreferenceChange(Preference preference, Object newValue) {
	    	String newValueString = String.valueOf(newValue);
	    	if (!TextUtils.isEmpty(newValueString)  &&  newValueString.matches(NUMBERIC_REGEX)) {
	    		return true;
	    	} else {
	    		Toast.makeText(JumpPreferenceActivity.this, R.string.preference_jump_invalid_number, Toast.LENGTH_SHORT).show();
	    		return false;
	    	}
	    }
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle(R.string.preference_jump_title);
		addPreferencesFromResource(R.xml.jump_preferences);

		EditTextPreference altitudePref = (EditTextPreference) getPreferenceScreen().findPreference("default_jump_altitude");
		EditTextPreference delayPref = (EditTextPreference) getPreferenceScreen().findPreference("default_jump_delay");

		altitudePref.setOnPreferenceChangeListener(numberCheckListener);
		delayPref.setOnPreferenceChangeListener(numberCheckListener);
	}
}
