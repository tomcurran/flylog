package org.tomcurran.logbook.ui;

import android.support.v4.app.Fragment;

import org.tomcurran.logbook.ui.fragments.JumpsListFragment;

public class HomeActivity extends BaseSinglePaneActivity {

	@Override
	protected Fragment onCreatePane() {
//		new TestData(this);
		return new JumpsListFragment();
	}


}