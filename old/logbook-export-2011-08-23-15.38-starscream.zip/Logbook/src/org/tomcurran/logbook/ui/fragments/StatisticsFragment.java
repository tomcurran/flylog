package org.tomcurran.logbook.ui.fragments;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.view.MenuItem;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.tomcurran.logbook.R;
import org.tomcurran.logbook.provider.LogbookDatabase;
import org.tomcurran.logbook.provider.LogbookContract.Jumps;
import org.tomcurran.logbook.ui.BaseActivity;
import org.tomcurran.logbook.ui.HomeActivity;
import org.tomcurran.logbook.util.BaseCursorLoader;
import org.tomcurran.logbook.util.DbAdapter;
import org.tomcurran.logbook.util.UIUtils;

public class StatisticsFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {

	private static final int[] LAST_MONTHS = { 6, 12, 18, 24 };
	private static final int LOADER_ALTITUDES = 1;
	private static final int LOADER_DELAYS = 2;
	private static final int LOADER_PLACES = 3;
	private static final int LOADER_EQUIPMENT = 4;
	private static final int LOADER_AIRCRAFTS = 5;

	private Cursor mAltitudesCursor;
	private Cursor mDelaysCursor;
	private Cursor mPlacesCursor;
	private Cursor mEquipmentCursor;
	private Cursor mAircraftsCursor;

	// life cycle

    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setHasOptionsMenu(true);
    }

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflater.inflate(R.layout.fragment_statistics, container, false);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		FragmentActivity activity = getActivity();
        LoaderManager loaderManager = getLoaderManager();

        activity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        loaderManager.initLoader(LOADER_ALTITUDES, null, this);
        loaderManager.initLoader(LOADER_DELAYS, null, this);
        loaderManager.initLoader(LOADER_PLACES, null, this);
        loaderManager.initLoader(LOADER_EQUIPMENT, null, this);
        loaderManager.initLoader(LOADER_AIRCRAFTS, null, this);

		TextView jumpNumbersText = (TextView) activity.findViewById(R.id.text_stat_jump_numbers);
		for (int months : LAST_MONTHS) {
			jumpNumbersText.append(getString(R.string.text_stat_jump_numbers,
					months, DbAdapter.getJumpCountLastMonths(activity, months)));
		}
	}


	// Options menu

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			((BaseActivity)getActivity()).goUp(HomeActivity.class);
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}


    // loaders

	public static class PlacesLoader extends BaseCursorLoader {

		public PlacesLoader(Context context) {
			super(context);
		}

		@Override
		public Cursor getCusor() {
			return new LogbookDatabase(getContext()).getReadableDatabase().query(
					PLACES_TABLE,
					PLACES_PROJECTION,
					null,
					null,
					PLACES_ID,
					null,
					PLACES_COUNT + " DESC",
					null
			);
		}
	}

	public static class EquipmentLoader extends BaseCursorLoader {

		public EquipmentLoader(Context context) {
			super(context);
		}

		@Override
		public Cursor getCusor() {
			return new LogbookDatabase(getContext()).getReadableDatabase().query(
					EQUIPMENT_TABLE,
					EQUIPMENT_PROJECTION,
					null,
					null,
					EQUIPMENT_ID,
					null,
					EQUIPMENT_COUNT + " DESC",
					null
			);
		}
	}

	public static class AircraftsLoader extends BaseCursorLoader {

		public AircraftsLoader(Context context) {
			super(context);
		}

		@Override
		public Cursor getCusor() {
			return new LogbookDatabase(getContext()).getReadableDatabase().query(
					AIRCRAFTS_TABLE,
					AIRCRAFTS_PROJECTION,
					null,
					null,
					AIRCRAFTS_ID,
					null,
					AIRCRAFTS_COUNT + " DESC",
					null
			);
		}
	}

	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {
		switch (id) {
        case LOADER_ALTITUDES:
            return new CursorLoader(
            		getActivity(),
                    Jumps.CONTENT_URI,
                    DbAdapter.ALTITUDES_PROJECTION,
                    DbAdapter.ALTITUDE_SELECTION,
                    DbAdapter.SELECTION_ARG_ZERO,
                    Jumps.DEFAULT_SORT
            );
        case LOADER_DELAYS:
        	return new CursorLoader(
					getActivity(),
					Jumps.CONTENT_URI,
					DbAdapter.DELAYS_PROJECTION,
					DbAdapter.DELAY_SELECTION,
					DbAdapter.SELECTION_ARG_ZERO,
					Jumps.DEFAULT_SORT
			);
        case LOADER_PLACES:
            return new PlacesLoader(getActivity());
        case LOADER_EQUIPMENT:
            return new EquipmentLoader(getActivity());
        case LOADER_AIRCRAFTS:
            return new AircraftsLoader(getActivity());
        default:
            return null;
        }
	}

	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
		switch (loader.getId()) {
        case LOADER_ALTITUDES:
            mAltitudesCursor = data;
            loadAltitudes();
            break;
        case LOADER_DELAYS:
            mDelaysCursor = data;
            loadDelays();
            break;
        case LOADER_PLACES:
            mPlacesCursor = data;
            loadPlaces();
            break;
        case LOADER_EQUIPMENT:
            mEquipmentCursor = data;
            loadEquipment();
            break;
        case LOADER_AIRCRAFTS:
            mAircraftsCursor = data;
            loadAircrafts();
            break;
		}
	}

	@Override
	public void onLoaderReset(Loader<Cursor> loader) {
		switch (loader.getId()) {
        case LOADER_ALTITUDES:
            mAltitudesCursor = null;
            break;
        case LOADER_DELAYS:
            mDelaysCursor = null;
            break;
        case LOADER_PLACES:
            mPlacesCursor = null;
            break;
        case LOADER_EQUIPMENT:
            mEquipmentCursor = null;
            break;
        case LOADER_AIRCRAFTS:
            mAircraftsCursor = null;
            break;
        }
	}

	private void loadAltitudes() {
		Cursor data = mAltitudesCursor;
		Activity activity = getActivity();
		int highestAltitude = 0;
		int averageAltitude = 0;
		int lowestAltitude = 0;
		if (data != null && data.moveToFirst()) {
			highestAltitude = data.getInt(data.getColumnIndexOrThrow(DbAdapter.ALTITUDE_MAX));
			averageAltitude = data.getInt(data.getColumnIndexOrThrow(DbAdapter.ALTITUDE_AVG));
			lowestAltitude = data.getInt(data.getColumnIndexOrThrow(DbAdapter.ALTITUDE_MIN));
		}
		((TextView) activity.findViewById(R.id.text_stat_altitude))
				.setText(getString(R.string.text_stat_altitude,
					UIUtils.formatAltitude(activity, highestAltitude),
					UIUtils.formatAltitude(activity, averageAltitude),
					UIUtils.formatAltitude(activity, lowestAltitude)));
	}

	private void loadDelays() {
		Cursor data = mDelaysCursor;
		Activity activity = getActivity();
		int longestDelay = 0;
		int totalDelay = 0;
		if (data != null && data.moveToFirst()) {
			longestDelay = data.getInt(data.getColumnIndexOrThrow(DbAdapter.DELAY_MAX));
			totalDelay = data.getInt(data.getColumnIndexOrThrow(DbAdapter.DELAY_SUM));
		}
		((TextView) activity.findViewById(R.id.text_stat_delay))
				.setText(getString(R.string.text_stat_delay,
					UIUtils.formatDelay(activity, longestDelay),
					UIUtils.formatDelay(activity, totalDelay)));
	}

	private void loadPlaces() {
		Cursor data = mPlacesCursor;
		TextView placesText = (TextView) getActivity().findViewById(R.id.text_stat_places);
		if (data != null && data.moveToFirst()) {
			int nameColumn = data.getColumnIndexOrThrow(PLACES_NAME);
			int countColumn = data.getColumnIndexOrThrow(PLACES_COUNT);
			do {
				placesText.append(getString(R.string.text_stat_places,
						data.getString(nameColumn), data.getInt(countColumn)));
			} while (data.moveToNext());
		} else {
			placesText.setText(getString(R.string.text_stat_places_empty));
		}
	}

	private void loadEquipment() {
		Cursor data = mEquipmentCursor;
		TextView equipmentText = (TextView) getActivity().findViewById(R.id.text_stat_equipment);
		if (data != null && data.moveToFirst()) {
			int nameColumn = data.getColumnIndexOrThrow(EQUIPMENT_NAME);
			int sizeColumn = data.getColumnIndexOrThrow(EQUIPMENT_SIZE);
			int countColumn = data.getColumnIndexOrThrow(EQUIPMENT_COUNT);
			do {
				equipmentText.append(getString(R.string.text_stat_equipment,
						data.getString(nameColumn), data.getInt(sizeColumn), data.getInt(countColumn)));
			} while (data.moveToNext());
		} else {
			equipmentText.setText(getString(R.string.text_stat_equipment_empty));
		}
	}

	private void loadAircrafts() {
		Cursor data = mAircraftsCursor;
		TextView aircraftsText = (TextView) getActivity().findViewById(R.id.text_stat_aircrafts);
		if (data != null && data.moveToFirst()) {
			int nameColumn = data.getColumnIndexOrThrow(AIRCRAFTS_NAME);
			int countColumn = data.getColumnIndexOrThrow(AIRCRAFTS_COUNT);
			do {
				aircraftsText.append(getString(R.string.text_stat_aircrafts,
						data.getString(nameColumn), data.getInt(countColumn)));
			} while (data.moveToNext());
		} else {
			aircraftsText.setText(getString(R.string.text_stat_aircrafts_empty));
		}
	}


	private static final String PLACES_TABLE = "places LEFT OUTER JOIN jumps ON places._id=jumps.place_id";
	private static final String PLACES_COUNT = "count(jump_number)";
	private static final String PLACES_NAME = "places.place_name";
	private static final String PLACES_ID = "places._id";
	private static final String[] PLACES_PROJECTION = {
		PLACES_COUNT,
		PLACES_NAME,
		PLACES_ID
	};

	private static final String EQUIPMENT_TABLE = "equipment LEFT OUTER JOIN jumps ON equipment._id=jumps.equipment_id";
	private static final String EQUIPMENT_COUNT = "count(jump_number)";
	private static final String EQUIPMENT_NAME = "equipment.equipment_canopy_name";
	private static final String EQUIPMENT_SIZE = "equipment.equipment_canopy_size";
	private static final String EQUIPMENT_ID = "equipment._id";
	private static final String[] EQUIPMENT_PROJECTION = {
		EQUIPMENT_COUNT,
		EQUIPMENT_NAME,
		EQUIPMENT_SIZE,
		EQUIPMENT_ID
	};

	private static final String AIRCRAFTS_TABLE = "aircrafts LEFT OUTER JOIN jumps ON aircrafts._id=jumps.aircraft_id";
	private static final String AIRCRAFTS_COUNT = "count(jump_number)";
	private static final String AIRCRAFTS_NAME = "aircrafts.aircraft_name";
	private static final String AIRCRAFTS_ID = "aircrafts._id";
	private static final String[] AIRCRAFTS_PROJECTION = {
		AIRCRAFTS_COUNT,
		AIRCRAFTS_NAME,
		AIRCRAFTS_ID
	};
}
