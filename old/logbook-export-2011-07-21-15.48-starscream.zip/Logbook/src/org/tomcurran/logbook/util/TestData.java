package org.tomcurran.logbook.util;

import org.tomcurran.logbook.provider.LogbookContract.Aircrafts;
import org.tomcurran.logbook.provider.LogbookContract.Equipment;
import org.tomcurran.logbook.provider.LogbookContract.Jumps;
import org.tomcurran.logbook.provider.LogbookContract.Places;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.text.format.Time;

public class TestData {
	
	private ContentResolver mResolver;
	private Time mTime;
	
	private final PlaceInfo[] PLACES = {
			new PlaceInfo("SPC")
	};
	
	private final AircraftInfo[] AIRCRAFTS = {
			new AircraftInfo("C206")
	};
	
	private final EquipmentInfo[] EQUIPMENT = {
			new EquipmentInfo("Fury", 220),
			new EquipmentInfo("Spectre", 190)
	};
	
	private final JumpInfo[] JUMPS = {
			new JumpInfo(99,  4000,  8,  "chilled out"),
			new JumpInfo(100, 8000,  30, "few barrol rolls & backloops & turns\npuled high to try out new canopy\nlots of fun\nlanded in pit"),
			new JumpInfo(101, 9500,  40, "same as #100\nlanded hanger side of pit\nmake sure not to"),
			new JumpInfo(102, 5000,  18, "practice jump master & spotting\nspun about\nlanded in pit"),
			new JumpInfo(103, 9000,  38, "tracked"),
			new JumpInfo(104, 4000,  12, "rolled out plane"),
			new JumpInfo(105, 7500,  28, "good party night before so just relaxed\nmajor chill out, backloop for good measure\ntried different ways of turning"),
			new JumpInfo(106, 1000,  43, "two way with kelly\nneed to make better use of deep brakes if far out on deployment"),
			new JumpInfo(107, 2200,  7,  "hop'n'pop"),
			new JumpInfo(108, 2400,  7,  "hop'n'pop"),
			new JumpInfo(109, 4000,  11, "hop'n'pop"),
			new JumpInfo(110, 2400,  7,  "hop'n'pop"),
			new JumpInfo(111, 2800,  8,  "hop'n'pop"),
			new JumpInfo(112, 4000,  14, "hop'n'pop"),
			new JumpInfo(113, 4500,  16, "backloop that didn't go so well\nthen turned to check out others in freefall"),
			new JumpInfo(114, 4000,  12, "backloop exit turned into a barrel roll"),
			new JumpInfo(115, 10000, 47, "5 way speed star unlinked exit with john, sandy, jonny, kieran"),
			new JumpInfo(116, 2200,  5, "hop'n'pop"),
			new JumpInfo(117, 4870,  18, "3 way. Lost grips on exit"),
			new JumpInfo(118, 9590,  43, "2 way with sandy.\nDave filming"),
			new JumpInfo(119, 9960,  46, "3 way with sandy & gus. Got first two points good. Then gus forgot the third point and it sort of went tits up"),
			new JumpInfo(120, 9380,  44, "5 way with sandy, kelly, gus, steve")
	};

	public TestData(Activity activity) {
		mResolver = activity.getContentResolver();
		mTime = new Time();
		delete();
		insert();
	}
	
	public void insert() {
		ContentResolver resolver = mResolver;
		Time time = mTime;
		Uri placeUri;
		Uri aircraftUri;
		Uri equipmentUri;

		placeUri = resolver.insert(Places.CONTENT_URI, PLACES[0].getContentValues());
		aircraftUri = resolver.insert(Aircrafts.CONTENT_URI, AIRCRAFTS[0].getContentValues());
		equipmentUri = resolver.insert(Equipment.CONTENT_URI, EQUIPMENT[0].getContentValues());

		time.set(1, 4 - 1, 2011);
		JUMPS[0].setValues(time, placeUri, aircraftUri, equipmentUri);
		
		equipmentUri = resolver.insert(Equipment.CONTENT_URI, EQUIPMENT[1].getContentValues());
		time.set(1, 5 - 1, 2011);
		JUMPS[1].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[2].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[3].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[4].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[5].setValues(time, placeUri, aircraftUri, equipmentUri);

		time.set(30, 5 - 1, 2011);
		JUMPS[6].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[7].setValues(time, placeUri, aircraftUri, equipmentUri);

		time.set(4, 6 - 1, 2011);
		JUMPS[8].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[9].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[10].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[11].setValues(time, placeUri, aircraftUri, equipmentUri);

		time.set(5, 6 - 1, 2011);
		JUMPS[12].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[13].setValues(time, placeUri, aircraftUri, equipmentUri);

		time.set(25, 6 - 1, 2011);
		JUMPS[14].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[15].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[16].setValues(time, placeUri, aircraftUri, equipmentUri);

		time.set(26, 6 - 1, 2011);
		JUMPS[17].setValues(time, placeUri, aircraftUri, equipmentUri);

		time.set(2, 7 - 1, 2011);
		JUMPS[18].setValues(time, placeUri, aircraftUri, equipmentUri);

		time.set(3, 7 - 1, 2011);
		JUMPS[19].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[20].setValues(time, placeUri, aircraftUri, equipmentUri);
		JUMPS[21].setValues(time, placeUri, aircraftUri, equipmentUri);

		for (int index = 0; index < JUMPS.length; index++) {
			resolver.insert(Jumps.CONTENT_URI, JUMPS[index].getContentValues());
        }
	}
	
	public void delete() {
		ContentResolver resolver = mResolver;
		resolver.delete(Jumps.CONTENT_URI, null, null);
		resolver.delete(Places.CONTENT_URI, null, null);
		resolver.delete(Aircrafts.CONTENT_URI, null, null);
		resolver.delete(Equipment.CONTENT_URI, null, null);
	}

	private static class PlaceInfo {
		String place_name;
		
		public PlaceInfo(String name) {
			this.place_name = name;
		}
		
		public ContentValues getContentValues() {
			ContentValues v = new ContentValues();
			v.put(Places.PLACE_NAME, place_name);
			return v;
		}
	}

	private static class AircraftInfo {
		String aircraft_name;
		
		public AircraftInfo(String name) {
			this.aircraft_name = name;
		}
		
		public ContentValues getContentValues() {
			ContentValues v = new ContentValues();
			v.put(Aircrafts.AIRCRAFT_NAME, aircraft_name);
			return v;
		}
	}

	private static class EquipmentInfo {
		String equipment_canopy_name;
		int equipment_canopy_size;
		
		public EquipmentInfo(String name, int size) {
			this.equipment_canopy_name = name;
			this.equipment_canopy_size = size;
		}
		
		public ContentValues getContentValues() {
			ContentValues v = new ContentValues();
			v.put(Equipment.EQUIPMENT_CANOPY_NAME, equipment_canopy_name);
			v.put(Equipment.EQUIPMENT_CANOPY_SIZE, equipment_canopy_size);
			return v;
		}
	}

	private static class JumpInfo {
		int place_id;
		int aircraft_id;
		int equipment_id;
		int jump_number;
		long jump_date;
		int jump_altitude;
		int jump_delay;
		String jump_description;
		
		public JumpInfo(int number, int altitude, int delay, String description) {
			this.place_id = 0;
			this.aircraft_id = 0;
			this.equipment_id = 0;
			this.jump_number = number;
			this.jump_date = 0L;
			this.jump_altitude = altitude;
			this.jump_delay = delay;
			this.jump_description = description;
		}
		
		public ContentValues getContentValues() {
			ContentValues v = new ContentValues();
			v.put(Jumps.PLACE_ID, place_id);
			v.put(Jumps.AIRCRAFT_ID, aircraft_id);
			v.put(Jumps.EQUIPMENT_ID, equipment_id);
			v.put(Jumps.JUMP_NUMBER, jump_number);
			v.put(Jumps.JUMP_DATE, jump_date);
			v.put(Jumps.JUMP_ALTITUDE, jump_altitude);
			v.put(Jumps.JUMP_DELAY, jump_delay);
			v.put(Jumps.JUMP_DESCRIPTION, jump_description);
			return v;
		}
		
		public void setValues(Time time, Uri placeUri, Uri aircraftUri, Uri equipmentUri) {
			this.jump_date = time.toMillis(false);
			this.place_id = Integer.valueOf(Places.getPlaceId(placeUri));
			this.aircraft_id = Integer.valueOf(Aircrafts.getAircraftId(aircraftUri));
			this.equipment_id = Integer.valueOf(Equipment.getEquipmentId(equipmentUri));
		}
	}


}
