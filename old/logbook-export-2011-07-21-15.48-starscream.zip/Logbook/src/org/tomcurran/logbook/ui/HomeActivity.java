package org.tomcurran.logbook.ui;

import org.tomcurran.logbook.ui.fragments.JumpsListFragment;

import android.support.v4.app.Fragment;

public class HomeActivity extends BaseSinglePaneActivity {

	@Override
	protected Fragment onCreatePane() {
//		new TestData(this);
		return new JumpsListFragment();
	}

}